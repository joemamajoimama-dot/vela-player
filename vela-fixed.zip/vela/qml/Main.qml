import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Dialogs
import QtQuick.Effects
import QtQuick.Layouts
import QtQuick.Window
import Vela

ApplicationWindow {
    id: win
    width: 1320
    height: 820
    minimumWidth: 760
    minimumHeight: 500
    visible: true
    title: vlc.hasMedia ? vlc.title + " — Vela" : "Vela"
    color: Theme.c.bg
    flags: (Theme.opt.titlebar === "custom" ? (Qt.Window | Qt.FramelessWindowHint) : Qt.Window) | (keepOnTop ? Qt.WindowStaysOnTopHint : 0)

    font.family: Theme.opt.fontFamily
    font.pixelSize: 14 * Theme.opt.fontScale

    property var startupUrls: []
    property bool playerOpen: false
    property bool keepOnTop: false
    property string page: "home"
    readonly property bool customChrome: Theme.opt.titlebar === "custom"
    readonly property bool isFullScreen: visibility === Window.FullScreen
    property int lastVisibility: Window.Windowed

    // ---------------------------------------------------------------- core

    VlcPlayer {
        id: vlc
        onEndReached: {
            watchHistory.record(source, title, 0, length, hasVideo)
            playQueue.next(false) // stays on the last item when the queue is done
        }
        onErrorOccurred: win.toast("info", lastError)
        onSourceChanged: recordTimer.restart()
    }

    PlaylistModel {
        id: playQueue
        onPlayRequested: url => win.playUrl(url)
    }

    HistoryModel { id: watchHistory }

    LibraryModel { id: homeLibrary; kind: "all"; sortBy: "recent" }

    Timer {
        id: recordTimer
        interval: 5000
        repeat: true
        running: vlc.playing
        onTriggered: watchHistory.record(vlc.source, vlc.title, vlc.time, vlc.length, vlc.hasVideo)
    }

    function playUrl(url) {
        const resume = watchHistory.resumePosition(url)
        vlc.open(url, resume)
        if (resume > 0)
            toast("clock", qsTr("Resumed at %1").arg(fmt(resume)))
        if (Theme.opt.autoOpenPlayer)
            playerOpen = true
    }

    function openUrls(urls) {
        if (!urls || urls.length === 0) return
        playQueue.playAll(urls, 0)
    }

    function enqueue(urls) {
        if (playQueue.count === 0) { openUrls(urls); return }
        playQueue.appendMany(urls)
        toast("queue", urls.length === 1 ? qsTr("Added to queue") : qsTr("%1 items added to queue").arg(urls.length))
    }

    function toast(icon, text) { toaster.show(icon, text) }

    function go(p) { page = p; if (playerOpen) playerOpen = false }

    function fmt(ms) {
        const s = Math.max(0, Math.floor(ms / 1000)), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = s % 60
        return (h > 0 ? h + ":" + String(m).padStart(2, "0") : m) + ":" + String(ss).padStart(2, "0")
    }

    function toggleFullScreen() {
        if (isFullScreen) {
            visibility = lastVisibility === Window.FullScreen ? Window.Windowed : lastVisibility
        } else {
            lastVisibility = visibility
            showFullScreen()
        }
    }

    function openFileDialog() { fileDialog.open() }
    function openSubtitleDialog() { subtitleDialog.open() }

    Component.onCompleted: if (startupUrls.length > 0) openUrls(startupUrls)

    onClosing: if (vlc.hasMedia) watchHistory.record(vlc.source, vlc.title, vlc.time, vlc.length, vlc.hasVideo)

    FileDialog {
        id: fileDialog
        title: qsTr("Open media")
        fileMode: FileDialog.OpenFiles
        nameFilters: [qsTr("Media files (*.mkv *.mp4 *.m4v *.webm *.avi *.mov *.wmv *.flv *.mpg *.mpeg *.ts *.m2ts *.ogv *.mp3 *.flac *.ogg *.opus *.m4a *.aac *.wav)"), qsTr("All files (*)")]
        onAccepted: win.openUrls(selectedFiles)
    }

    FileDialog {
        id: subtitleDialog
        title: qsTr("Add subtitles")
        nameFilters: [qsTr("Subtitles (*.srt *.ass *.ssa *.vtt *.sub *.idx)"), qsTr("All files (*)")]
        onAccepted: if (vlc.addSubtitle(selectedFile)) win.toast("subtitles", qsTr("Subtitles added"))
    }

    // ------------------------------------------------------------- layout

    Item {
        id: shell
        anchors.fill: parent

        // Subtle ambient wash behind the whole app, tinted by the accent.
        Rectangle {
            anchors.fill: parent
            gradient: Gradient {
                GradientStop { position: 0; color: Theme.mix(Theme.c.bg, Theme.c.accent, Theme.dark ? 0.07 : 0.04) }
                GradientStop { position: 0.45; color: Theme.c.bg }
                GradientStop { position: 1; color: Theme.c.bgAlt }
            }
        }

        RowLayout {
            anchors.fill: parent
            spacing: 0

            // Sidebar ------------------------------------------------------
            Rectangle {
                id: sidebar
                readonly property bool compact: Theme.opt.sidebar === "compact" || win.width < 980
                Layout.fillHeight: true
                Layout.preferredWidth: compact ? 76 : 240
                color: Theme.alpha(Theme.c.surface, Theme.dark ? 0.55 : 0.7)
                Behavior on Layout.preferredWidth { NumberAnimation { duration: Theme.opt.motion ? 240 : 0; easing.type: Easing.OutCubic } }

                Rectangle { anchors { top: parent.top; bottom: parent.bottom; right: parent.right } width: 1; color: Theme.c.border }

                DragHandler {
                    target: null
                    enabled: win.customChrome
                    onActiveChanged: if (active) win.startSystemMove()
                }

                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: sidebar.compact ? 12 : 16
                    anchors.topMargin: 20
                    spacing: 4 * Theme.opt.space

                    // Brand
                    RowLayout {
                        spacing: 10
                        Layout.bottomMargin: 18
                        Layout.leftMargin: sidebar.compact ? 6 : 6
                        Image {
                            source: "qrc:/qt/qml/Vela/branding/vela.svg"
                            sourceSize: Qt.size(40, 40)
                            Layout.preferredWidth: 40
                            Layout.preferredHeight: 40
                        }
                        Text {
                            visible: !sidebar.compact
                            text: "Vela"
                            color: Theme.c.text
                            font.family: "Inter Display"
                            font.pixelSize: 24 * Theme.opt.fontScale
                            font.weight: Font.Bold
                            font.letterSpacing: -0.6
                        }
                    }

                    SidebarItem { icon: "home"; text: qsTr("Home"); compact: sidebar.compact; active: win.page === "home" && !win.playerOpen; onClicked: win.go("home") }
                    SidebarItem { icon: "film"; text: qsTr("Videos"); compact: sidebar.compact; active: win.page === "videos" && !win.playerOpen; onClicked: win.go("videos") }
                    SidebarItem { icon: "music"; text: qsTr("Music"); compact: sidebar.compact; active: win.page === "music" && !win.playerOpen; onClicked: win.go("music") }
                    SidebarItem { icon: "queue"; text: qsTr("Queue"); compact: sidebar.compact; badge: playQueue.count > 0 ? String(playQueue.count) : ""; active: win.page === "queue" && !win.playerOpen; onClicked: win.go("queue") }
                    SidebarItem { icon: "globe"; text: qsTr("Streams"); compact: sidebar.compact; active: win.page === "streams" && !win.playerOpen; onClicked: win.go("streams") }

                    Item { Layout.fillHeight: true }

                    // Now playing shortcut
                    SidebarItem {
                        visible: vlc.hasMedia
                        icon: vlc.playing ? "sparkle" : "play"
                        text: qsTr("Now playing")
                        compact: sidebar.compact
                        active: win.playerOpen
                        onClicked: win.playerOpen = true
                    }
                    SidebarItem { icon: "palette"; text: qsTr("Customize"); compact: sidebar.compact; active: win.page === "settings" && !win.playerOpen; onClicked: win.go("settings") }

                    PillButton {
                        visible: !sidebar.compact
                        text: qsTr("Open media")
                        icon: "file-plus"
                        primary: true
                        Layout.fillWidth: true
                        Layout.topMargin: 10
                        onClicked: win.openFileDialog()
                    }
                    IconButton {
                        visible: sidebar.compact
                        icon: "file-plus"
                        filled: true
                        Layout.alignment: Qt.AlignHCenter
                        Layout.topMargin: 8
                        onClicked: win.openFileDialog()
                    }
                }
            }

            // Content --------------------------------------------------------
            Item {
                Layout.fillWidth: true
                Layout.fillHeight: true

                TitleBar {
                    id: titleBar
                    z: 5
                    visible: win.customChrome
                    window: win
                    anchors { left: parent.left; right: parent.right; top: parent.top }
                }

                StackLayout {
                    id: pages
                    anchors.fill: parent
                    anchors.bottomMargin: mini.visible ? mini.height + 24 : 0
                    currentIndex: ["home", "videos", "music", "queue", "streams", "settings"].indexOf(win.page)

                    HomeView { app: win; player: vlc; queue: playQueue; history: watchHistory; library: homeLibrary }
                    LibraryView { app: win; queue: playQueue; kind: "video"; heading: qsTr("Videos") }
                    LibraryView { app: win; queue: playQueue; kind: "audio"; heading: qsTr("Music") }
                    QueueView { app: win; queue: playQueue; player: vlc }
                    StreamsView { app: win; history: watchHistory }
                    SettingsView { app: win; player: vlc; history: watchHistory }
                }

                MiniPlayer {
                    id: mini
                    player: vlc
                    queue: playQueue
                    visible: vlc.hasMedia && !win.playerOpen
                    anchors { left: parent.left; right: parent.right; bottom: parent.bottom; margins: 16 }
                    onExpand: win.playerOpen = true
                }
            }
        }

        // Full-window player, slides up over everything.
        PlayerView {
            id: playerView
            anchors.fill: parent
            app: win
            player: vlc
            queue: playQueue
            visible: opacity > 0.001
            opacity: win.playerOpen ? 1 : 0
            scale: win.playerOpen ? 1 : 0.97
            Behavior on opacity { NumberAnimation { duration: Theme.opt.motion ? 260 * Theme.opt.motionSpeed : 0; easing.type: Easing.OutCubic } }
            Behavior on scale { NumberAnimation { duration: Theme.opt.motion ? 320 * Theme.opt.motionSpeed : 0; easing.type: Easing.OutCubic } }
            onCloseRequested: { if (win.isFullScreen) win.toggleFullScreen(); win.playerOpen = false }
        }

        Toast {
            id: toaster
            z: 100
            backdrop: win.playerOpen ? playerView : null
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.top: parent.top
            anchors.topMargin: 28
        }

        // Drop files anywhere
        DropArea {
            id: drop
            anchors.fill: parent
            keys: ["text/uri-list"]
            onDropped: drop => {
                if (!drop.hasUrls) return
                if (drop.urls.length === 1 && vlc.hasMedia && /\.(srt|ass|ssa|vtt|sub)$/i.test(drop.urls[0].toString())) {
                    if (vlc.addSubtitle(drop.urls[0])) win.toast("subtitles", qsTr("Subtitles added"))
                    return
                }
                (win.page === "queue" && !win.playerOpen) ? win.enqueue(drop.urls) : win.openUrls(drop.urls)
            }
        }
        Rectangle {
            anchors.fill: parent
            anchors.margins: 14
            visible: drop.containsDrag
            radius: Theme.opt.radius + 8
            color: Theme.alpha(Theme.c.accent, 0.12)
            border.width: 2
            border.color: Theme.c.accent
            ColumnLayout {
                anchors.centerIn: parent
                spacing: 12
                Icon { name: "import"; size: 48; color: Theme.c.accent; Layout.alignment: Qt.AlignHCenter }
                Text { text: win.page === "queue" && !win.playerOpen ? qsTr("Drop to queue") : qsTr("Drop to play"); color: Theme.c.text; font.pixelSize: 22 * Theme.opt.fontScale; font.weight: Font.Bold; Layout.alignment: Qt.AlignHCenter }
                Text { text: win.page === "queue" && !win.playerOpen ? qsTr("Adds to the end of your queue") : qsTr("Tip: drop a subtitle file onto a playing video"); color: Theme.c.textDim; font.pixelSize: 13 * Theme.opt.fontScale; Layout.alignment: Qt.AlignHCenter }
            }
        }

        // Film grain overlay (optional)
        Item {
            anchors.fill: parent
            visible: Theme.opt.grain
            opacity: 0.05
            Canvas {
                anchors.fill: parent
                renderStrategy: Canvas.Cooperative
                onPaint: {
                    const ctx = getContext("2d")
                    for (let i = 0; i < width * height / 60; ++i) {
                        ctx.fillStyle = Math.random() > 0.5 ? "#FFFFFF" : "#000000"
                        ctx.fillRect(Math.random() * width, Math.random() * height, 1, 1)
                    }
                }
            }
        }
    }

    // Window edge resizing for the frameless window
    Repeater {
        model: win.customChrome && win.visibility === Window.Windowed ? [
            { e: Qt.LeftEdge,  x: 0, y: 8, w: 6, h: -16, c: Qt.SizeHorCursor },
            { e: Qt.RightEdge, x: -6, y: 8, w: 6, h: -16, c: Qt.SizeHorCursor },
            { e: Qt.TopEdge,   x: 8, y: 0, w: -16, h: 6, c: Qt.SizeVerCursor },
            { e: Qt.BottomEdge, x: 8, y: -6, w: -16, h: 6, c: Qt.SizeVerCursor },
            { e: Qt.TopEdge | Qt.LeftEdge, x: 0, y: 0, w: 10, h: 10, c: Qt.SizeFDiagCursor },
            { e: Qt.TopEdge | Qt.RightEdge, x: -10, y: 0, w: 10, h: 10, c: Qt.SizeBDiagCursor },
            { e: Qt.BottomEdge | Qt.LeftEdge, x: 0, y: -10, w: 10, h: 10, c: Qt.SizeBDiagCursor },
            { e: Qt.BottomEdge | Qt.RightEdge, x: -10, y: -10, w: 10, h: 10, c: Qt.SizeFDiagCursor }
        ] : []
        delegate: MouseArea {
            required property var modelData
            z: 1000
            x: modelData.x < 0 ? win.width + modelData.x : modelData.x
            y: modelData.y < 0 ? win.height + modelData.y : modelData.y
            width: modelData.w <= 0 ? win.width + modelData.w : modelData.w
            height: modelData.h <= 0 ? win.height + modelData.h : modelData.h
            cursorShape: modelData.c
            onPressed: win.startSystemResize(modelData.e)
        }
    }

    // ---------------------------------------------------------- shortcuts

    Shortcut { sequences: [StandardKey.Open]; onActivated: win.openFileDialog() }
    Shortcut { sequence: "Ctrl+L"; onActivated: win.go("streams") }
    Shortcut { sequence: "Ctrl+,"; onActivated: win.go("settings") }
    Shortcut { sequences: [StandardKey.Quit]; onActivated: win.close() }
    Shortcut { sequence: "Space"; enabled: vlc.hasMedia; onActivated: vlc.togglePause() }
    Shortcut { sequence: "K"; enabled: vlc.hasMedia; onActivated: vlc.togglePause() }
    Shortcut { sequence: "F"; onActivated: { if (vlc.hasMedia) win.playerOpen = true; win.toggleFullScreen() } }
    Shortcut { sequence: "F11"; onActivated: win.toggleFullScreen() }
    Shortcut {
        sequence: "Esc"
        onActivated: win.isFullScreen ? win.toggleFullScreen() : (win.playerOpen ? win.playerOpen = false : undefined)
    }
    Shortcut { sequence: "M"; onActivated: { vlc.muted = !vlc.muted; win.toast(vlc.muted ? "volume-mute" : "volume", vlc.muted ? qsTr("Muted") : qsTr("Sound on")) } }
    Shortcut { sequence: "Right"; onActivated: { vlc.seekRelative(10000); win.toast("fwd-10", win.fmt(vlc.time)) } }
    Shortcut { sequence: "Left"; onActivated: { vlc.seekRelative(-10000); win.toast("back-10", win.fmt(vlc.time)) } }
    Shortcut { sequence: "Shift+Right"; onActivated: vlc.seekRelative(60000) }
    Shortcut { sequence: "Shift+Left"; onActivated: vlc.seekRelative(-60000) }
    Shortcut { sequence: "L"; onActivated: vlc.seekRelative(10000) }
    Shortcut { sequence: "J"; onActivated: vlc.seekRelative(-10000) }
    Shortcut { sequence: "."; onActivated: vlc.nextFrame() }
    Shortcut { sequence: "Up"; onActivated: { vlc.volume = Math.min(Theme.opt.volumeBoost ? 200 : 100, vlc.volume + 5); win.toast("volume", qsTr("Volume %1%").arg(vlc.volume)) } }
    Shortcut { sequence: "Down"; onActivated: { vlc.volume = Math.max(0, vlc.volume - 5); win.toast("volume-low", qsTr("Volume %1%").arg(vlc.volume)) } }
    Shortcut { sequence: "N"; onActivated: playQueue.next() }
    Shortcut { sequence: "P"; onActivated: playQueue.previous() }
    Shortcut { sequence: "]"; onActivated: { vlc.rate = Math.min(4, Math.round((vlc.rate + 0.25) * 100) / 100); win.toast("speed", vlc.rate + "×") } }
    Shortcut { sequence: "["; onActivated: { vlc.rate = Math.max(0.25, Math.round((vlc.rate - 0.25) * 100) / 100); win.toast("speed", vlc.rate + "×") } }
    Shortcut { sequence: "="; onActivated: { vlc.rate = 1; win.toast("speed", "1×") } }
    Shortcut {
        sequence: "S"
        onActivated: {
            const p = vlc.snapshot()
            win.toast("camera", p ? qsTr("Snapshot saved to Pictures/Vela") : qsTr("Nothing to capture"))
        }
    }
    Shortcut {
        sequence: "V"
        onActivated: {
            const t = vlc.subtitleTracks
            if (t.length === 0) return
            let i = t.findIndex(x => x.id === vlc.subtitleTrack)
            const next = t[(i + 1) % t.length]
            vlc.subtitleTrack = next.id
            win.toast("subtitles", next.name)
        }
    }
    Shortcut {
        sequence: "B"
        onActivated: {
            const t = vlc.audioTracks.filter(x => x.id >= 0)
            if (t.length === 0) return
            let i = t.findIndex(x => x.id === vlc.audioTrack)
            const next = t[(i + 1) % t.length]
            vlc.audioTrack = next.id
            win.toast("audio-track", next.name)
        }
    }
}
