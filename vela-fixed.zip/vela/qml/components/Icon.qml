import QtQuick
import QtQuick.Controls.impl as Impl
import Vela

// Monochrome SVG icon, tinted to any colour.
Impl.IconImage {
    id: root
    property string name
    property int size: 20
    source: name ? Theme.icon(name) : ""
    sourceSize: Qt.size(size, size)
    width: size
    height: size
    color: Theme.c.text
    fillMode: Image.PreserveAspectFit
}
