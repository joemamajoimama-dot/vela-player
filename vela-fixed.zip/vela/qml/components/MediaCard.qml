import QtQuick
import QtQuick.Effects
import QtQuick.Layouts
import Vela

// Poster-style tile. Falls back to a generative gradient "cover" derived from
// the title when the desktop has no thumbnail for the file yet.
Item {
    id: root
    property string title
    property string subtitle
    property url thumbnail
    property string kind: "video"
    property string badge
    property real progress: -1
    property real aspect: kind === "audio" ? 1 : 16 / 9
    signal clicked()
    signal rightClicked(real x, real y)

    implicitWidth: Theme.opt.cardSize
    implicitHeight: coverBox.height + meta.implicitHeight + 10

    function hue(s) { let h = 0; for (let i = 0; i < s.length; ++i) h = (h * 31 + s.charCodeAt(i)) % 360; return h / 360 }

    Item {
        id: coverBox
        width: parent.width
        height: width / root.aspect
        scale: ma.containsMouse ? 1.025 : 1
        Behavior on scale { NumberAnimation { duration: Theme.opt.motion ? 240 * Theme.opt.motionSpeed : 0; easing.type: Easing.OutCubic } }

        Rectangle {
            id: cover
            anchors.fill: parent
            radius: Theme.opt.radius
            readonly property real h: root.hue(root.title)
            gradient: Gradient {
                orientation: Gradient.Vertical
                GradientStop { position: 0; color: Qt.hsla(cover.h, 0.55, Theme.dark ? 0.32 : 0.72, 1) }
                GradientStop { position: 1; color: Qt.hsla((cover.h + 0.12) % 1, 0.6, Theme.dark ? 0.14 : 0.55, 1) }
            }
            Icon {
                anchors.centerIn: parent
                visible: thumb.status !== Image.Ready
                name: root.kind === "audio" ? "music" : "film"
                size: Math.min(parent.width, parent.height) * 0.28
                color: Theme.alpha("#FFFFFF", 0.55)
            }
        }

        Image {
            id: thumb
            anchors.fill: parent
            source: root.thumbnail
            fillMode: Image.PreserveAspectCrop
            asynchronous: true
            visible: false
            sourceSize.width: 480
        }
        Rectangle { id: thumbMask; anchors.fill: parent; radius: Theme.opt.radius; visible: false; layer.enabled: true }
        MultiEffect {
            anchors.fill: parent
            visible: thumb.status === Image.Ready
            source: thumb
            maskEnabled: true
            maskSource: thumbMask
        }

        // Hover scrim + play glyph
        Rectangle {
            anchors.fill: parent
            radius: Theme.opt.radius
            color: Theme.alpha("#000000", ma.containsMouse ? 0.35 : 0)
            Behavior on color { ColorAnimation { duration: 180 } }
            Rectangle {
                anchors.centerIn: parent
                width: 52; height: 52; radius: 26
                color: Theme.c.accent
                opacity: ma.containsMouse ? 1 : 0
                scale: ma.containsMouse ? 1 : 0.6
                Behavior on opacity { NumberAnimation { duration: 180 } }
                Behavior on scale { NumberAnimation { duration: Theme.opt.motion ? 260 : 0; easing.type: Easing.OutBack } }
                Icon { anchors.centerIn: parent; anchors.horizontalCenterOffset: 2; name: "play"; size: 22; color: Theme.c.onAccent }
            }
        }

        Rectangle {
            visible: root.badge !== ""
            anchors { top: parent.top; right: parent.right; margins: 10 }
            width: badgeLabel.implicitWidth + 12
            height: 20
            radius: 6
            color: Theme.alpha("#000000", 0.55)
            Text { id: badgeLabel; anchors.centerIn: parent; text: root.badge; color: "#FFFFFF"; font.pixelSize: 10 * Theme.opt.fontScale; font.weight: Font.Bold; font.letterSpacing: 0.6 }
        }

        Rectangle {
            visible: root.progress >= 0
            anchors { left: parent.left; right: parent.right; bottom: parent.bottom; margins: 10 }
            height: 4
            radius: 2
            color: Theme.alpha("#FFFFFF", 0.25)
            Rectangle { width: parent.width * Math.max(0.03, root.progress); height: parent.height; radius: 2; color: Theme.c.accent }
        }
    }

    ColumnLayout {
        id: meta
        anchors.top: coverBox.bottom
        anchors.topMargin: 10
        width: parent.width
        spacing: 2
        Text {
            text: root.title
            color: Theme.c.text
            font.pixelSize: 14 * Theme.opt.fontScale
            font.weight: Font.DemiBold
            elide: Text.ElideRight
            Layout.fillWidth: true
        }
        Text {
            visible: root.subtitle !== ""
            text: root.subtitle
            color: Theme.c.textMuted
            font.pixelSize: 12 * Theme.opt.fontScale
            elide: Text.ElideRight
            Layout.fillWidth: true
        }
    }

    MouseArea {
        id: ma
        anchors.fill: parent
        hoverEnabled: true
        acceptedButtons: Qt.LeftButton | Qt.RightButton
        cursorShape: Qt.PointingHandCursor
        onClicked: mouse => mouse.button === Qt.RightButton ? root.rightClicked(mouse.x, mouse.y) : root.clicked()
    }
}
