import QtQuick
import QtQuick.Effects
import QtQuick.Layouts
import Vela

// Docked "now playing" bar shown while you browse.
Rectangle {
    id: root
    property VlcPlayer player
    property PlaylistModel queue
    signal expand()

    implicitHeight: 76
    radius: Theme.opt.radius + 2
    color: Theme.c.surfaceHi
    border.color: Theme.c.border

    function fmt(ms) {
        const s = Math.max(0, Math.floor(ms / 1000)), m = Math.floor(s / 60), ss = s % 60
        return m + ":" + String(ss).padStart(2, "0")
    }

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 10
        anchors.rightMargin: 16
        spacing: 14

        // Live miniature of the video (or artwork / glyph for audio)
        Item {
            Layout.preferredWidth: root.player && root.player.hasVideo ? 100 : 56
            Layout.preferredHeight: 56
            Behavior on Layout.preferredWidth { NumberAnimation { duration: 200 } }
            Rectangle {
                id: frame
                anchors.fill: parent
                radius: Theme.opt.radius * 0.7
                color: Theme.mix(Theme.c.accent, "#000000", 0.55)
                Icon { anchors.centerIn: parent; visible: !root.player.hasVideo; name: "music"; size: 22; color: Theme.alpha("#FFFFFF", 0.8) }
            }
            VideoItem {
                id: mini
                anchors.fill: parent
                player: root.player
                fillMode: VideoItem.Fill
                visible: false
            }
            Rectangle { id: miniMask; anchors.fill: parent; radius: frame.radius; visible: false; layer.enabled: true }
            MultiEffect { anchors.fill: parent; source: mini; maskEnabled: true; maskSource: miniMask; visible: root.player.hasVideo }
            MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: root.expand() }
        }

        ColumnLayout {
            spacing: 2
            Layout.fillWidth: true
            Text {
                text: root.player.title
                color: Theme.c.text
                font.pixelSize: 14 * Theme.opt.fontScale
                font.weight: Font.DemiBold
                elide: Text.ElideRight
                Layout.fillWidth: true
            }
            Text {
                text: (root.player.artist ? root.player.artist + "  ·  " : "") + root.fmt(root.player.time) + " / " + root.fmt(root.player.length)
                color: Theme.c.textMuted
                font.pixelSize: 12 * Theme.opt.fontScale
                font.features: ({ "tnum": 1 })
                Layout.fillWidth: true
                elide: Text.ElideRight
            }
        }

        IconButton { icon: "skip-prev"; size: 38; enabled: root.queue.hasPrevious; onClicked: root.queue.previous() }
        IconButton { icon: root.player.playing ? "pause" : "play"; filled: true; size: 46; onClicked: root.player.togglePause() }
        IconButton { icon: "skip-next"; size: 38; enabled: root.queue.hasNext; onClicked: root.queue.next() }
        Item { implicitWidth: 6 }
        IconButton { icon: "fullscreen"; size: 38; tip: qsTr("Open player"); onClicked: root.expand() }
    }

    // Progress hairline along the bottom edge
    Rectangle {
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: root.radius; rightMargin: root.radius }
        height: 2
        radius: 1
        color: Theme.alpha(Theme.c.text, 0.08)
        Rectangle { width: parent.width * root.player.position; height: parent.height; radius: 1; color: Theme.c.accent }
    }
}
