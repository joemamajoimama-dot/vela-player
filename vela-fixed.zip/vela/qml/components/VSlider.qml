import QtQuick
import QtQuick.Controls.Basic
import Vela

// Theme-styled slider used for volume and every numeric setting.
Slider {
    id: control
    property bool showValue: false
    property string suffix: ""
    property int decimals: 0
    implicitWidth: 180
    implicitHeight: 28
    hoverEnabled: true

    background: Rectangle {
        x: control.leftPadding
        y: control.topPadding + control.availableHeight / 2 - height / 2
        width: control.availableWidth
        height: control.hovered || control.pressed ? 6 : 4
        radius: height / 2
        color: Theme.alpha(Theme.c.text, 0.16)
        Behavior on height { NumberAnimation { duration: 120 } }
        Rectangle {
            width: control.visualPosition * parent.width
            height: parent.height
            radius: parent.radius
            color: Theme.c.accent
        }
    }
    handle: Rectangle {
        x: control.leftPadding + control.visualPosition * (control.availableWidth - width)
        y: control.topPadding + control.availableHeight / 2 - height / 2
        width: control.pressed ? 18 : 16
        height: width
        radius: width / 2
        color: "#FFFFFF"
        border.color: Theme.c.accent
        border.width: 3
        Behavior on width { NumberAnimation { duration: 120 } }

        Rectangle {
            visible: control.showValue && (control.pressed || control.hovered)
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.bottom: parent.top
            anchors.bottomMargin: 8
            width: valueText.implicitWidth + 12
            height: 22
            radius: 6
            color: Theme.c.elevated
            border.color: Theme.c.border
            Text {
                id: valueText
                anchors.centerIn: parent
                text: control.value.toFixed(control.decimals) + control.suffix
                color: Theme.c.text
                font.pixelSize: 11 * Theme.opt.fontScale
                font.weight: Font.DemiBold
            }
        }
    }
}
