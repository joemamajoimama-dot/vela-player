import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Effects
import QtQuick.Layouts
import Vela

Flickable {
    id: root
    property var app
    property VlcPlayer player
    property PlaylistModel queue
    property HistoryModel history
    property LibraryModel library

    contentHeight: col.implicitHeight + 120
    clip: true
    boundsBehavior: Flickable.StopAtBounds
    ScrollBar.vertical: ScrollBar { policy: ScrollBar.AsNeeded }

    readonly property real pad: 40 * Theme.opt.space
    readonly property var hero: history.count > 0 ? history.get(0) : null

    function greeting() {
        const h = new Date().getHours()
        return h < 5 ? qsTr("Late night") : h < 12 ? qsTr("Good morning") : h < 18 ? qsTr("Good afternoon") : qsTr("Good evening")
    }
    function hue(s) { let h = 0; s = s || ""; for (let i = 0; i < s.length; ++i) h = (h * 31 + s.charCodeAt(i)) % 360; return h / 360 }

    ColumnLayout {
        id: col
        x: root.pad
        y: 64
        width: root.width - root.pad * 2
        spacing: 34 * Theme.opt.space

        // Header ---------------------------------------------------------------
        ColumnLayout {
            spacing: 6
            Text {
                text: root.greeting()
                color: Theme.c.accent
                font.pixelSize: 14 * Theme.opt.fontScale
                font.weight: Font.DemiBold
            }
            Text {
                text: root.hero ? qsTr("Pick up where you left off.") : qsTr("What are we watching?")
                color: Theme.c.text
                font.family: "Inter Display"
                font.pixelSize: 38 * Theme.opt.fontScale
                font.weight: Font.Bold
                font.letterSpacing: -1
            }
            RowLayout {
                spacing: 10
                Layout.topMargin: 14
                PillButton { text: qsTr("Open files"); icon: "file-plus"; primary: true; onClicked: root.app.openFileDialog() }
                PillButton { text: qsTr("Play a link"); icon: "link"; onClicked: root.app.go("streams") }
                PillButton { text: qsTr("Make it yours"); icon: "palette"; onClicked: root.app.go("settings") }
            }
        }

        // Hero -----------------------------------------------------------------
        Item {
            Layout.fillWidth: true
            Layout.preferredHeight: Math.max(240, Math.min(360, width * 0.34))

            Rectangle {
                id: heroCard
                anchors.fill: parent
                radius: Theme.opt.radius + 10
                readonly property real h: root.hue(root.hero ? root.hero.title : "vela")
                gradient: Gradient {
                    orientation: Gradient.Horizontal
                    GradientStop { position: 0; color: root.hero ? Qt.hsla(heroCard.h, 0.55, Theme.dark ? 0.22 : 0.6, 1) : Theme.mix(Theme.c.accent, Theme.c.bg, 0.55) }
                    GradientStop { position: 1; color: root.hero ? Qt.hsla((heroCard.h + 0.14) % 1, 0.6, Theme.dark ? 0.1 : 0.45, 1) : Theme.mix(Theme.c.accent, Theme.c.bg, 0.85) }
                }
                border.color: Theme.c.border
            }
            Image {
                id: heroThumb
                anchors.fill: parent
                source: root.hero ? root.hero.thumbnail : ""
                fillMode: Image.PreserveAspectCrop
                visible: false
            }
            Rectangle { id: heroMask; anchors.fill: parent; radius: heroCard.radius; visible: false; layer.enabled: true }
            MultiEffect {
                anchors.fill: parent
                source: heroThumb
                visible: heroThumb.status === Image.Ready
                maskEnabled: true
                maskSource: heroMask
                blurEnabled: true
                blur: 0.25
                blurMax: 24
                brightness: -0.15
            }
            // Legibility scrim
            Rectangle {
                anchors.fill: parent
                radius: heroCard.radius
                gradient: Gradient {
                    orientation: Gradient.Horizontal
                    GradientStop { position: 0; color: Theme.alpha("#000000", 0.55) }
                    GradientStop { position: 0.7; color: Theme.alpha("#000000", 0.0) }
                }
            }
            // Decorative sail mark, huge and faint
            Image {
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                anchors.rightMargin: -parent.height * 0.08
                width: parent.height * 1.15
                height: width
                source: "qrc:/qt/qml/Vela/branding/vela.svg"
                sourceSize: Qt.size(width, height)
                opacity: root.hero ? 0.0 : 0.22
                visible: opacity > 0
            }

            ColumnLayout {
                anchors.left: parent.left
                anchors.verticalCenter: parent.verticalCenter
                anchors.leftMargin: 36
                width: parent.width * 0.6
                spacing: 10
                Rectangle {
                    implicitWidth: tag.implicitWidth + 18
                    implicitHeight: 26
                    radius: 13
                    color: Theme.alpha("#FFFFFF", 0.16)
                    Text {
                        id: tag
                        anchors.centerIn: parent
                        text: root.hero ? qsTr("CONTINUE WATCHING") : qsTr("WELCOME TO VELA")
                        color: "#FFFFFF"
                        font.pixelSize: 11 * Theme.opt.fontScale
                        font.weight: Font.Bold
                        font.letterSpacing: 1.2
                    }
                }
                Text {
                    text: root.hero ? root.hero.title : qsTr("Every format VLC plays.\nNone of the clutter.")
                    color: "#FFFFFF"
                    font.family: "Inter Display"
                    font.pixelSize: 30 * Theme.opt.fontScale
                    font.weight: Font.Bold
                    font.letterSpacing: -0.6
                    wrapMode: Text.WordWrap
                    maximumLineCount: 2
                    elide: Text.ElideRight
                    Layout.fillWidth: true
                }
                Text {
                    text: root.hero
                        ? (root.hero.length > 0 ? qsTr("%1 left").arg(root.app.fmt(root.hero.length - root.hero.position)) : "")
                        : qsTr("Drop a file anywhere, or press Ctrl+O. Every pixel of this app is themeable.")
                    color: Theme.alpha("#FFFFFF", 0.78)
                    font.pixelSize: 14 * Theme.opt.fontScale
                    wrapMode: Text.WordWrap
                    Layout.fillWidth: true
                }
                Rectangle {
                    visible: !!root.hero && root.hero.length > 0
                    Layout.preferredWidth: 260
                    implicitHeight: 4
                    radius: 2
                    color: Theme.alpha("#FFFFFF", 0.22)
                    Rectangle { width: parent.width * (root.hero ? root.hero.progress : 0); height: 4; radius: 2; color: "#FFFFFF" }
                }
                RowLayout {
                    spacing: 10
                    Layout.topMargin: 8
                    PillButton {
                        text: root.hero ? qsTr("Resume") : qsTr("Open files")
                        icon: root.hero ? "play" : "file-plus"
                        primary: true
                        onClicked: root.hero ? root.app.openUrls([root.hero.url]) : root.app.openFileDialog()
                    }
                    PillButton {
                        visible: !!root.hero
                        text: qsTr("Start over")
                        icon: "refresh"
                        onClicked: {
                            const h = root.hero
                            root.history.record(h.url, h.title, 0, h.length, h.kind === "video")
                            root.queue.playAll([h.url], 0)
                        }
                    }
                }
            }
        }

        // Continue watching -------------------------------------------------------
        ColumnLayout {
            visible: root.history.count > 1
            spacing: 16
            Layout.fillWidth: true
            SectionHeader { title: qsTr("Jump back in"); action: qsTr("Clear"); onActionClicked: root.history.clear(); Layout.fillWidth: true }
            ListView {
                Layout.fillWidth: true
                Layout.preferredHeight: Theme.opt.cardSize * 0.9 / (16 / 9) + 64
                orientation: ListView.Horizontal
                spacing: 18
                clip: true
                model: root.history
                boundsBehavior: Flickable.StopAtBounds
                delegate: MediaCard {
                    required property int index
                    required property url url
                    required title
                    required progress
                    required kind
                    required thumbnail
                    width: Theme.opt.cardSize * 0.9
                    aspect: 16 / 9
                    subtitle: url.toString().startsWith("file:") ? qsTr("%1% watched").arg(Math.round(progress * 100)) : url.toString().split("/")[2]
                    onClicked: root.app.openUrls([url])
                }
            }
        }

        // Recently added ---------------------------------------------------------
        ColumnLayout {
            spacing: 16
            Layout.fillWidth: true
            SectionHeader {
                title: qsTr("Recently added")
                subtitle: root.library.scanning ? qsTr("Scanning your folders…") : qsTr("%1 files in your library").arg(root.library.totalCount)
                action: qsTr("See all")
                onActionClicked: root.app.go("videos")
                Layout.fillWidth: true
            }
            ListView {
                id: recent
                visible: root.library.count > 0
                Layout.fillWidth: true
                Layout.preferredHeight: Theme.opt.cardSize / (16 / 9) + 64
                orientation: ListView.Horizontal
                spacing: 18
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                model: root.library
                delegate: MediaCard {
                    required property int index
                    required property string folder
                    required property string extension
                    required title
                    required kind
                    required thumbnail
                    width: Theme.opt.cardSize
                    subtitle: folder
                    badge: extension
                    aspect: 16 / 9
                    onClicked: root.queue.playAll(root.library.urls(), index)
                }
            }
            // Empty library state
            Rectangle {
                visible: root.library.count === 0 && !root.library.scanning
                Layout.fillWidth: true
                implicitHeight: 150
                radius: Theme.opt.radius + 4
                color: "transparent"
                border.width: 1.5
                border.color: Theme.c.borderStrong
                RowLayout {
                    anchors.centerIn: parent
                    spacing: 16
                    Icon { name: "folder"; size: 34; color: Theme.c.textMuted }
                    ColumnLayout {
                        spacing: 4
                        Text { text: qsTr("Your library is empty"); color: Theme.c.text; font.pixelSize: 16 * Theme.opt.fontScale; font.weight: Font.DemiBold }
                        Text { text: qsTr("Vela looks in Videos, Music and Downloads. Add more folders in Customize → Library."); color: Theme.c.textMuted; font.pixelSize: 13 * Theme.opt.fontScale }
                    }
                    PillButton { text: qsTr("Add folders"); compact: true; onClicked: root.app.go("settings") }
                }
            }
        }
    }
}
