import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Effects
import QtQuick.Layouts
import Vela

// The full-window "now playing" experience.
FocusScope {
    id: root
    property var app
    property VlcPlayer player
    property PlaylistModel queue
    signal closeRequested()

    property bool queueOpen: false
    property bool showRemaining: Theme.opt.showRemaining
    property bool userActive: true
    readonly property bool anySheetOpen: speedSheet.opened || fillSheet.opened || tracksSheet.opened || eqSheet.opened || moreSheet.opened
    readonly property bool chromeVisible: !player.playing || userActive || anySheetOpen || queueOpen || seek.active
    readonly property string style: Theme.opt.controlStyle
    property string fill: Theme.opt.defaultFill

    function wake() { userActive = true; idle.restart() }

    Timer { id: idle; interval: Theme.opt.autoHideMs; onTriggered: root.userActive = false }
    onVisibleChanged: if (visible) wake()

    // ----------------------------------------------------------- backdrop

    Rectangle { anchors.fill: parent; color: Theme.mix(Theme.c.bg, "#000000", 0.75) }

    Item {
        id: stage
        anchors.fill: parent

        // Ambient light: a tiny, heavily blurred copy of the picture spilling
        // into the letterbox — like a bias light behind your TV.
        ShaderEffectSource {
            id: ambientSrc
            sourceItem: video
            live: true
            hideSource: false
            visible: false
            textureSize: Qt.size(48, 27)
        }
        MultiEffect {
            visible: Theme.opt.ambient && player.hasVideo
            anchors.centerIn: video
            width: video.contentRect.width * 1.12
            height: video.contentRect.height * 1.25
            source: ambientSrc
            blurEnabled: true
            blur: 1
            blurMax: 64
            saturation: 0.35
            opacity: Theme.opt.ambientStrength
        }

        VideoItem {
            id: video
            anchors.fill: parent
            player: root.player
            fillMode: root.fill === "fill" ? VideoItem.Fill : root.fill === "stretch" ? VideoItem.Stretch : VideoItem.Fit
            Behavior on zoom { NumberAnimation { duration: 200 } }
        }

        // Audio-only: big artwork over a blurred version of itself.
        Item {
            id: audioStage
            anchors.fill: parent
            visible: player.hasMedia && !player.hasVideo
            readonly property real hue: { let h = 0; const s = player.title || ""; for (let i = 0; i < s.length; ++i) h = (h * 31 + s.charCodeAt(i)) % 360; return h / 360 }

            // The artwork itself, blown up and blurred, becomes the backdrop.
            MultiEffect {
                anchors.fill: parent
                anchors.margins: -80
                source: coverArt
                blurEnabled: true
                blur: 1
                blurMax: 64
                opacity: 0.55
            }

            Rectangle {
                id: coverArt
                width: Math.min(parent.width * 0.42, parent.height * 0.5, 420)
                height: width
                anchors.centerIn: parent
                anchors.verticalCenterOffset: -40
                radius: Theme.opt.radius * 1.6
                gradient: Gradient {
                    GradientStop { position: 0; color: Qt.hsla(audioStage.hue, 0.6, 0.45, 1) }
                    GradientStop { position: 1; color: Qt.hsla((audioStage.hue + 0.15) % 1, 0.65, 0.18, 1) }
                }
                Icon { anchors.centerIn: parent; visible: art.status !== Image.Ready; name: "music"; size: parent.width * 0.3; color: Theme.alpha("#FFFFFF", 0.6) }
                Image {
                    id: art
                    anchors.fill: parent
                    source: player.artworkUrl
                    fillMode: Image.PreserveAspectCrop
                    visible: false
                }
                Rectangle { id: artMask; anchors.fill: parent; radius: parent.radius; visible: false; layer.enabled: true }
                MultiEffect { anchors.fill: parent; source: art; visible: art.status === Image.Ready; maskEnabled: true; maskSource: artMask }
                scale: player.playing ? 1 : 0.94
                Behavior on scale { NumberAnimation { duration: Theme.opt.motion ? 420 : 0; easing.type: Easing.OutBack } }
            }

            // Breathing equaliser bars
            Row {
                id: bars
                anchors.top: coverArt.bottom
                anchors.topMargin: 28
                anchors.horizontalCenter: parent.horizontalCenter
                spacing: 5
                height: 44
                Repeater {
                    model: 24
                    delegate: Rectangle {
                        required property int index
                        width: 5
                        radius: 2.5
                        color: Theme.alpha(Theme.c.accent, 0.85)
                        y: 44 - height
                        height: 6
                        SequentialAnimation on height {
                            running: player.playing && Theme.opt.motion && audioStage.visible
                            loops: Animation.Infinite
                            NumberAnimation { to: 8 + Math.random() * 34; duration: 260 + (index % 5) * 70; easing.type: Easing.InOutSine }
                            NumberAnimation { to: 6 + Math.random() * 10; duration: 300 + (index % 3) * 90; easing.type: Easing.InOutSine }
                        }
                    }
                }
            }

            Column {
                anchors.top: bars.bottom
                anchors.topMargin: 22
                anchors.horizontalCenter: parent.horizontalCenter
                spacing: 6
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: player.title
                    color: "#FFFFFF"
                    font.family: "Inter Display"
                    font.pixelSize: 26 * Theme.opt.fontScale
                    font.weight: Font.Bold
                }
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    visible: text !== ""
                    text: player.artist
                    color: Theme.alpha("#FFFFFF", 0.7)
                    font.pixelSize: 14 * Theme.opt.fontScale
                }
            }
        }
    }

    // ----------------------------------------------------------- scrims

    Rectangle {
        anchors { left: parent.left; right: parent.right; top: parent.top }
        height: 180
        opacity: root.chromeVisible ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: 300 } }
        gradient: Gradient {
            GradientStop { position: 0; color: Theme.alpha("#000000", 0.6) }
            GradientStop { position: 1; color: "transparent" }
        }
    }
    Rectangle {
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
        height: 260
        opacity: root.chromeVisible ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: 300 } }
        gradient: Gradient {
            GradientStop { position: 0; color: "transparent" }
            GradientStop { position: 1; color: Theme.alpha("#000000", 0.7) }
        }
    }

    // ----------------------------------------------------- interactions

    MouseArea {
        anchors.fill: parent
        hoverEnabled: true
        acceptedButtons: Qt.NoButton
        cursorShape: root.chromeVisible ? Qt.ArrowCursor : Qt.BlankCursor
        onPositionChanged: root.wake()
        onWheel: wheel => {
            const step = wheel.angleDelta.y > 0 ? 5 : -5
            player.volume = Math.max(0, Math.min(Theme.opt.volumeBoost ? 200 : 100, player.volume + step))
            root.app.toast(player.volume === 0 ? "volume-mute" : "volume", qsTr("Volume %1%").arg(player.volume))
            root.wake()
        }
    }
    TapHandler {
        id: tap
        onTapped: clickTimer.restart()
        onDoubleTapped: { clickTimer.stop(); root.app.toggleFullScreen() }
    }
    Timer {
        id: clickTimer
        interval: 230
        onTriggered: { player.togglePause(); pulse.flash(player.playing ? "pause" : "play") }
    }

    // Centre pulse when toggling
    Rectangle {
        id: pulse
        anchors.centerIn: parent
        width: 92; height: 92; radius: 46
        color: Theme.alpha("#000000", 0.45)
        opacity: 0
        Icon { id: pulseIcon; anchors.centerIn: parent; size: 40; color: "#FFFFFF" }
        function flash(icon) { pulseIcon.name = icon; pulseAnim.restart() }
        ParallelAnimation {
            id: pulseAnim
            NumberAnimation { target: pulse; property: "opacity"; from: 1; to: 0; duration: 650; easing.type: Easing.InQuad }
            NumberAnimation { target: pulse; property: "scale"; from: 0.8; to: 1.35; duration: 650; easing.type: Easing.OutCubic }
        }
    }

    // Spinner while opening / buffering
    Item {
        anchors.centerIn: parent
        width: 56; height: 56
        visible: player.state === VlcPlayer.Opening || (player.state === VlcPlayer.Buffering && player.buffering < 100)
        Rectangle {
            anchors.fill: parent; radius: 28; color: "transparent"
            border.width: 4; border.color: Theme.alpha("#FFFFFF", 0.15)
        }
        Canvas {
            id: arc
            anchors.fill: parent
            property color c: Theme.c.accent
            onPaint: {
                const ctx = getContext("2d"); ctx.reset()
                ctx.lineWidth = 4; ctx.lineCap = "round"; ctx.strokeStyle = c
                ctx.beginPath(); ctx.arc(28, 28, 26, 0, Math.PI * 0.6); ctx.stroke()
            }
            RotationAnimation on rotation { from: 0; to: 360; duration: 900; loops: Animation.Infinite; running: arc.visible }
        }
    }

    // --------------------------------------------------------------- top bar

    RowLayout {
        id: topBar
        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 20 }
        spacing: 14
        opacity: root.chromeVisible ? 1 : 0
        anchors.topMargin: root.chromeVisible ? 20 : 0
        Behavior on opacity { NumberAnimation { duration: 260 } }
        Behavior on anchors.topMargin { NumberAnimation { duration: Theme.opt.motion ? 300 : 0; easing.type: Easing.OutCubic } }

        IconButton {
            icon: "chevron-left"
            flat: false
            tint: "#FFFFFF"
            tip: qsTr("Back to library")
            onClicked: root.closeRequested()
        }
        ColumnLayout {
            spacing: 2
            Layout.fillWidth: true
            Text {
                text: player.title
                color: "#FFFFFF"
                font.family: "Inter Display"
                font.pixelSize: 19 * Theme.opt.fontScale
                font.weight: Font.Bold
                elide: Text.ElideRight
                Layout.fillWidth: true
            }
            Text {
                text: {
                    const bits = []
                    if (player.artist) bits.push(player.artist)
                    if (player.hasVideo) bits.push(player.videoSize.width + " × " + player.videoSize.height)
                    if (queue.count > 1) bits.push(qsTr("%1 of %2 in queue").arg(queue.currentIndex + 1).arg(queue.count))
                    return bits.join("  ·  ")
                }
                color: Theme.alpha("#FFFFFF", 0.65)
                font.pixelSize: 12.5 * Theme.opt.fontScale
                Layout.fillWidth: true
                elide: Text.ElideRight
            }
        }
        IconButton { icon: "queue"; flat: false; tint: "#FFFFFF"; checked: root.queueOpen; tip: qsTr("Up next"); onClicked: root.queueOpen = !root.queueOpen }
        IconButton { id: moreBtn; icon: "more"; flat: false; tint: "#FFFFFF"; tip: qsTr("More"); onClicked: moreSheet.open() }
    }

    // ------------------------------------------------------------- controls

    Item {
        id: controlsHost
        readonly property bool docked: root.style === "docked"
        readonly property bool minimal: root.style === "minimal"
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: (docked ? 0 : 24) - (root.chromeVisible ? 0 : height + 40)
        width: docked ? parent.width : Math.min(parent.width - 48, minimal ? 720 : 1040)
        height: controls.implicitHeight + (docked ? 34 : 30)
        Behavior on anchors.bottomMargin { NumberAnimation { duration: Theme.opt.motion ? 340 * Theme.opt.motionSpeed : 0; easing.type: Easing.OutCubic } }

        // Swallow clicks on the panel so they don't toggle playback.
        MouseArea { anchors.fill: parent; hoverEnabled: true; onPositionChanged: root.wake() }

        Glass {
            anchors.fill: parent
            backdrop: stage
            radius: controlsHost.docked ? 0 : Theme.opt.radius + 8
            visible: !controlsHost.minimal
        }

        ColumnLayout {
            id: controls
            anchors.fill: parent
            anchors.margins: controlsHost.minimal ? 0 : 18
            anchors.topMargin: controlsHost.minimal ? 0 : 16
            spacing: 10

            RowLayout {
                spacing: 12
                Layout.fillWidth: true
                Text {
                    text: root.app.fmt(seek.pressedOnce ? seek.dragValue * player.length : player.time)
                    color: "#FFFFFF"
                    font.pixelSize: 12.5 * Theme.opt.fontScale
                    font.weight: Font.DemiBold
                    font.features: ({ "tnum": 1 })
                    Layout.preferredWidth: 58
                }
                SeekBar {
                    id: seek
                    property bool pressedOnce: false
                    Layout.fillWidth: true
                    value: player.position
                    length: player.length
                    onScrubbing: pressedOnce = true
                    onSeekRequested: pos => { player.setPosition(pos); pressedOnce = false }
                }
                Text {
                    text: root.showRemaining ? "−" + root.app.fmt(player.length - player.time) : root.app.fmt(player.length)
                    color: Theme.alpha("#FFFFFF", 0.75)
                    font.pixelSize: 12.5 * Theme.opt.fontScale
                    font.weight: Font.DemiBold
                    font.features: ({ "tnum": 1 })
                    horizontalAlignment: Text.AlignRight
                    Layout.preferredWidth: 58
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: root.showRemaining = !root.showRemaining }
                }
            }

            RowLayout {
                spacing: 6
                Layout.fillWidth: true

                // Left: transport
                IconButton { icon: "skip-prev"; tint: "#FFFFFF"; enabled: queue.hasPrevious || player.time > 3000; tip: qsTr("Previous (P)"); onClicked: player.time > 3000 ? player.seek(0) : queue.previous() }
                IconButton { visible: !controlsHost.minimal; icon: "back-10"; tint: "#FFFFFF"; tip: qsTr("Back 10s (←)"); onClicked: player.seekRelative(-10000) }
                IconButton {
                    icon: player.playing ? "pause" : "play"
                    filled: true
                    size: 52
                    iconSize: 24
                    tip: qsTr("Play / pause (Space)")
                    onClicked: player.togglePause()
                }
                IconButton { visible: !controlsHost.minimal; icon: "fwd-10"; tint: "#FFFFFF"; tip: qsTr("Forward 10s (→)"); onClicked: player.seekRelative(10000) }
                IconButton { icon: "skip-next"; tint: "#FFFFFF"; enabled: queue.hasNext; tip: qsTr("Next (N)"); onClicked: queue.next() }

                // Volume with a slider that slides open on hover
                Item {
                    id: volBox
                    Layout.leftMargin: 8
                    implicitWidth: volBtn.width + (expanded ? volSlider.implicitWidth + 8 : 0)
                    implicitHeight: 40
                    clip: true
                    property bool expanded: volHover.hovered || volSlider.pressed
                    Behavior on implicitWidth { NumberAnimation { duration: Theme.opt.motion ? 200 : 0; easing.type: Easing.OutCubic } }
                    HoverHandler { id: volHover }
                    IconButton {
                        id: volBtn
                        icon: player.muted || player.volume === 0 ? "volume-mute" : player.volume < 50 ? "volume-low" : "volume"
                        tint: "#FFFFFF"
                        tip: qsTr("Mute (M)")
                        onClicked: player.muted = !player.muted
                    }
                    VSlider {
                        id: volSlider
                        anchors.left: volBtn.right
                        anchors.leftMargin: 4
                        anchors.verticalCenter: parent.verticalCenter
                        implicitWidth: 110
                        from: 0
                        to: Theme.opt.volumeBoost ? 200 : 100
                        value: player.muted ? 0 : player.volume
                        showValue: true
                        suffix: "%"
                        onMoved: { player.muted = false; player.volume = Math.round(value) }
                    }
                }

                Item { Layout.fillWidth: true }

                // Right: tools
                Rectangle {
                    visible: !controlsHost.minimal
                    implicitWidth: rateText.implicitWidth + 22
                    implicitHeight: 32
                    radius: 16
                    color: rateMa.containsMouse || speedSheet.opened ? Theme.alpha("#FFFFFF", 0.16) : Theme.alpha("#FFFFFF", 0.08)
                    Text { id: rateText; anchors.centerIn: parent; text: player.rate.toFixed(player.rate % 1 === 0 ? 1 : 2) + "×"; color: "#FFFFFF"; font.pixelSize: 13 * Theme.opt.fontScale; font.weight: Font.Bold }
                    MouseArea { id: rateMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: speedSheet.open() }
                }
                IconButton { id: subsBtn; icon: "subtitles"; tint: "#FFFFFF"; checked: player.subtitleTrack >= 0; tip: qsTr("Subtitles & audio (V / B)"); onClicked: tracksSheet.open() }
                IconButton { visible: !controlsHost.minimal; icon: "equalizer"; tint: "#FFFFFF"; checked: player.equalizerEnabled; tip: qsTr("Equalizer"); onClicked: eqSheet.open() }
                IconButton { visible: !controlsHost.minimal && player.hasVideo; icon: "aspect"; tint: "#FFFFFF"; tip: qsTr("Picture"); onClicked: fillSheet.open() }
                IconButton { visible: !controlsHost.minimal && player.hasVideo; icon: "camera"; tint: "#FFFFFF"; tip: qsTr("Snapshot (S)"); onClicked: { const p = player.snapshot(); root.app.toast("camera", p ? qsTr("Saved to Pictures/Vela") : qsTr("Nothing to capture")) } }
                IconButton { icon: root.app.isFullScreen ? "fullscreen-exit" : "fullscreen"; tint: "#FFFFFF"; tip: qsTr("Full screen (F)"); onClicked: root.app.toggleFullScreen() }
            }
        }
    }

    // ------------------------------------------------------------ up next

    Glass {
        id: upNext
        backdrop: stage
        width: 340
        anchors { top: topBar.bottom; bottom: controlsHost.top; topMargin: 16; bottomMargin: 16 }
        x: root.queueOpen ? root.width - width - 20 : root.width + 20
        Behavior on x { NumberAnimation { duration: Theme.opt.motion ? 320 * Theme.opt.motionSpeed : 0; easing.type: Easing.OutCubic } }
        radius: Theme.opt.radius + 6

        MouseArea { anchors.fill: parent; hoverEnabled: true; onPositionChanged: root.wake() }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 14
            spacing: 8
            RowLayout {
                Text { text: qsTr("Up next"); color: Theme.c.text; font.pixelSize: 16 * Theme.opt.fontScale; font.weight: Font.Bold; Layout.fillWidth: true }
                IconButton { icon: "shuffle"; size: 34; checked: queue.shuffle; onClicked: queue.shuffle = !queue.shuffle; tip: qsTr("Shuffle") }
                IconButton { icon: queue.repeat === "one" ? "repeat-one" : "repeat"; size: 34; checked: queue.repeat !== "off"; onClicked: queue.cycleRepeat(); tip: qsTr("Repeat: %1").arg(queue.repeat) }
            }
            ListView {
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                spacing: 2
                model: queue
                currentIndex: queue.currentIndex
                delegate: Rectangle {
                    id: qrow
                    required property int index
                    required property string title
                    required property bool isCurrent
                    required property string kind
                    width: ListView.view.width
                    height: 48
                    radius: Theme.opt.radius * 0.6
                    color: isCurrent ? Theme.c.accentSoft : rowMa.containsMouse ? Theme.alpha(Theme.c.text, 0.07) : "transparent"
                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 10
                        anchors.rightMargin: 10
                        spacing: 10
                        Text { text: qrow.index + 1; color: Theme.c.textMuted; font.pixelSize: 12 * Theme.opt.fontScale; font.features: ({ "tnum": 1 }); Layout.preferredWidth: 20; visible: !qrow.isCurrent }
                        Icon { visible: qrow.isCurrent; name: player.playing ? "sparkle" : "pause"; size: 16; color: Theme.c.accent; Layout.preferredWidth: 20 }
                        Text { text: qrow.title; color: qrow.isCurrent ? Theme.c.accent : Theme.c.text; font.pixelSize: 13.5 * Theme.opt.fontScale; font.weight: qrow.isCurrent ? Font.DemiBold : Font.Normal; elide: Text.ElideRight; Layout.fillWidth: true }
                        Icon { name: qrow.kind === "audio" ? "music" : "film"; size: 14; color: Theme.c.textMuted }
                    }
                    MouseArea { id: rowMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: queue.currentIndex = qrow.index }
                }
            }
        }
    }

    // ------------------------------------------------------------- sheets

    MenuSheet {
        id: speedSheet
        title: qsTr("Playback speed")
        backdrop: stage
        width: 240
        x: controlsHost.x + controlsHost.width - width - 160
        y: controlsHost.y - height - 12
        Repeater {
            model: [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0, 3.0]
            delegate: MenuSheet.Option {
                required property real modelData
                text: modelData === 1 ? qsTr("Normal") : modelData + "×"
                selected: Math.abs(player.rate - modelData) < 0.01
                onTriggered: { player.rate = modelData; speedSheet.close() }
            }
        }
    }

    MenuSheet {
        id: fillSheet
        title: qsTr("Picture")
        backdrop: stage
        width: 260
        x: controlsHost.x + controlsHost.width - width - 60
        y: controlsHost.y - height - 12
        MenuSheet.Option { text: qsTr("Fit"); detail: qsTr("Letterbox"); selected: root.fill === "fit"; onTriggered: root.fill = "fit" }
        MenuSheet.Option { text: qsTr("Fill"); detail: qsTr("Crop edges"); selected: root.fill === "fill"; onTriggered: root.fill = "fill" }
        MenuSheet.Option { text: qsTr("Stretch"); selected: root.fill === "stretch"; onTriggered: root.fill = "stretch" }
        Rectangle { Layout.fillWidth: true; implicitHeight: 1; color: Theme.c.border; Layout.topMargin: 4; Layout.bottomMargin: 4 }
        Repeater {
            model: ["auto", "16:9", "4:3", "21:9", "1:1", "9:16"]
            delegate: MenuSheet.Option {
                required property string modelData
                text: modelData === "auto" ? qsTr("Original aspect") : modelData
                selected: video.aspectRatio === modelData
                onTriggered: video.aspectRatio = modelData
            }
        }
        RowLayout {
            Layout.fillWidth: true
            Layout.margins: 8
            Text { text: qsTr("Zoom"); color: Theme.c.textDim; font.pixelSize: 13 * Theme.opt.fontScale }
            VSlider { Layout.fillWidth: true; from: 1; to: 2.5; value: video.zoom; onMoved: video.zoom = value; showValue: true; decimals: 2; suffix: "×" }
        }
    }

    TracksSheet { id: tracksSheet; player: root.player; app: root.app; backdrop: stage; x: controlsHost.x + controlsHost.width - width - 100; y: controlsHost.y - height - 12 }
    EqualizerSheet { id: eqSheet; player: root.player; backdrop: stage; x: controlsHost.x + controlsHost.width - width - 60; y: controlsHost.y - height - 12 }

    MenuSheet {
        id: moreSheet
        title: qsTr("More")
        backdrop: stage
        width: 280
        x: root.width - width - 20
        y: topBar.y + topBar.height + 8
        MenuSheet.Option { icon: "file-plus"; text: qsTr("Open media…"); detail: "Ctrl+O"; onTriggered: { moreSheet.close(); root.app.openFileDialog() } }
        MenuSheet.Option { icon: "subtitles"; text: qsTr("Load subtitle file…"); onTriggered: { moreSheet.close(); root.app.openSubtitleDialog() } }
        MenuSheet.Option { icon: "camera"; text: qsTr("Take snapshot"); detail: "S"; onTriggered: { moreSheet.close(); const p = player.snapshot(); root.app.toast("camera", p ? qsTr("Saved to Pictures/Vela") : qsTr("Nothing to capture")) } }
        MenuSheet.Option { icon: "pip"; text: qsTr("Keep on top"); selected: root.app.keepOnTop; onTriggered: root.app.keepOnTop = !root.app.keepOnTop }
        MenuSheet.Option { icon: "sun-glow"; text: qsTr("Ambient light"); selected: Theme.opt.ambient; onTriggered: Theme.set("ambient", !Theme.opt.ambient) }
        MenuSheet.Option { icon: "palette"; text: qsTr("Customize player…"); onTriggered: { moreSheet.close(); root.app.go("settings") } }
    }
}
