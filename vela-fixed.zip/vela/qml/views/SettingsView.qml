import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Dialogs
import QtQuick.Layouts
import Vela

Item {
    id: root
    property var app
    property VlcPlayer player
    property HistoryModel history
    readonly property real pad: 40 * Theme.opt.space

    readonly property var sections: [
        { id: "look", t: qsTr("Look & feel"), i: "palette" },
        { id: "player", t: qsTr("Player"), i: "film" },
        { id: "playback", t: qsTr("Playback"), i: "play" },
        { id: "subs", t: qsTr("Subtitles"), i: "subtitles" },
        { id: "library", t: qsTr("Library"), i: "folder" },
        { id: "keys", t: qsTr("Shortcuts"), i: "keyboard" },
        { id: "about", t: qsTr("About"), i: "info" }
    ]
    property string current: "look"

    function scrollTo(id) {
        const target = { look: secLook, player: secPlayer, playback: secPlayback, subs: secSubs, library: secLibrary, keys: secKeys, about: secAbout }[id]
        if (!target) return
        scrollAnim.to = Math.min(flick.contentHeight - flick.height, Math.max(0, target.y - 8))
        scrollAnim.restart()
        current = id
    }

    FolderDialog {
        id: folderDialog
        onAccepted: {
            const f = folderPicker.folders.slice()
            const p = decodeURIComponent(selectedFolder.toString().replace("file://", ""))
            if (f.indexOf(p) < 0) f.push(p)
            folderPicker.folders = f
        }
    }
    FileDialog { id: themeImport; nameFilters: [qsTr("Vela theme (*.json)")]; onAccepted: Theme.importTheme(selectedFile) ? root.app.toast("palette", qsTr("Theme imported")) : root.app.toast("info", qsTr("That file isn't a valid theme")) }
    ColorDialog { id: colorDialog; selectedColor: Theme.c.accent; onAccepted: Theme.set("accent", selectedColor.toString()) }

    LibraryModel { id: folderPicker; kind: "video" }

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: root.pad
        anchors.topMargin: 64
        spacing: 32

        // Section rail
        ColumnLayout {
            Layout.alignment: Qt.AlignTop
            Layout.preferredWidth: 200
            spacing: 4
            Text {
                text: qsTr("Customize")
                color: Theme.c.text
                font.family: "Inter Display"
                font.pixelSize: 34 * Theme.opt.fontScale
                font.weight: Font.Bold
                font.letterSpacing: -0.8
                Layout.bottomMargin: 16
            }
            Repeater {
                model: root.sections
                delegate: SidebarItem {
                    required property var modelData
                    icon: modelData.i
                    text: modelData.t
                    active: root.current === modelData.id
                    onClicked: root.scrollTo(modelData.id)
                }
            }
            Item { implicitHeight: 16 }
            PillButton { text: qsTr("Reset to theme defaults"); icon: "refresh"; compact: true; onClicked: { Theme.resetOverrides(); root.app.toast("refresh", qsTr("Customizations reset")) } }
        }

        Flickable {
            id: flick
            Layout.fillWidth: true
            Layout.fillHeight: true
            contentHeight: content.implicitHeight + 120
            clip: true
            boundsBehavior: Flickable.StopAtBounds
            ScrollBar.vertical: ScrollBar {}
            NumberAnimation { id: scrollAnim; target: flick; property: "contentY"; duration: Theme.opt.motion ? 420 : 0; easing.type: Easing.OutCubic }
            onContentYChanged: if (!scrollAnim.running) {
                const all = [secLook, secPlayer, secPlayback, secSubs, secLibrary, secKeys, secAbout]
                for (let i = all.length - 1; i >= 0; --i) if (all[i].y - 80 <= contentY) { root.current = root.sections[i].id; break }
            }

            ColumnLayout {
                id: content
                width: flick.width - root.pad
                spacing: 30

                // =============================================== LOOK & FEEL
                Card {
                    id: secLook
                    title: qsTr("Look & feel")
                    subtitle: qsTr("Pick a theme, then make it yours. Every change is live.")

                    // Theme gallery + live preview
                    RowLayout {
                    Layout.fillWidth: true
                    Layout.margins: 18
                    spacing: 18
                    Flow {
                        Layout.fillWidth: true
                        Layout.alignment: Qt.AlignTop
                        spacing: 14
                        Repeater {
                            model: Theme.themes
                            delegate: Item {
                                id: tcard
                                required property var modelData
                                readonly property bool on: Theme.currentId === modelData.id
                                width: 172; height: 128
                                Rectangle {
                                    anchors.fill: parent
                                    radius: 16
                                    color: tcard.modelData.bg
                                    border.width: tcard.on ? 2.5 : 1
                                    border.color: tcard.on ? Theme.c.accent : Theme.c.border
                                    scale: tma.containsMouse && !tcard.on ? 1.03 : 1
                                    Behavior on scale { NumberAnimation { duration: 160 } }
                                    // mini UI preview
                                    Rectangle { x: 12; y: 12; width: 36; height: 72; radius: 7; color: tcard.modelData.surface }
                                    Rectangle { x: 56; y: 12; width: parent.width - 68; height: 46; radius: 8; color: tcard.modelData.surface
                                        Rectangle { anchors.centerIn: parent; width: 18; height: 18; radius: 9; color: tcard.modelData.accent } }
                                    Rectangle { x: 56; y: 64; width: (parent.width - 68) * 0.55; height: 6; radius: 3; color: tcard.modelData.accent }
                                    Rectangle { x: 56; y: 76; width: (parent.width - 68) * 0.8; height: 6; radius: 3; color: tcard.modelData.surface }
                                    Text {
                                        x: 12; y: parent.height - 30
                                        text: tcard.modelData.name
                                        color: tcard.modelData.text
                                        font.pixelSize: 13 * Theme.opt.fontScale
                                        font.weight: Font.DemiBold
                                    }
                                    Rectangle {
                                        visible: tcard.on
                                        anchors { right: parent.right; bottom: parent.bottom; margins: 10 }
                                        width: 22; height: 22; radius: 11
                                        color: Theme.c.accent
                                        Icon { anchors.centerIn: parent; name: "check"; size: 14; color: Theme.c.onAccent }
                                    }
                                    Text {
                                        visible: !tcard.modelData.builtin
                                        anchors { right: parent.right; top: parent.top; margins: 10 }
                                        text: qsTr("CUSTOM"); color: tcard.modelData.accent; font.pixelSize: 9 * Theme.opt.fontScale; font.weight: Font.Bold; font.letterSpacing: 1
                                    }
                                }
                                MouseArea { id: tma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: Theme.currentId = tcard.modelData.id }
                            }
                        }
                    }

                    // A tiny player that restyles live as you tweak things.
                    ColumnLayout {
                        visible: content.width > 900
                        Layout.preferredWidth: 340
                        Layout.alignment: Qt.AlignTop
                        spacing: 8
                        Text { text: qsTr("LIVE PREVIEW"); color: Theme.c.textMuted; font.pixelSize: 11 * Theme.opt.fontScale; font.weight: Font.Bold; font.letterSpacing: 1.1 }
                        Item {
                            Layout.fillWidth: true
                            Layout.preferredHeight: width * 9 / 16
                            Rectangle {
                                id: previewScene
                                anchors.fill: parent
                                radius: Theme.opt.radius
                                gradient: Gradient {
                                    GradientStop { position: 0; color: Theme.mix(Theme.c.accent, "#000000", 0.75) }
                                    GradientStop { position: 0.7; color: Theme.mix(Theme.c.accent, "#000000", 0.35) }
                                    GradientStop { position: 1; color: Theme.mix(Theme.c.accentHi, "#FFFFFF", 0.2) }
                                }
                                Rectangle {
                                    width: parent.height * 0.36; height: width; radius: width / 2
                                    x: parent.width * 0.6; y: parent.height * 0.32
                                    color: Theme.mix(Theme.c.accentHi, "#FFFFFF", 0.6)
                                }
                                VideoItem {
                                    anchors.fill: parent
                                    player: root.player
                                    fillMode: VideoItem.Fill
                                    visible: root.player.hasVideo
                                }
                            }
                            Glass {
                                backdrop: previewScene
                                anchors { left: parent.left; right: parent.right; bottom: parent.bottom; margins: 12 }
                                height: 52
                                radius: Theme.opt.radius
                                RowLayout {
                                    anchors.fill: parent
                                    anchors.leftMargin: 10
                                    anchors.rightMargin: 14
                                    spacing: 12
                                    IconButton { icon: root.player.playing ? "pause" : "play"; filled: true; size: 34; iconSize: 16; onClicked: root.player.togglePause() }
                                    SeekBar { Layout.fillWidth: true; value: root.player.hasMedia ? root.player.position : 0.55; length: root.player.length; onSeekRequested: pos => root.player.setPosition(pos) }
                                }
                            }
                        }
                    }
                    }

                    SettingRow {
                        title: qsTr("Accent colour")
                        description: qsTr("Tints buttons, progress, highlights and the ambient glow.")
                        icon: "sparkle"
                        RowLayout {
                            spacing: 8
                            Repeater {
                                model: Theme.accentPresets
                                delegate: Rectangle {
                                    required property string modelData
                                    readonly property bool on: Theme.overrides.accent === modelData
                                    width: 26; height: 26; radius: 13
                                    color: modelData
                                    border.width: on ? 3 : 0
                                    border.color: Theme.c.text
                                    scale: am.containsMouse ? 1.15 : 1
                                    Behavior on scale { NumberAnimation { duration: 120 } }
                                    MouseArea { id: am; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: Theme.set("accent", parent.modelData) }
                                }
                            }
                            IconButton { icon: "plus"; size: 28; iconSize: 15; flat: false; tip: qsTr("Custom colour…"); onClicked: colorDialog.open() }
                            PillButton { text: qsTr("Theme"); compact: true; selected: Theme.overrides.accent === undefined; onClicked: Theme.unset("accent") }
                        }
                    }
                    SettingRow {
                        title: qsTr("Corner radius"); description: qsTr("From razor-sharp to soft and bubbly."); icon: "maximize"
                        VSlider { from: 0; to: 30; stepSize: 1; value: Theme.opt.radius; showValue: true; suffix: "px"; onMoved: Theme.set("radius", value) }
                    }
                    SettingRow {
                        title: qsTr("Glass blur"); description: qsTr("How frosted the player panels are. 0 turns blur off (faster on old GPUs)."); icon: "layers"
                        VSlider { from: 0; to: 96; stepSize: 1; value: Theme.opt.blur; showValue: true; onMoved: Theme.set("blur", value) }
                    }
                    SettingRow {
                        title: qsTr("Glass tint"); description: qsTr("Opacity of the tint over blurred surfaces."); icon: "sun-glow"
                        VSlider { from: 0.2; to: 1; value: Theme.opt.glassOpacity; showValue: true; decimals: 2; onMoved: Theme.set("glassOpacity", value) }
                    }
                    SettingRow {
                        title: qsTr("Density"); description: qsTr("Spacing between everything."); icon: "tune"
                        Segmented { options: [["compact", qsTr("Compact")], ["comfortable", qsTr("Cozy")], ["spacious", qsTr("Roomy")]]; value: Theme.opt.density; onPicked: v => Theme.set("density", v) }
                    }
                    SettingRow {
                        title: qsTr("Text size"); icon: "info"
                        VSlider { from: 0.85; to: 1.3; value: Theme.opt.fontScale; showValue: true; decimals: 2; suffix: "×"; onMoved: Theme.set("fontScale", value) }
                    }
                    SettingRow {
                        title: qsTr("Font"); description: qsTr("Inter ships with Vela. Type any installed family."); icon: "keyboard"
                        Rectangle {
                            implicitWidth: 200; implicitHeight: 36; radius: 10
                            color: Theme.c.surfaceHi; border.color: fontField.activeFocus ? Theme.c.accent : Theme.c.border
                            TextField {
                                id: fontField
                                anchors.fill: parent; anchors.leftMargin: 8
                                text: Theme.opt.fontFamily
                                color: Theme.c.text; background: null; font.pixelSize: 13 * Theme.opt.fontScale
                                onEditingFinished: if (text.trim()) Theme.set("fontFamily", text.trim())
                            }
                        }
                    }
                    SettingRow {
                        title: qsTr("Animations"); description: qsTr("Springy transitions everywhere. Turn off for reduced motion."); icon: "sparkle"
                        Toggle { checked: Theme.opt.motion; onToggled: on => Theme.set("motion", on) }
                    }
                    SettingRow {
                        title: qsTr("Animation speed"); icon: "clock"
                        VSlider { enabled: Theme.opt.motion; from: 0.5; to: 2; value: Theme.opt.motionSpeed; showValue: true; decimals: 1; suffix: "×"; onMoved: Theme.set("motionSpeed", value) }
                    }
                    SettingRow {
                        title: qsTr("Sidebar"); icon: "sidebar"
                        Segmented { options: [["expanded", qsTr("Full")], ["compact", qsTr("Icons")]]; value: Theme.opt.sidebar; onPicked: v => Theme.set("sidebar", v) }
                    }
                    SettingRow {
                        title: qsTr("Window frame"); description: qsTr("Vela's own title bar, or your desktop's."); icon: "maximize"
                        Segmented { options: [["custom", qsTr("Vela")], ["system", qsTr("System")]]; value: Theme.opt.titlebar; onPicked: v => Theme.set("titlebar", v) }
                    }
                    SettingRow {
                        title: qsTr("Accent glow"); description: qsTr("Soft light under the play button."); icon: "sun-glow"
                        Toggle { checked: Theme.opt.accentGlow; onToggled: on => Theme.set("accentGlow", on) }
                    }
                    SettingRow {
                        title: qsTr("Film grain"); description: qsTr("A whisper of texture over the interface."); icon: "film"
                        Toggle { checked: Theme.opt.grain; onToggled: on => Theme.set("grain", on) }
                    }

                    // Theme files
                    RowLayout {
                        Layout.margins: 18
                        spacing: 10
                        PillButton {
                            text: qsTr("Save as new theme")
                            icon: "export"
                            primary: true
                            onClicked: {
                                const p = Theme.exportTheme(qsTr("My %1").arg(Theme.currentName))
                                root.app.toast("palette", p ? qsTr("Saved — edit it in the themes folder") : qsTr("Couldn't save theme"))
                            }
                        }
                        PillButton { text: qsTr("Import theme…"); icon: "import"; onClicked: themeImport.open() }
                        PillButton { text: qsTr("Open themes folder"); icon: "folder"; onClicked: Theme.openThemesFolder() }
                    }
                    Text {
                        Layout.leftMargin: 18; Layout.rightMargin: 18; Layout.bottomMargin: 16
                        Layout.fillWidth: true
                        wrapMode: Text.WordWrap
                        text: qsTr("Themes are plain JSON in %1. Edit one in any text editor and Vela reloads it the moment you save.").arg(Theme.themesFolder)
                        color: Theme.c.textMuted
                        font.pixelSize: 12 * Theme.opt.fontScale
                    }
                }

                // =============================================== PLAYER
                Card {
                    id: secPlayer
                    title: qsTr("Player")
                    subtitle: qsTr("How the now-playing screen looks and behaves.")

                    SettingRow {
                        title: qsTr("Control style"); icon: "tune"
                        description: qsTr("Floating glass card, a full-width dock, or the bare minimum.")
                        Segmented { options: [["floating", qsTr("Floating")], ["docked", qsTr("Docked")], ["minimal", qsTr("Minimal")]]; value: Theme.opt.controlStyle; onPicked: v => Theme.set("controlStyle", v) }
                    }
                    SettingRow {
                        title: qsTr("Timeline"); icon: "clock"
                        Segmented { options: [["thin", qsTr("Thin")], ["thick", qsTr("Bold")]]; value: Theme.opt.seekStyle; onPicked: v => Theme.set("seekStyle", v) }
                    }
                    SettingRow {
                        title: qsTr("Ambient light"); icon: "sun-glow"
                        description: qsTr("Let the picture's colours glow into the letterbox, like bias lighting.")
                        Toggle { checked: Theme.opt.ambient; onToggled: on => Theme.set("ambient", on) }
                    }
                    SettingRow {
                        title: qsTr("Ambient intensity"); icon: "sparkle"
                        VSlider { enabled: Theme.opt.ambient; from: 0.1; to: 1; value: Theme.opt.ambientStrength; showValue: true; decimals: 2; onMoved: Theme.set("ambientStrength", value) }
                    }
                    SettingRow {
                        title: qsTr("Hide controls after"); icon: "clock"
                        VSlider { from: 1000; to: 8000; stepSize: 100; value: Theme.opt.autoHideMs; showValue: true; decimals: 0; suffix: " ms"; onMoved: Theme.set("autoHideMs", value) }
                    }
                    SettingRow {
                        title: qsTr("Default picture"); icon: "aspect"
                        Segmented { options: [["fit", qsTr("Fit")], ["fill", qsTr("Fill")], ["stretch", qsTr("Stretch")]]; value: Theme.opt.defaultFill; onPicked: v => Theme.set("defaultFill", v) }
                    }
                    SettingRow {
                        title: qsTr("Show time remaining"); icon: "clock"
                        Toggle { checked: Theme.opt.showRemaining; onToggled: on => Theme.set("showRemaining", on) }
                    }
                    SettingRow {
                        title: qsTr("Open player when playback starts"); icon: "fullscreen"
                        Toggle { checked: Theme.opt.autoOpenPlayer; onToggled: on => Theme.set("autoOpenPlayer", on) }
                    }
                }

                // =============================================== PLAYBACK
                Card {
                    id: secPlayback
                    title: qsTr("Playback")
                    SettingRow {
                        title: qsTr("Hardware decoding"); icon: "speed"
                        description: qsTr("VA-API / VDPAU / NVDEC via libVLC. Applies to the next file.")
                        Toggle { checked: root.player.hardwareDecoding; onToggled: on => root.player.hardwareDecoding = on }
                    }
                    SettingRow {
                        title: qsTr("Resume where you left off"); icon: "clock"
                        description: qsTr("Remembers your position and fills “Jump back in”.")
                        Toggle { checked: root.history.enabled; onToggled: on => root.history.enabled = on }
                    }
                    SettingRow {
                        title: qsTr("Volume boost"); icon: "volume"
                        description: qsTr("Allow up to 200%. Can distort; use with care.")
                        Toggle { checked: Theme.opt.volumeBoost; onToggled: on => Theme.set("volumeBoost", on) }
                    }
                    SettingRow {
                        title: qsTr("Clear watch history"); icon: "trash"
                        PillButton { text: qsTr("Clear"); compact: true; onClicked: { root.history.clear(); root.app.toast("trash", qsTr("History cleared")) } }
                    }
                }

                // =============================================== SUBTITLES
                Card {
                    id: secSubs
                    title: qsTr("Subtitles")
                    subtitle: qsTr("Size applies to the next file; colour and outline after a restart.")
                    SettingRow {
                        title: qsTr("Size"); icon: "subtitles"
                        VSlider { from: 50; to: 250; stepSize: 5; value: root.player.subtitleScale; showValue: true; suffix: "%"; onMoved: root.player.subtitleScale = value }
                    }
                    SettingRow {
                        title: qsTr("Colour"); icon: "palette"
                        RowLayout {
                            spacing: 8
                            Repeater {
                                model: ["#FFFFFF", "#FFF5B8", "#B8F5FF", "#C6F432", "#FFC145"]
                                delegate: Rectangle {
                                    required property string modelData
                                    width: 26; height: 26; radius: 13; color: modelData
                                    border.width: (Theme.settingsRevision, Theme.setting("subtitles/color", "#FFFFFF")) === modelData ? 3 : 1
                                    border.color: Theme.c.accent
                                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: Theme.setSetting("subtitles/color", parent.modelData) }
                                }
                            }
                        }
                    }
                    SettingRow {
                        title: qsTr("Background box"); icon: "aspect"
                        VSlider { from: 0; to: 255; stepSize: 5; value: Number(Theme.setting("subtitles/backgroundOpacity", 0)); onMoved: Theme.setSetting("subtitles/backgroundOpacity", value) }
                    }
                    SettingRow {
                        title: qsTr("Outline"); icon: "maximize"
                        VSlider { from: 0; to: 6; stepSize: 1; value: Number(Theme.setting("subtitles/outline", 4)); showValue: true; onMoved: Theme.setSetting("subtitles/outline", value) }
                    }
                }

                // =============================================== LIBRARY
                Card {
                    id: secLibrary
                    title: qsTr("Library")
                    subtitle: qsTr("Folders Vela scans for videos and music.")
                    Repeater {
                        model: folderPicker.folders
                        delegate: SettingRow {
                            id: folderRow
                            required property string modelData
                            required property int index
                            title: modelData.split("/").pop()
                            description: modelData
                            icon: "folder"
                            IconButton {
                                icon: "trash"; size: 34; iconSize: 16; tip: qsTr("Remove")
                                onClicked: { const f = folderPicker.folders.slice(); f.splice(folderRow.index, 1); folderPicker.folders = f }
                            }
                        }
                    }
                    RowLayout {
                        Layout.margins: 18
                        spacing: 10
                        PillButton { text: qsTr("Add folder…"); icon: "plus"; primary: true; onClicked: folderDialog.open() }
                        PillButton { text: qsTr("Restore defaults"); icon: "refresh"; onClicked: { folderPicker.folders = folderPicker.defaultFolders() } }
                    }
                }

                // =============================================== SHORTCUTS
                Card {
                    id: secKeys
                    title: qsTr("Shortcuts")
                    GridLayout {
                        Layout.margins: 18
                        Layout.fillWidth: true
                        columns: 2
                        columnSpacing: 40
                        rowSpacing: 10
                        Repeater {
                            model: [
                                ["Space / K", qsTr("Play / pause")], ["F / double-click", qsTr("Full screen")],
                                ["← / →", qsTr("Seek 10 seconds")], ["Shift + ← / →", qsTr("Seek 1 minute")],
                                ["J / L", qsTr("Seek 10 seconds")], [".", qsTr("Next frame")],
                                ["↑ / ↓  · scroll", qsTr("Volume")], ["M", qsTr("Mute")],
                                ["N / P", qsTr("Next / previous")], ["[ / ] / =", qsTr("Slower / faster / normal")],
                                ["V", qsTr("Cycle subtitles")], ["B", qsTr("Cycle audio track")],
                                ["S", qsTr("Snapshot")], ["Ctrl + O", qsTr("Open files")],
                                ["Ctrl + L", qsTr("Open a link")], ["Ctrl + ,", qsTr("Customize")],
                                ["Esc", qsTr("Leave full screen / player")], ["Ctrl + Q", qsTr("Quit")]
                            ]
                            delegate: RowLayout {
                                id: keyRow
                                required property var modelData
                                spacing: 12
                                Layout.fillWidth: true
                                Rectangle {
                                    implicitWidth: keyText.implicitWidth + 16; implicitHeight: 26; radius: 7
                                    color: Theme.c.surfaceHi; border.color: Theme.c.borderStrong
                                    Text { id: keyText; anchors.centerIn: parent; text: keyRow.modelData[0]; color: Theme.c.text; font.pixelSize: 12 * Theme.opt.fontScale; font.weight: Font.DemiBold; font.family: "monospace" }
                                }
                                Text { text: keyRow.modelData[1]; color: Theme.c.textDim; font.pixelSize: 13 * Theme.opt.fontScale; Layout.fillWidth: true }
                            }
                        }
                    }
                }

                // =============================================== ABOUT
                Card {
                    id: secAbout
                    title: qsTr("About")
                    RowLayout {
                        Layout.margins: 18
                        spacing: 18
                        Image { source: "qrc:/qt/qml/Vela/branding/vela.svg"; sourceSize: Qt.size(84, 84) }
                        ColumnLayout {
                            spacing: 4
                            Text { text: "Vela " + Qt.application.version; color: Theme.c.text; font.family: "Inter Display"; font.pixelSize: 24 * Theme.opt.fontScale; font.weight: Font.Bold }
                            Text { text: qsTr("A beautiful, customizable media player built on libVLC %1.").arg(root.player.vlcVersion); color: Theme.c.textDim; font.pixelSize: 13 * Theme.opt.fontScale }
                            Text { text: qsTr("Free software under the GNU GPL v3. Not affiliated with VideoLAN; VLC is a trademark of VideoLAN."); color: Theme.c.textMuted; font.pixelSize: 12 * Theme.opt.fontScale; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                        }
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- bits

    component Card: Rectangle {
        id: card
        property string title
        property string subtitle
        default property alias body: bodyCol.data
        Layout.fillWidth: true
        implicitHeight: cardCol.implicitHeight + 8
        radius: Theme.opt.radius + 6
        color: Theme.c.surface
        border.color: Theme.c.border
        ColumnLayout {
            id: cardCol
            width: parent.width
            spacing: 0
            ColumnLayout {
                Layout.margins: 18
                Layout.bottomMargin: 6
                spacing: 4
                Text { text: card.title; color: Theme.c.text; font.pixelSize: 18 * Theme.opt.fontScale; font.weight: Font.Bold }
                Text { visible: card.subtitle !== ""; text: card.subtitle; color: Theme.c.textMuted; font.pixelSize: 13 * Theme.opt.fontScale }
            }
            ColumnLayout { id: bodyCol; Layout.fillWidth: true; spacing: 0 }
        }
    }

    component Segmented: Rectangle {
        id: seg
        property var options: []   // [[value, label], …]
        property string value
        signal picked(string v)
        implicitWidth: segRow.implicitWidth + 8
        implicitHeight: 36
        radius: Math.min(18, Theme.opt.radius)
        color: Theme.alpha(Theme.c.text, 0.06)
        Row {
            id: segRow
            anchors.centerIn: parent
            spacing: 2
            Repeater {
                model: seg.options
                delegate: Rectangle {
                    id: segItem
                    required property var modelData
                    readonly property bool on: seg.value === modelData[0]
                    width: segLabel.implicitWidth + 24
                    height: 28
                    radius: Math.min(14, Theme.opt.radius * 0.8)
                    color: on ? Theme.c.accent : segMa.containsMouse ? Theme.alpha(Theme.c.text, 0.08) : "transparent"
                    Behavior on color { ColorAnimation { duration: 140 } }
                    Text { id: segLabel; anchors.centerIn: parent; text: segItem.modelData[1]; color: segItem.on ? Theme.c.onAccent : Theme.c.textDim; font.pixelSize: 13 * Theme.opt.fontScale; font.weight: Font.DemiBold }
                    MouseArea { id: segMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: seg.picked(segItem.modelData[0]) }
                }
            }
        }
    }
}
