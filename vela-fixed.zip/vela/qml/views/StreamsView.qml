import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import Vela

Item {
    id: root
    property var app
    property HistoryModel history
    readonly property real pad: 40 * Theme.opt.space

    function go() {
        const t = field.text.trim()
        if (!t) return
        const url = /^[a-z][a-z0-9+.-]*:\/\//i.test(t) ? t : "https://" + t
        root.app.openUrls([url])
        field.text = ""
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.leftMargin: root.pad
        anchors.rightMargin: root.pad
        anchors.topMargin: 64
        spacing: 26 * Theme.opt.space

        ColumnLayout {
            spacing: 4
            Text { text: qsTr("Streams"); color: Theme.c.text; font.family: "Inter Display"; font.pixelSize: 34 * Theme.opt.fontScale; font.weight: Font.Bold; font.letterSpacing: -0.8 }
            Text { text: qsTr("Anything libVLC can open: HTTP(S), HLS, DASH, RTSP, RTMP, UDP, SMB, FTP, DVD/Blu-ray paths…"); color: Theme.c.textMuted; font.pixelSize: 13 * Theme.opt.fontScale }
        }

        Rectangle {
            Layout.fillWidth: true
            Layout.maximumWidth: 860
            implicitHeight: 64
            radius: Theme.opt.radius + 4
            color: Theme.c.surface
            border.color: field.activeFocus ? Theme.c.accent : Theme.c.border
            border.width: field.activeFocus ? 2 : 1
            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: 20
                anchors.rightMargin: 10
                spacing: 12
                Icon { name: "link"; size: 22; color: field.activeFocus ? Theme.c.accent : Theme.c.textMuted }
                TextField {
                    id: field
                    Layout.fillWidth: true
                    placeholderText: qsTr("Paste a link — e.g. https://example.com/live/stream.m3u8")
                    placeholderTextColor: Theme.c.textMuted
                    color: Theme.c.text
                    font.pixelSize: 16 * Theme.opt.fontScale
                    background: null
                    selectByMouse: true
                    onAccepted: root.go()
                }
                PillButton { text: qsTr("Play"); icon: "play"; primary: true; onClicked: root.go() }
            }
        }

        SectionHeader { title: qsTr("Recent streams"); Layout.fillWidth: true; Layout.maximumWidth: 860 }

        ListView {
            id: recent
            Layout.fillWidth: true
            Layout.maximumWidth: 860
            Layout.fillHeight: true
            clip: true
            spacing: 4
            model: root.history
            delegate: Rectangle {
                id: r
                required property url url
                required property string title
                required property var played
                readonly property bool isStream: !url.toString().startsWith("file:")
                width: recent.width
                height: isStream ? 58 : 0
                visible: isStream
                radius: Theme.opt.radius * 0.7
                color: ma.containsMouse ? Theme.c.surfaceHi : Theme.c.surface
                border.color: Theme.c.border
                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 16
                    anchors.rightMargin: 16
                    spacing: 14
                    Icon { name: "globe"; size: 20; color: Theme.c.accent }
                    ColumnLayout {
                        spacing: 2
                        Layout.fillWidth: true
                        Text { text: r.title; color: Theme.c.text; font.pixelSize: 14 * Theme.opt.fontScale; font.weight: Font.DemiBold; elide: Text.ElideRight; Layout.fillWidth: true }
                        Text { text: r.url.toString(); color: Theme.c.textMuted; font.pixelSize: 12 * Theme.opt.fontScale; elide: Text.ElideMiddle; Layout.fillWidth: true }
                    }
                    Text { text: Qt.formatDateTime(r.played, "d MMM, hh:mm"); color: Theme.c.textMuted; font.pixelSize: 12 * Theme.opt.fontScale }
                }
                MouseArea { id: ma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: root.app.openUrls([r.url]) }
            }
        }
    }
}
