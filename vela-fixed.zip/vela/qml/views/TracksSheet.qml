import QtQuick
import QtQuick.Layouts
import Vela

MenuSheet {
    id: root
    property VlcPlayer player
    property var app
    title: qsTr("Subtitles")
    width: 320

    Repeater {
        model: root.player ? root.player.subtitleTracks : []
        delegate: MenuSheet.Option {
            required property var modelData
            text: modelData.name
            selected: root.player.subtitleTrack === modelData.id
            onTriggered: root.player.subtitleTrack = modelData.id
        }
    }
    MenuSheet.Option {
        visible: root.player && root.player.subtitleTracks.length === 0
        text: qsTr("No embedded subtitles")
        enabled: false
        opacity: 0.6
    }
    MenuSheet.Option { icon: "plus"; text: qsTr("Load from file…"); onTriggered: { root.close(); root.app.openSubtitleDialog() } }

    DelayRow { label: qsTr("Subtitle delay"); value: root.player ? root.player.subtitleDelay : 0; onAdjust: d => root.player.subtitleDelay += d; onReset: root.player.subtitleDelay = 0 }

    Rectangle { Layout.fillWidth: true; implicitHeight: 1; color: Theme.c.border; Layout.topMargin: 6; Layout.bottomMargin: 6 }
    Text {
        text: qsTr("AUDIO")
        color: Theme.c.textMuted
        font.pixelSize: 11 * Theme.opt.fontScale
        font.weight: Font.Bold
        font.letterSpacing: 1.1
        Layout.leftMargin: 10
        Layout.bottomMargin: 4
    }
    Repeater {
        model: root.player ? root.player.audioTracks.filter(t => t.id >= 0) : []
        delegate: MenuSheet.Option {
            required property var modelData
            text: modelData.name
            selected: root.player.audioTrack === modelData.id
            onTriggered: root.player.audioTrack = modelData.id
        }
    }
    DelayRow { label: qsTr("Audio delay"); value: root.player ? root.player.audioDelay : 0; onAdjust: d => root.player.audioDelay += d; onReset: root.player.audioDelay = 0 }

    component DelayRow: RowLayout {
        id: dr
        property string label
        property int value
        signal adjust(int d)
        signal reset()
        Layout.fillWidth: true
        Layout.leftMargin: 10
        Layout.rightMargin: 6
        Layout.topMargin: 4
        spacing: 6
        Text { text: dr.label; color: Theme.c.textDim; font.pixelSize: 13 * Theme.opt.fontScale; Layout.fillWidth: true }
        IconButton { icon: "minimize"; size: 30; iconSize: 14; flat: false; onClicked: dr.adjust(-50) }
        Text {
            text: (dr.value > 0 ? "+" : "") + dr.value + " ms"
            color: dr.value === 0 ? Theme.c.textMuted : Theme.c.accent
            font.pixelSize: 12.5 * Theme.opt.fontScale
            font.weight: Font.DemiBold
            font.features: ({ "tnum": 1 })
            horizontalAlignment: Text.AlignHCenter
            Layout.preferredWidth: 64
            MouseArea { anchors.fill: parent; onDoubleClicked: dr.reset() }
        }
        IconButton { icon: "plus"; size: 30; iconSize: 14; flat: false; onClicked: dr.adjust(50) }
    }
}
