// SPDX-License-Identifier: GPL-3.0-or-later
//
// Vela — a beautiful, deeply customizable media player built on libVLC.
// Copyright (C) 2026 The Vela contributors
//
// This program is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version.

#include <QCommandLineParser>
#include <QDir>
#include <QFileInfo>
#include <QFontDatabase>
#include <QGuiApplication>
#include <QIcon>
#include <QQmlApplicationEngine>
#include <QQuickStyle>
#include <QQuickWindow>
#include <QUrl>

#include "thememanager.h"

int main(int argc, char *argv[])
{
    // libVLC + Qt share the process; make sure Xlib is thread-safe on X11.
    qputenv("QT_QUICK_CONTROLS_HOVER_ENABLED", "1");

    QGuiApplication app(argc, argv);
    QGuiApplication::setApplicationName("Vela");
    QGuiApplication::setOrganizationName("Vela");
    QGuiApplication::setApplicationDisplayName("Vela");
    QGuiApplication::setApplicationVersion(VELA_VERSION);
    QGuiApplication::setDesktopFileName(VELA_APP_ID);
    QGuiApplication::setWindowIcon(QIcon::fromTheme(VELA_APP_ID, QIcon(":/qt/qml/Vela/branding/vela.svg")));

    QQuickStyle::setStyle("Basic");

    const QDir fonts(":/qt/qml/Vela/fonts");
    for (const QString &f : fonts.entryList({"*.otf", "*.ttf"}))
        QFontDatabase::addApplicationFont(fonts.filePath(f));
    QFont base("Inter");
    base.setHintingPreference(QFont::PreferNoHinting);
    base.setStyleStrategy(QFont::PreferAntialias);
    QGuiApplication::setFont(base);

    QCommandLineParser parser;
    parser.setApplicationDescription("Vela media player");
    parser.addHelpOption();
    parser.addVersionOption();
    parser.addPositionalArgument("media", "Files or URLs to play.", "[media...]");
    parser.process(app);

    QVariantList startup;
    for (const QString &arg : parser.positionalArguments()) {
        const QUrl url = QFileInfo::exists(arg) ? QUrl::fromLocalFile(QFileInfo(arg).absoluteFilePath())
                                                : QUrl::fromUserInput(arg);
        if (url.isValid())
            startup << url;
    }

    QQmlApplicationEngine engine;
    engine.setInitialProperties({{"startupUrls", startup}});
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed, &app,
                     [] { QCoreApplication::exit(1); }, Qt::QueuedConnection);
    engine.loadFromModule("Vela", "Main");

    // Plain QML Text items don't inherit the window font, so apply the user's
    // chosen family to the application font and keep it in sync with Customize.
    if (auto *theme = engine.singletonInstance<ThemeManager *>("Vela", "Theme")) {
        auto applyFont = [theme] {
            const QString fam = theme->options().value("fontFamily", "Inter").toString();
            QFont f = QGuiApplication::font();
            if (f.family() != fam) {
                f.setFamily(fam);
                QGuiApplication::setFont(f);
            }
        };
        QObject::connect(theme, &ThemeManager::changed, &app, applyFont);
        applyFont();
    }

    return app.exec();
}
