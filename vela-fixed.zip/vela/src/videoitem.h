// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include <QPointer>
#include <QQuickItem>
#include <QtQml/qqmlregistration.h>

class VlcPlayer;

// Displays the frames produced by a VlcPlayer as a scene-graph texture.
class VideoItem : public QQuickItem
{
    Q_OBJECT
    QML_ELEMENT

    Q_PROPERTY(VlcPlayer *player READ player WRITE setPlayer NOTIFY playerChanged)
    Q_PROPERTY(FillMode fillMode READ fillMode WRITE setFillMode NOTIFY fillModeChanged)
    Q_PROPERTY(QString aspectRatio READ aspectRatio WRITE setAspectRatio NOTIFY fillModeChanged)
    Q_PROPERTY(double zoom READ zoom WRITE setZoom NOTIFY fillModeChanged)
    Q_PROPERTY(QRectF contentRect READ contentRect NOTIFY contentRectChanged)

public:
    enum FillMode { Fit, Fill, Stretch };
    Q_ENUM(FillMode)

    explicit VideoItem(QQuickItem *parent = nullptr);

    VlcPlayer *player() const { return m_player; }
    void setPlayer(VlcPlayer *p);
    FillMode fillMode() const { return m_fillMode; }
    void setFillMode(FillMode m);
    QString aspectRatio() const { return m_aspect; }
    void setAspectRatio(const QString &a);
    double zoom() const { return m_zoom; }
    void setZoom(double z);
    QRectF contentRect() const { return m_contentRect; }

signals:
    void playerChanged();
    void fillModeChanged();
    void contentRectChanged();

protected:
    QSGNode *updatePaintNode(QSGNode *old, UpdatePaintNodeData *) override;
    void geometryChange(const QRectF &newGeometry, const QRectF &oldGeometry) override;

private:
    void recomputeRect(QSizeF frameSize);

    QPointer<VlcPlayer> m_player;
    FillMode m_fillMode = Fit;
    QString m_aspect = QStringLiteral("auto");
    double m_zoom = 1.0;
    QRectF m_contentRect;
    QSizeF m_lastFrameSize;
};
