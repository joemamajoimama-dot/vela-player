// SPDX-License-Identifier: GPL-3.0-or-later
#include "vlcplayer.h"

#include <QColor>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QMutexLocker>
#include <QSettings>
#include <QStandardPaths>
#include <QtMath>

#include <vlc/vlc.h>

#include <algorithm>
#include <cstring>

namespace {

QString takeVlcString(char *s)
{
    if (!s)
        return {};
    QString out = QString::fromUtf8(s);
    libvlc_free(s);
    return out;
}

QVariantList trackList(libvlc_track_description_t *list)
{
    QVariantList out;
    for (auto *t = list; t; t = t->p_next) {
        QString name = QString::fromUtf8(t->psz_name ? t->psz_name : "");
        if (t->i_id < 0)
            name = QObject::tr("Off");
        out.append(QVariantMap{{"id", t->i_id}, {"name", name}});
    }
    if (list)
        libvlc_track_description_list_release(list);
    return out;
}

} // namespace

VlcPlayer::VlcPlayer(QObject *parent)
    : QObject(parent)
{
    QSettings settings;
    m_hwDecoding = settings.value("playback/hardwareDecoding", true).toBool();
    m_subtitleScale = settings.value("subtitles/scale", 100).toInt();
    const QString subColor = settings.value("subtitles/color", "#FFFFFF").toString();
    const int subBgOpacity = settings.value("subtitles/backgroundOpacity", 0).toInt();
    const int subOutline = settings.value("subtitles/outline", 4).toInt();

    QByteArrayList args = {
        "--no-video-title-show",
        "--no-osd",
        "--no-snapshot-preview",
        "--no-stats",
        "--no-xlib",
        "--quiet",
        "--audio-time-stretch",
        QByteArray("--freetype-color=") + QByteArray::number(QColor(subColor).rgb() & 0xFFFFFF),
        QByteArray("--freetype-background-opacity=") + QByteArray::number(qBound(0, subBgOpacity, 255)),
        QByteArray("--freetype-outline-thickness=") + QByteArray::number(qBound(0, subOutline, 6)),
        "--freetype-font=Inter",
        "--freetype-bold",
    };
    std::vector<const char *> argv;
    argv.reserve(args.size());
    for (const QByteArray &a : args)
        argv.push_back(a.constData());

    m_vlc = libvlc_new(int(argv.size()), argv.data());
    if (!m_vlc) {
        // An option unknown to this libVLC build makes libvlc_new() fail;
        // fall back to defaults rather than refusing to start.
        qWarning("Vela: libVLC rejected custom options (%s); retrying with defaults",
                 libvlc_errmsg() ? libvlc_errmsg() : "unknown error");
        const char *minimal[] = {"--no-video-title-show", "--quiet"};
        m_vlc = libvlc_new(2, minimal);
    }
    if (!m_vlc) {
        m_lastError = tr("libVLC could not be initialised. Is VLC installed?");
        m_state = Error;
        return;
    }
    libvlc_set_user_agent(m_vlc, "Vela", "Vela/" VELA_VERSION " LibVLC");
    libvlc_set_app_id(m_vlc, VELA_APP_ID, VELA_VERSION, VELA_APP_ID);

    m_mp = libvlc_media_player_new(m_vlc);
    libvlc_video_set_callbacks(m_mp, &VlcPlayer::videoLock, &VlcPlayer::videoUnlock,
                               &VlcPlayer::videoDisplay, this);
    libvlc_video_set_format_callbacks(m_mp, &VlcPlayer::videoSetup, &VlcPlayer::videoCleanup);

    libvlc_event_manager_t *em = libvlc_media_player_event_manager(m_mp);
    const libvlc_event_type_t events[] = {
        libvlc_MediaPlayerOpening,     libvlc_MediaPlayerBuffering,
        libvlc_MediaPlayerPlaying,     libvlc_MediaPlayerPaused,
        libvlc_MediaPlayerStopped,     libvlc_MediaPlayerEndReached,
        libvlc_MediaPlayerEncounteredError, libvlc_MediaPlayerTimeChanged,
        libvlc_MediaPlayerLengthChanged,    libvlc_MediaPlayerESAdded,
        libvlc_MediaPlayerESDeleted,        libvlc_MediaPlayerESSelected,
    };
    for (auto e : events)
        libvlc_event_attach(em, e, &VlcPlayer::handleEvent, this);

    m_volume = settings.value("playback/volume", 100).toInt();
    m_eqEnabled = settings.value("equalizer/enabled", false).toBool();
    m_eqPreamp = settings.value("equalizer/preamp", 0.0).toDouble();
    m_eqBandsDb = settings.value("equalizer/bands").toList();
    applyEqualizer();
}

VlcPlayer::~VlcPlayer()
{
    m_alive = false;
    QSettings settings;
    settings.setValue("playback/volume", m_volume);
    if (m_mp) {
        libvlc_media_player_stop(m_mp); // joins decoder + vout threads
        libvlc_media_player_release(m_mp);
    }
    if (m_media)
        libvlc_media_release(m_media);
    if (m_vlc)
        libvlc_release(m_vlc);
}

QString VlcPlayer::vlcVersion() const
{
    return QString::fromUtf8(libvlc_get_version());
}

// ---------------------------------------------------------------- playback

void VlcPlayer::open(const QUrl &url, qint64 startAtMs)
{
    if (!m_mp || !url.isValid())
        return;

    libvlc_media_t *media = nullptr;
    if (url.isLocalFile())
        media = libvlc_media_new_path(m_vlc, QFile::encodeName(url.toLocalFile()).constData());
    else
        media = libvlc_media_new_location(m_vlc, url.toString(QUrl::FullyEncoded).toUtf8().constData());
    if (!media) {
        m_lastError = tr("Could not open %1").arg(url.toDisplayString());
        setState(Error);
        emit errorOccurred();
        return;
    }

    libvlc_media_add_option(media, m_hwDecoding ? ":avcodec-hw=any" : ":avcodec-hw=none");
    libvlc_media_add_option(media, QByteArray(":sub-text-scale=" + QByteArray::number(m_subtitleScale)).constData());
    if (startAtMs > 0)
        libvlc_media_add_option(media, QByteArray(":start-time=" + QByteArray::number(startAtMs / 1000.0, 'f', 3)).constData());

    if (m_media) {
        libvlc_event_detach(libvlc_media_event_manager(m_media), libvlc_MediaMetaChanged, &VlcPlayer::handleEvent, this);
        libvlc_media_release(m_media);
    }
    m_media = media;
    libvlc_event_attach(libvlc_media_event_manager(m_media), libvlc_MediaMetaChanged, &VlcPlayer::handleEvent, this);
    libvlc_media_parse_with_options(m_media,
        libvlc_media_parse_flag_t(libvlc_media_parse_local | libvlc_media_fetch_local), 4000);

    libvlc_media_player_set_media(m_mp, m_media);

    m_source = url;
    m_time = startAtMs;
    m_length = 0;
    m_pendingStart = startAtMs;
    m_audioTracks.clear();
    m_subtitleTracks.clear();
    m_subtitleDelay = m_audioDelay = 0;
    m_title = QFileInfo(url.path()).completeBaseName();
    if (m_title.isEmpty())
        m_title = url.toDisplayString();
    m_artist.clear();
    m_artworkUrl.clear();

    emit sourceChanged();
    emit timeChanged();
    emit lengthChanged();
    emit tracksChanged();
    emit delaysChanged();
    emit titleChanged();

    play();
}

void VlcPlayer::play()
{
    if (m_mp && libvlc_media_player_play(m_mp) != 0) {
        if (const char *msg = libvlc_errmsg())
            m_lastError = QString::fromUtf8(msg);
        setState(Error);
        emit errorOccurred();
    }
}

void VlcPlayer::pause()
{
    if (m_mp)
        libvlc_media_player_set_pause(m_mp, 1);
}

void VlcPlayer::togglePause()
{
    if (!m_mp)
        return;
    if (m_state == Ended || m_state == Stopped) {
        if (m_source.isValid())
            open(m_source);
        return;
    }
    libvlc_media_player_set_pause(m_mp, isPlaying() ? 1 : 0);
}

void VlcPlayer::stop()
{
    if (m_mp)
        libvlc_media_player_stop(m_mp);
}

void VlcPlayer::seek(qint64 ms)
{
    if (!m_mp || m_length <= 0)
        return;
    ms = std::clamp<qint64>(ms, 0, m_length);
    libvlc_media_player_set_time(m_mp, ms);
    m_time = ms;
    emit timeChanged();
}

void VlcPlayer::seekRelative(qint64 deltaMs)
{
    seek(m_time + deltaMs);
}

void VlcPlayer::setPosition(double pos)
{
    seek(qint64(std::clamp(pos, 0.0, 1.0) * double(m_length)));
}

void VlcPlayer::nextFrame()
{
    if (m_mp)
        libvlc_media_player_next_frame(m_mp);
}

bool VlcPlayer::addSubtitle(const QUrl &url)
{
    if (!m_mp)
        return false;
    const bool ok = libvlc_media_player_add_slave(m_mp, libvlc_media_slave_type_subtitle,
                                                  url.toString(QUrl::FullyEncoded).toUtf8().constData(),
                                                  true) == 0;
    return ok;
}

QString VlcPlayer::snapshot()
{
    const QImage frame = currentFrameCopy();
    if (frame.isNull())
        return {};
    QDir dir(QStandardPaths::writableLocation(QStandardPaths::PicturesLocation) + "/Vela");
    dir.mkpath(".");
    const QString file = dir.filePath(QStringLiteral("Vela %1.png")
                                          .arg(QDateTime::currentDateTime().toString("yyyy-MM-dd hh.mm.ss")));
    return frame.save(file) ? file : QString();
}

// ------------------------------------------------------------- properties

void VlcPlayer::setVolume(int v)
{
    v = std::clamp(v, 0, 200);
    if (m_mp)
        libvlc_audio_set_volume(m_mp, v);
    if (v != m_volume) {
        m_volume = v;
        emit volumeChanged();
    }
}

void VlcPlayer::setMuted(bool m)
{
    if (m_mp)
        libvlc_audio_set_mute(m_mp, m ? 1 : 0);
    if (m != m_muted) {
        m_muted = m;
        emit mutedChanged();
    }
}

void VlcPlayer::setRate(double r)
{
    r = std::clamp(r, 0.25, 4.0);
    if (m_mp)
        libvlc_media_player_set_rate(m_mp, float(r));
    if (!qFuzzyCompare(r, m_rate)) {
        m_rate = r;
        emit rateChanged();
    }
}

int VlcPlayer::audioTrack() const
{
    return m_mp ? libvlc_audio_get_track(m_mp) : -1;
}

int VlcPlayer::subtitleTrack() const
{
    return m_mp ? libvlc_video_get_spu(m_mp) : -1;
}

void VlcPlayer::setAudioTrack(int id)
{
    if (m_mp && libvlc_audio_set_track(m_mp, id) == 0)
        emit tracksChanged();
}

void VlcPlayer::setSubtitleTrack(int id)
{
    if (m_mp && libvlc_video_set_spu(m_mp, id) == 0)
        emit tracksChanged();
}

void VlcPlayer::setSubtitleDelay(int ms)
{
    if (m_mp)
        libvlc_video_set_spu_delay(m_mp, int64_t(ms) * 1000);
    m_subtitleDelay = ms;
    emit delaysChanged();
}

void VlcPlayer::setAudioDelay(int ms)
{
    if (m_mp)
        libvlc_audio_set_delay(m_mp, int64_t(ms) * 1000);
    m_audioDelay = ms;
    emit delaysChanged();
}

void VlcPlayer::setHardwareDecoding(bool on)
{
    if (on == m_hwDecoding)
        return;
    m_hwDecoding = on;
    QSettings().setValue("playback/hardwareDecoding", on);
    emit optionsChanged();
}

void VlcPlayer::setSubtitleScale(int pct)
{
    pct = std::clamp(pct, 25, 400);
    if (pct == m_subtitleScale)
        return;
    m_subtitleScale = pct;
    QSettings().setValue("subtitles/scale", pct);
    emit optionsChanged();
}

// --------------------------------------------------------------- equalizer

QStringList VlcPlayer::equalizerPresets() const
{
    QStringList out;
    const unsigned n = libvlc_audio_equalizer_get_preset_count();
    for (unsigned i = 0; i < n; ++i)
        out << QString::fromUtf8(libvlc_audio_equalizer_get_preset_name(i));
    return out;
}

QVariantList VlcPlayer::equalizerBands() const
{
    QVariantList out;
    const unsigned n = libvlc_audio_equalizer_get_band_count();
    for (unsigned i = 0; i < n; ++i)
        out << double(libvlc_audio_equalizer_get_band_frequency(i));
    return out;
}

QVariantList VlcPlayer::equalizerPresetValues(int preset) const
{
    QVariantList out;
    libvlc_equalizer_t *eq = libvlc_audio_equalizer_new_from_preset(unsigned(preset));
    if (!eq)
        return out;
    out << double(libvlc_audio_equalizer_get_preamp(eq));
    const unsigned n = libvlc_audio_equalizer_get_band_count();
    for (unsigned i = 0; i < n; ++i)
        out << double(libvlc_audio_equalizer_get_amp_at_index(eq, i));
    libvlc_audio_equalizer_release(eq);
    return out; // [preamp, band0, band1, ...]
}

void VlcPlayer::setEqualizer(double preamp, const QVariantList &bandsDb)
{
    m_eqPreamp = preamp;
    m_eqBandsDb = bandsDb;
    QSettings s;
    s.setValue("equalizer/preamp", preamp);
    s.setValue("equalizer/bands", bandsDb);
    applyEqualizer();
    emit equalizerChanged();
}

void VlcPlayer::setEqualizerEnabled(bool on)
{
    if (on == m_eqEnabled)
        return;
    m_eqEnabled = on;
    QSettings().setValue("equalizer/enabled", on);
    applyEqualizer();
    emit equalizerChanged();
}

void VlcPlayer::applyEqualizer()
{
    if (!m_mp)
        return;
    if (!m_eqEnabled) {
        libvlc_media_player_set_equalizer(m_mp, nullptr);
        return;
    }
    libvlc_equalizer_t *eq = libvlc_audio_equalizer_new();
    libvlc_audio_equalizer_set_preamp(eq, float(m_eqPreamp));
    const unsigned n = libvlc_audio_equalizer_get_band_count();
    for (unsigned i = 0; i < n && int(i) < m_eqBandsDb.size(); ++i)
        libvlc_audio_equalizer_set_amp_at_index(eq, float(m_eqBandsDb.at(int(i)).toDouble()), i);
    libvlc_media_player_set_equalizer(m_mp, eq); // copies the settings
    libvlc_audio_equalizer_release(eq);
}

// ------------------------------------------------------------------ events

void VlcPlayer::setState(State s)
{
    if (s == m_state)
        return;
    m_state = s;
    emit stateChanged();
}

void VlcPlayer::refreshTracks()
{
    if (!m_mp)
        return;
    m_audioTracks = trackList(libvlc_audio_get_track_description(m_mp));
    m_subtitleTracks = trackList(libvlc_video_get_spu_description(m_mp));
    emit tracksChanged();
}

void VlcPlayer::refreshMeta()
{
    if (!m_media)
        return;
    const QString title = takeVlcString(libvlc_media_get_meta(m_media, libvlc_meta_Title));
    const QString artist = takeVlcString(libvlc_media_get_meta(m_media, libvlc_meta_Artist));
    const QString art = takeVlcString(libvlc_media_get_meta(m_media, libvlc_meta_ArtworkURL));
    // VLC reports the file name as the title when there is no tag; keep our cleaner base name.
    if (!title.isEmpty() && !m_source.fileName().startsWith(title))
        m_title = title;
    m_artist = artist;
    m_artworkUrl = art;
    emit titleChanged();
}

void VlcPlayer::handleEvent(const libvlc_event_t *ev, void *opaque)
{
    auto *self = static_cast<VlcPlayer *>(opaque);
    if (!self->m_alive)
        return;

    // Everything below hops onto the GUI thread; the lambda is dropped
    // automatically if the player is destroyed first.
    auto post = [self](auto fn) { QMetaObject::invokeMethod(self, fn, Qt::QueuedConnection); };

    switch (ev->type) {
    case libvlc_MediaPlayerOpening:
        post([self] { self->setState(Opening); });
        break;
    case libvlc_MediaPlayerBuffering: {
        const double cache = ev->u.media_player_buffering.new_cache;
        post([self, cache] {
            self->m_buffering = cache;
            emit self->bufferingChanged();
            if (cache < 100.0 && self->m_state == Opening)
                self->setState(Buffering);
        });
        break;
    }
    case libvlc_MediaPlayerPlaying:
        post([self] {
            // Audio output exists now: re-apply sticky audio settings.
            self->setVolume(self->m_volume);
            self->setMuted(self->m_muted);
            self->setRate(self->m_rate);
            self->applyEqualizer();
            self->setState(Playing);
            self->refreshTracks();
            self->refreshMeta();
        });
        break;
    case libvlc_MediaPlayerPaused:
        post([self] { self->setState(Paused); });
        break;
    case libvlc_MediaPlayerStopped:
        post([self] { self->setState(Stopped); });
        break;
    case libvlc_MediaPlayerEndReached:
        post([self] {
            self->m_time = self->m_length;
            emit self->timeChanged();
            self->setState(Ended);
            emit self->endReached();
        });
        break;
    case libvlc_MediaPlayerEncounteredError:
        post([self] {
            const char *msg = libvlc_errmsg();
            self->m_lastError = msg ? QString::fromUtf8(msg) : tr("Playback failed");
            self->setState(Error);
            emit self->errorOccurred();
        });
        break;
    case libvlc_MediaPlayerTimeChanged: {
        const qint64 t = ev->u.media_player_time_changed.new_time;
        post([self, t] {
            self->m_time = t;
            emit self->timeChanged();
        });
        break;
    }
    case libvlc_MediaPlayerLengthChanged: {
        const qint64 len = ev->u.media_player_length_changed.new_length;
        post([self, len] {
            self->m_length = len;
            emit self->lengthChanged();
            emit self->timeChanged();
        });
        break;
    }
    case libvlc_MediaPlayerESAdded:
    case libvlc_MediaPlayerESDeleted:
    case libvlc_MediaPlayerESSelected:
        post([self] { self->refreshTracks(); });
        break;
    case libvlc_MediaMetaChanged:
        post([self] { self->refreshMeta(); });
        break;
    default:
        break;
    }
}

// ------------------------------------------------------- video callbacks

unsigned VlcPlayer::videoSetup(void **opaque, char *chroma, unsigned *w, unsigned *h,
                               unsigned *pitches, unsigned *lines)
{
    auto *self = static_cast<VlcPlayer *>(*opaque);
    std::memcpy(chroma, "RV32", 4); // BGRA in memory == QImage::Format_RGB32 on little endian

    const unsigned width = *w, height = *h;
    const unsigned pitch = ((width * 4) + 31) & ~31u;
    {
        QMutexLocker lock(&self->m_frameLock);
        self->m_frameW = width;
        self->m_frameH = height;
        self->m_pitch = pitch;
        for (auto &b : self->m_buffers)
            b.assign(size_t(pitch) * height, 0);
        self->m_hasNewFrame = false;
    }
    pitches[0] = pitch;
    lines[0] = height;

    const QSize size(int(width), int(height));
    QMetaObject::invokeMethod(self, [self, size] {
        self->m_videoSize = size;
        emit self->videoSizeChanged();
    }, Qt::QueuedConnection);
    return 1;
}

void VlcPlayer::videoCleanup(void *opaque)
{
    auto *self = static_cast<VlcPlayer *>(opaque);
    {
        QMutexLocker lock(&self->m_frameLock);
        self->m_frameW = self->m_frameH = self->m_pitch = 0;
        self->m_hasNewFrame = false;
    }
    if (self->m_alive)
        QMetaObject::invokeMethod(self, [self] {
            self->m_videoSize = QSize();
            emit self->videoSizeChanged();
            emit self->frameReady();
        }, Qt::QueuedConnection);
}

void *VlcPlayer::videoLock(void *opaque, void **planes)
{
    auto *self = static_cast<VlcPlayer *>(opaque);
    QMutexLocker lock(&self->m_frameLock);
    planes[0] = self->m_buffers[self->m_writeIdx].data();
    return nullptr;
}

void VlcPlayer::videoUnlock(void *, void *, void *const *) {}

void VlcPlayer::videoDisplay(void *opaque, void *)
{
    auto *self = static_cast<VlcPlayer *>(opaque);
    {
        QMutexLocker lock(&self->m_frameLock);
        std::swap(self->m_writeIdx, self->m_readyIdx);
        self->m_hasNewFrame = true;
    }
    if (self->m_alive)
        emit self->frameReady(); // queued to VideoItem's thread
}

bool VlcPlayer::takeFrame(QImage &out)
{
    QMutexLocker lock(&m_frameLock);
    if (!m_frameW || !m_frameH)
        return false;
    if (m_hasNewFrame) {
        std::swap(m_readyIdx, m_readIdx);
        m_hasNewFrame = false;
    }
    // Deep copy so the texture upload never races VLC reallocating buffers.
    out = QImage(m_buffers[m_readIdx].data(), int(m_frameW), int(m_frameH), int(m_pitch),
                 QImage::Format_RGB32).copy();
    return true;
}

QImage VlcPlayer::currentFrameCopy()
{
    QImage img;
    takeFrame(img);
    return img;
}
