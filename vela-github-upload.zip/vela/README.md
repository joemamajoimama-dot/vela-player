<p align="center">
  <img src="branding/vela.svg" width="128" alt="Vela logo"/>
</p>

<h1 align="center">Vela</h1>
<p align="center"><b>Play anything, beautifully.</b><br/>A modern, deeply customizable media player for Linux, built on libVLC.</p>

<p align="center">
  <img src="branding/screenshots/player.png" width="860" alt="Vela now playing"/>
</p>

Vela uses **libVLC** — the engine inside VLC — so it plays practically every
file, codec, disc and stream VLC does. On top of it sits a brand-new Qt Quick
interface where *everything* is themeable.

> Vela is an independent project and is **not affiliated with VideoLAN**.
> VLC and the cone logo are trademarks of VideoLAN; Vela uses neither.

## Highlights

- **Frosted-glass player** with floating, docked or minimal controls
- **Ambient light**: the picture's colours glow softly into the letterbox
- **Home that knows you**: *Jump back in*, automatic resume, recently added
- **Library** grid or list for videos & music, search, sort, card size slider
- **Queue** with shuffle, repeat-one/all, drag-to-reorder, drop-to-enqueue
- **Tracks**: subtitle/audio switching, external subs (drag & drop), delays
- **10-band equalizer** with libVLC presets, playback speed, frame stepping, snapshots
- **Streams**: HTTP(S), HLS, DASH, RTSP, RTMP, SMB…
- **Customization is the point** — see below

## Make it yours

Everything visual reads from one theme engine:

| Setting | Range |
|---|---|
| Theme | Vela Night, Vela Day, Nebula, Ember, Aurora, OLED Black, + your own |
| Accent | 10 presets or any colour |
| Corner radius | 0–30 px |
| Glass blur / tint | 0–96 / 20–100 % |
| Density | Compact · Cozy · Roomy |
| Font & text size | any installed family, 0.85–1.3× |
| Motion | on/off, 0.5–2× speed |
| Player controls | Floating · Docked · Minimal, thin/bold timeline, auto-hide delay |
| Ambient light | on/off + intensity |
| Chrome | Vela title bar or system frame, full or icon sidebar, film grain |

Hit **Save as new theme** and Vela writes a JSON file you can tweak in any
editor — it hot-reloads as you save. Share it; others drop it in their themes
folder. Details in [THEMING.md](THEMING.md).

<p align="center">
  <img src="branding/screenshots/customize.png" width="420"/>
  <img src="branding/screenshots/home.png" width="420"/>
</p>

## Install

### Flatpak (any distro)

```sh
flatpak-builder --user --install --force-clean build-dir packaging/flatpak/io.github.velaplayer.Vela.yml
flatpak run io.github.velaplayer.Vela
```

Run `packaging/flatpak/update-hashes.sh` once first to fill in source checksums.
Every tagged release also attaches a ready-made `vela.flatpak` bundle
(`flatpak install vela.flatpak`). Once on Flathub it shows up in **Bazaar**,
GNOME Software and KDE Discover automatically.

### Arch Linux

```sh
cd packaging/arch && makepkg -si          # release
# or: makepkg -si -p PKGBUILD-git          # latest main
```

### Fedora

```sh
sudo dnf install rpm-build cmake ninja-build gcc-c++ vlc-devel \
  qt6-qtbase-devel qt6-qtdeclarative-devel qt6-qtsvg-devel desktop-file-utils libappstream-glib
rpmbuild -ba packaging/fedora/vela.spec   # or publish it on COPR
```

For full codec support enable RPM Fusion's VLC plugins.

### From source

Requirements: CMake ≥ 3.21, a C++20 compiler, Qt ≥ 6.6 (Base, Declarative, Svg), libVLC ≥ 3.0.

```sh
cmake -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build
./build/vela ~/Videos/something.mkv
```

Or, in one step (installs dependencies, builds, installs to `~/.local`, and adds
an app-menu entry plus a Desktop shortcut): `tools/install-local.sh`.

This tree includes compatibility fixes for Qt 6.11 and GCC 16 (for example
Fedora 44 / Nobara). See [REPAIR.md](REPAIR.md) for what changed and why.

## Keyboard

`Space`/`K` play · `F` full screen · `←/→` ±10 s · `Shift+←/→` ±1 min · `↑/↓` volume ·
`M` mute · `N/P` next/prev · `[ ] =` speed · `V` subtitles · `B` audio track ·
`S` snapshot · `.` next frame · `Ctrl+O` open · `Ctrl+L` link · `Ctrl+,` customize

## How it's built

```
src/vlcplayer.*     libVLC wrapper: playback, tracks, EQ, events → Qt signals
src/videoitem.*     renders libVLC frames (vmem callbacks) as a scene-graph texture
src/thememanager.*  themes (JSON) + live user overrides, hot reload
src/*model.*        library scan, play queue, watch history
qml/                the entire UI
themes/             built-in themes
```

Rendering through libVLC's memory callbacks means the video is a normal Qt
Quick item, so it works identically on Wayland and X11 and can be blurred,
masked and glowed like anything else.

## Credits

- Playback: [libVLC](https://www.videolan.org/vlc/libvlc.html) by VideoLAN (LGPL-2.1+)
- Interface: [Qt](https://www.qt.io) 6
- Font: [Inter](https://rsms.me/inter/) by Rasmus Andersson (OFL-1.1)
- Design inspiration: the community VLC redesign by Juxtopposed

Screenshots in `branding/screenshots/` are rendered from the app's design
tokens with `branding/tools/mockups.py`; swap in real captures after your first build.

## Brand kit

- `branding/vela.svg` — master icon; PNGs in `data/icons/hicolor/` and `branding/store/`
- `branding/screenshots/` — store screenshots + 1920×1080 banner (`mockups.py` regenerates them)
- `branding/promo/` — 24 s social promo in 9:16 and 16:9 (`promo.py` regenerates it, soundtrack included)
- `tools/set-github-owner.sh <you>` — swaps the app id/URLs to your GitHub account before publishing

## License

GPL-3.0-or-later. See [LICENSE](LICENSE).
