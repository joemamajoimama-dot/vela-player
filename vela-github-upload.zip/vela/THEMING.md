# Theming Vela

A theme is one JSON file. Built-ins live in `themes/`; yours live in

- `~/.config/Vela/themes/` (native)
- `~/.var/app/io.github.velaplayer.Vela/config/Vela/themes/` (Flatpak)

Vela watches that folder: save the file and the app restyles instantly.
The quickest start is **Customize → Save as new theme**, which exports what
you see right now.

```json
{
  "name": "Midnight Mint",
  "dark": true,
  "author": "you",
  "colors": {
    "bg":           "#0B0A16",
    "bgAlt":        "#100E21",
    "surface":      "#15132A",
    "surfaceHi":    "#1D1A38",
    "elevated":     "#252145",
    "border":       "#16FFFFFF",
    "borderStrong": "#2BFFFFFF",
    "text":         "#F4F2FF",
    "textDim":      "#B6B0DA",
    "textMuted":    "#77729C",
    "accent":       "#3DDC97",
    "positive":     "#5EEAD4",
    "warning":      "#FFC145",
    "danger":       "#FF6B81",
    "glass":        "#120F26",
    "scrim":        "#B3000000"
  },
  "options": {
    "radius": 20,
    "blur": 56,
    "glassOpacity": 0.55,
    "controlStyle": "floating",
    "ambient": true
  }
}
```

Colours are `#RRGGBB` or `#AARRGGBB` (alpha first, Qt style).
`accentHi` and `onAccent` are derived automatically unless you set them.

## Options

Any option can be set by a theme and overridden by the user in Customize.

| key | values | default |
|---|---|---|
| `radius` | px | 16 |
| `blur` | 0–96 | 48 |
| `glassOpacity` | 0–1 | 0.62 |
| `density` | `compact` `comfortable` `spacious` | `comfortable` |
| `fontFamily` | any installed family | `Inter` |
| `fontScale` | 0.85–1.3 | 1.0 |
| `motion` | bool | true |
| `motionSpeed` | 0.5–2 | 1.0 |
| `controlStyle` | `floating` `docked` `minimal` | `floating` |
| `seekStyle` | `thin` `thick` | `thick` |
| `ambient` | bool | true |
| `ambientStrength` | 0–1 | 0.55 |
| `autoHideMs` | ms | 2600 |
| `cardSize` | px | 236 |
| `sidebar` | `expanded` `compact` | `expanded` |
| `titlebar` | `custom` `system` | `custom` |
| `accentGlow` | bool | true |
| `grain` | bool | false |
| `showRemaining` | bool | false |
| `defaultFill` | `fit` `fill` `stretch` | `fit` |
| `libraryLayout` | `auto` `grid` `list` | `auto` |
