"""Renders Vela's store screenshots, banner and promo frames as SVG -> PNG.

The layouts mirror the QML in qml/ (same tokens, spacing and icons), so the
store listing shows exactly what the app looks like.

    python3 branding/tools/mockups.py   # needs `resvg` on PATH
"""
import json, os, re, subprocess, sys
from html import escape

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
sys.path.insert(0, HERE)
import scenes  # noqa: E402

OUT = os.environ.get("VELA_RENDER_OUT", os.path.join(ROOT, "branding", "screenshots"))
TMP = os.environ.get("VELA_RENDER_TMP", "/tmp/vela-render")
os.makedirs(OUT, exist_ok=True)
os.makedirs(TMP, exist_ok=True)
FONTS = ["--use-fonts-dir", "/usr/share/fonts/opentype/inter", "--use-fonts-dir", os.path.join(ROOT, "fonts")]


def theme(name):
    t = json.load(open(os.path.join(ROOT, "themes", name + ".json")))
    c = dict(t["colors"])
    def css(v):  # "#AARRGGBB" -> ("#RRGGBB", alpha)
        if len(v) == 9:
            return "#" + v[3:], int(v[1:3], 16) / 255
        return v, 1.0
    out = {}
    for k, v in c.items():
        out[k] = css(v)
    out.setdefault("accentHi", (lighten(out["accent"][0], 0.18), 1))
    if "onAccent" not in out:
        r, g, b = (int(out["accent"][0][i:i + 2], 16) / 255 for i in (1, 3, 5))
        lin = lambda v: v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
        lum = 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)
        out["onAccent"] = ("#111015" if lum > 0.45 else "#FFFFFF", 1)
    out["dark"] = t.get("dark", True)
    out["radius"] = t.get("options", {}).get("radius", 16)
    out["name"] = t["name"]
    return out


def lighten(hexc, t):
    r, g, b = (int(hexc[i:i + 2], 16) for i in (1, 3, 5))
    r, g, b = (int(v + (255 - v) * t) for v in (r, g, b))
    return f"#{r:02X}{g:02X}{b:02X}"


def mix(a, b, t):
    ra, ga, ba = (int(a[i:i + 2], 16) for i in (1, 3, 5))
    rb, gb, bb = (int(b[i:i + 2], 16) for i in (1, 3, 5))
    return "#%02X%02X%02X" % (int(ra + (rb - ra) * t), int(ga + (gb - ga) * t), int(ba + (bb - ba) * t))


ICON_CACHE = {}


def icon(name, x, y, size, color, opacity=1):
    if name not in ICON_CACHE:
        src = open(os.path.join(ROOT, "icons", name + ".svg")).read()
        ICON_CACHE[name] = re.sub(r"^<svg[^>]*>|</svg>$", "", src.strip())
    inner = ICON_CACHE[name].replace('stroke="#000"', f'stroke="{color}"').replace('fill="#000"', f'fill="{color}"')
    s = size / 24
    return (f'<g transform="translate({x:.1f},{y:.1f}) scale({s:.4f})" opacity="{opacity}" fill="none" stroke="{color}" '
            f'stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">{inner}</g>')


class C:
    """Tiny SVG builder."""

    def __init__(self, w, h, th):
        self.w, self.h, self.t = w, h, th
        self.parts, self.defs, self.n = [], [], 0

    def uid(self, p="u"):
        self.n += 1
        return f"{p}{self.n}"

    def col(self, key, a=1.0):
        c, base = self.t[key]
        return c, base * a

    def add(self, s):
        self.parts.append(s)

    def rect(self, x, y, w, h, r=0, fill=None, key=None, a=1.0, stroke=None, sw=1, sa=1.0, extra=""):
        if key:
            fill, a = self.col(key, a)
        st = f' stroke="{stroke}" stroke-opacity="{sa}" stroke-width="{sw}"' if stroke else ""
        self.add(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="{r}" fill="{fill or "none"}" fill-opacity="{a:.3f}"{st} {extra}/>')

    def border(self, x, y, w, h, r, key="border", sw=1):
        c, a = self.col(key)
        self.add(f'<rect x="{x+0.5:.1f}" y="{y+0.5:.1f}" width="{w-1:.1f}" height="{h-1:.1f}" rx="{r}" fill="none" stroke="{c}" stroke-opacity="{a:.3f}" stroke-width="{sw}"/>')

    def text(self, x, y, s, size=14, key="text", weight=400, a=1.0, family="Inter", anchor="start", fill=None, ls=0, opacity=None):
        c, al = (fill, a) if fill else self.col(key, a)
        if opacity is not None:
            al = opacity
        self.add(f'<text x="{x:.1f}" y="{y:.1f}" font-family="{family}" font-size="{size}" font-weight="{weight}" '
                 f'fill="{c}" fill-opacity="{al:.3f}" text-anchor="{anchor}" letter-spacing="{ls}">{escape(s)}</text>')

    def icon(self, name, x, y, size, key="text", fill=None, a=1.0):
        c, al = (fill, a) if fill else self.col(key, a)
        self.add(icon(name, x, y, size, c, al))

    def image(self, href, x, y, w, h, r=0, blur=0, opacity=1, preserve="xMidYMid slice", brightness=None):
        clip = self.uid("clip")
        self.defs.append(f'<clipPath id="{clip}"><rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}"/></clipPath>')
        filt = ""
        if blur or brightness is not None:
            fid = self.uid("f")
            ops = f'<feGaussianBlur stdDeviation="{blur}" edgeMode="duplicate"/>' if blur else ""
            if brightness is not None:
                ops += f'<feComponentTransfer><feFuncR type="linear" slope="{brightness}"/><feFuncG type="linear" slope="{brightness}"/><feFuncB type="linear" slope="{brightness}"/></feComponentTransfer>'
            self.defs.append(f'<filter id="{fid}" x="-10%" y="-10%" width="120%" height="120%" color-interpolation-filters="sRGB">{ops}</filter>')
            filt = f' filter="url(#{fid})"'
        self.add(f'<g clip-path="url(#{clip})"><image href="{href}" x="{x}" y="{y}" width="{w}" height="{h}" preserveAspectRatio="{preserve}" opacity="{opacity}"{filt}/></g>')

    def glass(self, x, y, w, h, r, backdrop, bx, by, bw, bh, tint="glass", ta=0.5, blur=26):
        """Frosted panel: blurred slice of `backdrop` (drawn at bx,by,bw,bh) clipped to the panel."""
        clip = self.uid("gc")
        fid = self.uid("gf")
        self.defs.append(f'<clipPath id="{clip}"><rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}"/></clipPath>')
        self.defs.append(f'<filter id="{fid}" x="-20%" y="-20%" width="140%" height="140%" color-interpolation-filters="sRGB">'
                         f'<feGaussianBlur stdDeviation="{blur}" edgeMode="duplicate"/><feColorMatrix type="saturate" values="1.25"/></filter>')
        if backdrop:
            self.add(f'<g clip-path="url(#{clip})"><image href="{backdrop}" x="{bx}" y="{by}" width="{bw}" height="{bh}" preserveAspectRatio="xMidYMid slice" filter="url(#{fid})"/></g>')
        c, a = self.col(tint, ta)
        self.add(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{c}" fill-opacity="{a:.3f}"/>')
        self.add(f'<rect x="{x+0.5}" y="{y+0.5}" width="{w-1}" height="{h-1}" rx="{r}" fill="none" stroke="#FFFFFF" stroke-opacity="{0.10 if self.t["dark"] else 0.5}"/>')
        self.add(f'<line x1="{x+r}" y1="{y+0.7}" x2="{x+w-r}" y2="{y+0.7}" stroke="#FFFFFF" stroke-opacity="0.16"/>')

    def svg(self):
        return (f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="{self.w}" height="{self.h}" '
                f'viewBox="0 0 {self.w} {self.h}"><defs>{"".join(self.defs)}</defs>{"".join(self.parts)}</svg>')


def render(svg, out_png, width=None):
    path = out_png[:-4] + ".svg"
    path = os.path.join(TMP, os.path.basename(path))
    open(path, "w").write(svg)
    cmd = ["resvg", *FONTS, "--resources-dir", TMP]
    if width:
        cmd += ["-w", str(width)]
    subprocess.run(cmd + [path, out_png], check=True)
    return out_png


def make_stills():
    stills = {}
    specs = [("aurora", 3), ("dusk", 4), ("desert", 5), ("ocean", 6), ("neon", 7), ("alpine", 8), ("forest", 9), ("violet", 10)]
    for name, seed in specs:
        p = os.path.join(TMP, f"still-{name}.png")
        if not os.path.exists(p):
            svg = scenes.scene_svg(name, 1920, 1080, seed)
            open(p[:-4] + ".svg", "w").write(svg)
            subprocess.run(["resvg", "-w", "1920", p[:-4] + ".svg", p], check=True)
        stills[name] = p
    return stills


LIB = [
    ("Northern Lights Over Tromsø", "aurora", "Documentaries", "MKV", 0.62),
    ("Night Drive", "neon", "Shorts", "MP4", 0.31),
    ("Dunes at Golden Hour", "desert", "Travel", "MKV", 0.84),
    ("Tidal", "ocean", "Films", "MP4", 0.12),
    ("First Snow", "alpine", "Travel", "WEBM", -1),
    ("The Quiet Forest", "forest", "Documentaries", "MKV", -1),
    ("Violet Hour", "violet", "Films", "MOV", -1),
    ("Summer, Ending", "dusk", "Home videos", "MP4", -1),
]


# ---------------------------------------------------------------- shell bits

def window_shell(c, page, wide=True):
    t = c.t
    W, H = c.w, c.h
    R = 14
    # page background with accent wash
    c.defs.append(f'<linearGradient id="wash" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{mix(t["bg"][0], t["accent"][0], 0.07)}"/>'
                  f'<stop offset="0.45" stop-color="{t["bg"][0]}"/><stop offset="1" stop-color="{t["bgAlt"][0]}"/></linearGradient>')
    c.add(f'<rect width="{W}" height="{H}" rx="{R}" fill="url(#wash)"/>')
    # sidebar
    sw = 240
    c.rect(0, 0, sw, H, 0, key="surface", a=0.55 if t["dark"] else 0.7, extra=f'clip-path="url(#winclip)"')
    c.defs.append(f'<clipPath id="winclip"><rect width="{W}" height="{H}" rx="{R}"/></clipPath>')
    c.rect(sw - 1, 0, 1, H, key="border")
    c.add(f'<image href="{os.path.join(ROOT, "branding", "vela.svg")}" x="22" y="20" width="40" height="40"/>')
    c.text(72, 49, "Vela", 24, weight=700, family="Inter Display", ls=-0.6)
    items = [("home", "Home"), ("film", "Videos"), ("music", "Music"), ("queue", "Queue"), ("globe", "Streams")]
    y = 92
    for ic, label in items:
        active = label.lower() == page
        if active:
            c.rect(16, y, sw - 32, 42, R * 0.75, key="accent", a=0.16)
            c.rect(15, y + 12, 3, 18, 1.5, key="accent")
        c.icon(ic, 30, y + 11, 20, key="accent" if active else "textDim")
        c.text(62, y + 26, label, 14, key="text" if active else "textDim", weight=600 if active else 500)
        if label == "Queue":
            c.rect(sw - 52, y + 11, 22, 20, 10, key="text", a=0.08)
            c.text(sw - 41, y + 25, "6", 11, key="textDim", weight=600, anchor="middle")
        y += 46
    yb = H - 170
    for ic, label, act in [("sparkle", "Now playing", False), ("palette", "Customize", page == "settings")]:
        if act:
            c.rect(16, yb, sw - 32, 42, R * 0.75, key="accent", a=0.16)
            c.rect(15, yb + 12, 3, 18, 1.5, key="accent")
        c.icon(ic, 30, yb + 11, 20, key="accent" if act else "textDim")
        c.text(62, yb + 26, label, 14, key="text" if act else "textDim", weight=600 if act else 500)
        yb += 46
    c.rect(16, H - 68, sw - 32, 42, 16, key="accent")
    c.icon("file-plus", 68, H - 56, 18, fill=t["onAccent"][0])
    c.text(96, H - 42, "Open media", 14, fill=t["onAccent"][0], weight=600)
    # window buttons
    for i, ic in enumerate(["minimize", "maximize", "close"]):
        x = W - 112 + i * 36
        c.rect(x, 9, 30, 30, 15, key="text", a=0.06)
        c.icon(ic, x + 7.5, 16.5, 15, key="textDim")
    return sw


def pill(c, x, y, label, ic=None, primary=False, compact=False, selected=False):
    t = c.t
    h = 32 if compact else 42
    fs = 13 if compact else 14
    tw = len(label) * fs * 0.56 + (26 if ic else 0)
    w = tw + (24 if compact else 36)
    if primary:
        c.rect(x, y, w, h, min(h / 2, t["radius"]), key="accent")
        col = t["onAccent"][0]
    else:
        c.rect(x, y, w, h, min(h / 2, t["radius"]), key="accent" if selected else "text", a=0.16 if selected else 0.07)
        col = t["accent"][0] if selected else t["text"][0]
    cx = x + (w - tw) / 2
    if ic:
        c.icon(ic, cx, y + (h - 18) / 2, 16 if compact else 18, fill=col)
        cx += 26
    c.text(cx, y + h / 2 + fs * 0.36, label, fs, fill=col, weight=600)
    return w


def card(c, x, y, w, still, title, sub, badge=None, progress=-1, aspect=16 / 9):
    t = c.t
    h = w / aspect
    r = t["radius"]
    c.image(still, x, y, w, h, r)
    if badge:
        bw = len(badge) * 7 + 12
        c.rect(x + w - bw - 10, y + 10, bw, 20, 6, fill="#000000", a=0.55)
        c.text(x + w - bw / 2 - 10, y + 24, badge, 10, fill="#FFFFFF", weight=700, anchor="middle", ls=0.6)
    if progress >= 0:
        c.rect(x + 10, y + h - 14, w - 20, 4, 2, fill="#FFFFFF", a=0.25)
        c.rect(x + 10, y + h - 14, (w - 20) * progress, 4, 2, key="accent")
    c.text(x, y + h + 24, title, 14, weight=600)
    c.text(x, y + h + 42, sub, 12, key="textMuted")


# ---------------------------------------------------------------- screens

def screen_home(th="vela-night", out="home.png", W=1600, H=1000):
    t = theme(th)
    c = C(W, H, t)
    S = make_stills()
    sw = window_shell(c, "home")
    x0 = sw + 40
    cw = W - x0 - 40
    c.text(x0, 96, "Good evening", 14, key="accent", weight=600)
    c.text(x0, 142, "Pick up where you left off.", 38, weight=700, family="Inter Display", ls=-1)
    px = x0
    for lbl, ic, pr in [("Open files", "file-plus", True), ("Play a link", "link", False), ("Make it yours", "palette", False)]:
        px += pill(c, px, 168, lbl, ic, primary=pr) + 10
    # hero
    hy, hh = 244, 300
    r = t["radius"] + 10
    c.image(S["aurora"], x0, hy, cw, hh, r, blur=4, brightness=0.82)
    c.defs.append('<linearGradient id="heroScrim" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#000" stop-opacity="0.62"/><stop offset="0.7" stop-color="#000" stop-opacity="0"/></linearGradient>')
    c.add(f'<rect x="{x0}" y="{hy}" width="{cw}" height="{hh}" rx="{r}" fill="url(#heroScrim)"/>')
    c.border(x0, hy, cw, hh, r)
    c.rect(x0 + 36, hy + 64, 170, 26, 13, fill="#FFFFFF", a=0.16)
    c.text(x0 + 121, hy + 81.5, "CONTINUE WATCHING", 11, fill="#FFFFFF", weight=700, anchor="middle", ls=1.2)
    c.text(x0 + 36, hy + 134, "Northern Lights Over Tromsø", 32, fill="#FFFFFF", weight=700, family="Inter Display", ls=-0.6)
    c.text(x0 + 36, hy + 162, "38:12 left  ·  Documentaries", 14, fill="#FFFFFF", opacity=0.78)
    c.rect(x0 + 36, hy + 180, 260, 4, 2, fill="#FFFFFF", a=0.22)
    c.rect(x0 + 36, hy + 180, 260 * 0.62, 4, 2, fill="#FFFFFF")
    bx = x0 + 36
    bx += pill(c, bx, hy + 206, "Resume", "play", primary=True) + 10
    c.rect(bx, hy + 206, 140, 42, min(21, t["radius"]), fill="#FFFFFF", a=0.14)
    c.icon("refresh", bx + 18, hy + 218, 18, fill="#FFFFFF")
    c.text(bx + 44, hy + 232, "Start over", 14, fill="#FFFFFF", weight=600)
    # jump back in
    y = hy + hh + 50
    c.text(x0, y, "Jump back in", 20, weight=700, family="Inter Display", ls=-0.3)
    c.text(x0 + cw, y - 2, "Clear", 13, key="accent", weight=600, anchor="end")
    cwid = 212
    for i, (title, still, folder, ext, prog) in enumerate([LIB[1], LIB[2], LIB[3], LIB[0], LIB[7]]):
        cx = x0 + i * (cwid + 18)
        if cx + cwid > x0 + cw:
            break
        p = prog if prog >= 0 else 0.45
        card(c, cx, y + 20, cwid, S[still], title, f"{int(p*100)}% watched", progress=p)
    # mini player
    my = H - 92
    c.rect(x0 - 24, my, cw + 48, 76, t["radius"] + 2, key="surfaceHi")
    c.border(x0 - 24, my, cw + 48, 76, t["radius"] + 2)
    c.image(S["neon"], x0 - 14, my + 10, 100, 56, int(t["radius"] * 0.7))
    c.text(x0 + 100, my + 34, "Night Drive", 14, weight=600)
    c.text(x0 + 100, my + 54, "1:42 / 5:30", 12, key="textMuted")
    bxr = x0 + cw + 24 - 16
    for ic, size, filled in [("fullscreen", 38, False), (None, 6, False), ("skip-next", 38, False), ("pause", 46, True), ("skip-prev", 38, False)]:
        if ic is None:
            bxr -= size
            continue
        bxr -= size
        cy = my + 38 - size / 2
        if filled:
            c.add(f'<circle cx="{bxr+size/2}" cy="{my+38+4}" r="{size/2}" fill="{t["accent"][0]}" opacity="0.4" filter="url(#glowf)"/>')
            c.defs.append('<filter id="glowf" x="-100%" y="-100%" width="300%" height="300%"><feGaussianBlur stdDeviation="9"/></filter>')
            c.rect(bxr, cy, size, size, size / 2, key="accent")
            c.icon(ic, bxr + size / 2 - 11, cy + size / 2 - 11, 22, fill=t["onAccent"][0])
        else:
            c.icon(ic, bxr + size / 2 - 10, cy + size / 2 - 10, 20, key="text")
        bxr -= 14
    c.rect(x0 - 24 + 18, my + 74, cw + 48 - 36, 2, 1, key="text", a=0.08)
    c.rect(x0 - 24 + 18, my + 74, (cw + 12) * 0.31, 2, 1, key="accent")
    return render(c.svg(), os.path.join(OUT, out))


def player_frame(c, S, still, title, meta, pos, time_s, len_s, playing=True, queue=True, style="floating",
                 show_bubble=True, controls_offset=0, chrome=1.0, sheet=None):
    t = c.t
    W, H = c.w, c.h
    R = 14
    c.defs.append(f'<clipPath id="winclip"><rect width="{W}" height="{H}" rx="{R}"/></clipPath>')
    c.add('<g clip-path="url(#winclip)">')
    c.rect(0, 0, W, H, 0, fill=mix(t["bg"][0], "#000000", 0.75))
    vh = W * 9 / 16
    vy = (H - vh) / 2
    # ambient light
    c.image(still, -W * 0.06, vy - vh * 0.13, W * 1.12, vh * 1.26, 0, blur=60, opacity=0.6)
    c.image(still, 0, vy, W, vh, 0)
    # scrims
    c.defs.append('<linearGradient id="topScrim" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000" stop-opacity="0.6"/><stop offset="1" stop-color="#000" stop-opacity="0"/></linearGradient>')
    c.defs.append('<linearGradient id="botScrim" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity="0.7"/></linearGradient>')
    c.add(f'<g opacity="{chrome}">')
    c.add(f'<rect width="{W}" height="180" fill="url(#topScrim)"/>')
    c.add(f'<rect y="{H-260}" width="{W}" height="260" fill="url(#botScrim)"/>')
    # top bar
    c.rect(20, 20, 40, 40, 20, fill="#FFFFFF", a=0.08)
    c.icon("chevron-left", 30, 30, 20, fill="#FFFFFF")
    c.text(74, 38, title, 19, fill="#FFFFFF", weight=700, family="Inter Display")
    c.text(74, 58, meta, 12.5, fill="#FFFFFF", opacity=0.65)
    for i, ic in enumerate(["more", "queue"]):
        x = W - 60 - i * 54
        if ic == "queue" and queue:
            c.rect(x, 20, 40, 40, 20, key="accent", a=0.16)
            c.icon(ic, x + 10, 30, 20, key="accent")
        else:
            c.rect(x, 20, 40, 40, 20, fill="#FFFFFF", a=0.08)
            c.icon(ic, x + 10, 30, 20, fill="#FFFFFF")
    # controls
    docked = style == "docked"
    cw = W if docked else min(W - 48, 1040)
    ch = 120
    cx = (W - cw) / 2
    cy = H - ch - (0 if docked else 24) + controls_offset
    c.glass(cx, cy, cw, ch, 0 if docked else t["radius"] + 8, still, 0, vy, W, vh)
    def fmt(s):
        s = int(s); h, m, ss = s // 3600, (s % 3600) // 60, s % 60
        return f"{h}:{m:02d}:{ss:02d}" if h else f"{m}:{ss:02d}"
    sy = cy + 30
    c.text(cx + 18, sy + 5, fmt(time_s), 12.5, fill="#FFFFFF", weight=600)
    c.text(cx + cw - 18, sy + 5, fmt(len_s), 12.5, fill="#FFFFFF", weight=600, anchor="end", opacity=0.75)
    tx, tw = cx + 88, cw - 176
    c.rect(tx, sy - 5, tw, 10, 5, fill="#FFFFFF", a=0.18)
    c.defs.append(f'<linearGradient id="seekg" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="{t["accent"][0]}"/><stop offset="1" stop-color="{t["accentHi"][0]}"/></linearGradient>')
    c.add(f'<rect x="{tx}" y="{sy-5}" width="{tw*pos:.1f}" height="10" rx="5" fill="url(#seekg)"/>')
    kx = tx + tw * pos
    c.add(f'<circle cx="{kx:.1f}" cy="{sy}" r="8" fill="#FFFFFF" stroke="{t["accent"][0]}" stroke-width="3"/>')
    if show_bubble:
        lab = fmt(time_s)
        bw = len(lab) * 7.5 + 16
        c.rect(kx - bw / 2, sy - 44, bw, 26, 8, key="elevated")
        c.border(kx - bw / 2, sy - 44, bw, 26, 8)
        c.text(kx, sy - 26.5, lab, 12, weight=600, anchor="middle")
    by = cy + 62
    x = cx + 18
    for ic, size, filled in [("skip-prev", 40, False), ("back-10", 40, False), ("pause" if playing else "play", 52, True), ("fwd-10", 40, False), ("skip-next", 40, False)]:
        yy = by + 26 - size / 2
        if filled:
            c.add(f'<circle cx="{x+size/2}" cy="{yy+size/2+4}" r="{size/2}" fill="{t["accent"][0]}" opacity="0.55" filter="url(#glowp)"/>')
            c.rect(x, yy, size, size, size / 2, key="accent")
            c.icon(ic, x + size / 2 - 12, yy + size / 2 - 12, 24, fill=t["onAccent"][0])
        else:
            c.icon(ic, x + size / 2 - 10, yy + size / 2 - 10, 20, fill="#FFFFFF")
        x += size + 6
    c.defs.append('<filter id="glowp" x="-100%" y="-100%" width="300%" height="300%"><feGaussianBlur stdDeviation="11"/></filter>')
    # volume
    x += 8
    c.icon("volume", x + 10, by + 16, 20, fill="#FFFFFF")
    c.rect(x + 44, by + 24, 110, 5, 2.5, fill="#FFFFFF", a=0.16)
    c.rect(x + 44, by + 24, 110 * 0.72, 5, 2.5, key="accent")
    c.add(f'<circle cx="{x+44+110*0.72:.1f}" cy="{by+26.5}" r="7" fill="#FFFFFF" stroke="{t["accent"][0]}" stroke-width="3"/>')
    # right tools
    rx = cx + cw - 18
    tools = ["fullscreen", "camera", "aspect", "equalizer", "subtitles"]
    for ic in tools:
        rx -= 40
        if ic == "subtitles":
            c.rect(rx, by + 6, 40, 40, 20, key="accent", a=0.16)
            c.icon(ic, rx + 10, by + 16, 20, key="accent")
        else:
            c.icon(ic, rx + 10, by + 16, 20, fill="#FFFFFF")
        rx -= 6
    rx -= 58
    c.rect(rx, by + 10, 52, 32, 16, fill="#FFFFFF", a=0.08)
    c.text(rx + 26, by + 30.5, "1.0×", 13, fill="#FFFFFF", weight=700, anchor="middle")
    # up next
    if queue:
        qw, qx, qy = 340, W - 340 - 20, 80
        qh = cy - qy - 16
        c.glass(qx, qy, qw, qh, t["radius"] + 6, still, 0, vy, W, vh)
        c.text(qx + 16, qy + 34, "Up next", 16, weight=700)
        c.icon("repeat", qx + qw - 40, qy + 20, 18, key="text")
        c.rect(qx + qw - 92, qy + 12, 34, 34, 17, key="accent", a=0.16)
        c.icon("shuffle", qx + qw - 83, qy + 20, 16, key="accent")
        rows = [("Dunes at Golden Hour", "film"), ("Northern Lights Over Tromsø", "film"), ("Night Drive", "film"),
                ("Tidal", "film"), ("Violet Hour", "film"), ("Summer, Ending", "film")]
        for i, (name, kind) in enumerate(rows):
            ry = qy + 58 + i * 50
            if ry + 48 > qy + qh:
                break
            cur = name == title
            if cur:
                c.rect(qx + 14, ry, qw - 28, 48, int(t["radius"] * 0.6), key="accent", a=0.16)
                c.icon("sparkle", qx + 26, ry + 16, 16, key="accent")
            else:
                c.text(qx + 34, ry + 29, str(i + 1), 12, key="textMuted", anchor="middle")
            c.text(qx + 56, ry + 29, name, 13.5, key="accent" if cur else "text", weight=600 if cur else 400)
            c.icon("film", qx + qw - 40, ry + 17, 14, key="textMuted")
    if sheet == "speed":
        sx, sw2 = cx + cw - 400, 240
        opts = ["0.5×", "0.75×", "Normal", "1.25×", "1.5×", "2.0×"]
        sh = 50 + len(opts) * 42
        c.glass(sx, cy - sh - 12, sw2, sh, t["radius"] + 4, still, 0, vy, W, vh, tint="elevated", ta=0.8)
        c.text(sx + 20, cy - sh + 18, "PLAYBACK SPEED", 11, key="textMuted", weight=700, ls=1.1)
        for i, o in enumerate(opts):
            oy = cy - sh + 34 + i * 42
            sel = o == "1.25×"
            if sel:
                c.rect(sx + 10, oy, sw2 - 20, 40, 10, key="text", a=0.08)
                c.icon("check", sx + sw2 - 42, oy + 11, 18, key="accent")
            c.text(sx + 22, oy + 25, o, 14, key="accent" if sel else "text", weight=600 if sel else 400)
    c.add('</g></g>')


def screen_player(th="vela-night", out="player.png", W=1600, H=1000, **kw):
    t = theme(th)
    c = C(W, H, t)
    S = make_stills()
    still = S[kw.pop("still", "desert")]
    player_frame(c, S, still, kw.pop("title", "Dunes at Golden Hour"), "1920 × 1080  ·  1 of 6 in queue",
                 kw.pop("pos", 0.42), kw.pop("time_s", 1532), kw.pop("len_s", 3648), **kw)
    return render(c.svg(), os.path.join(OUT, out))


def screen_settings(th="vela-night", out="customize.png", W=1600, H=1000, accent_override=None):
    t = theme(th)
    if accent_override:
        t["accent"] = (accent_override, 1)
        t["accentHi"] = (lighten(accent_override, 0.18), 1)
    c = C(W, H, t)
    sw = window_shell(c, "settings")
    x0 = sw + 40
    c.text(x0, 106, "Customize", 34, weight=700, family="Inter Display", ls=-0.8)
    rail = [("palette", "Look & feel"), ("film", "Player"), ("play", "Playback"), ("subtitles", "Subtitles"), ("folder", "Library"), ("keyboard", "Shortcuts"), ("info", "About")]
    for i, (ic, lab) in enumerate(rail):
        y = 134 + i * 46
        if i == 0:
            c.rect(x0, y, 200, 42, t["radius"] * 0.75, key="accent", a=0.16)
            c.rect(x0 - 1, y + 12, 3, 18, 1.5, key="accent")
        c.icon(ic, x0 + 14, y + 11, 20, key="accent" if i == 0 else "textDim")
        c.text(x0 + 46, y + 26, lab, 14, key="text" if i == 0 else "textDim", weight=600 if i == 0 else 500)
    pill(c, x0, 134 + 7 * 46 + 16, "Reset to theme defaults", "refresh", compact=True)
    # card
    cx = x0 + 232
    cw = W - cx - 40
    cy = 64
    ch = H - cy - 24
    r = t["radius"] + 6
    c.rect(cx, cy, cw, ch, r, key="surface")
    c.border(cx, cy, cw, ch, r)
    c.text(cx + 18, cy + 36, "Look & feel", 18, weight=700)
    c.text(cx + 18, cy + 58, "Pick a theme, then make it yours. Every change is live.", 13, key="textMuted")
    themes = ["vela-night", "vela-day", "nebula", "ember", "aurora", "oled"]
    tx, ty = cx + 18, cy + 80
    for i, name in enumerate(themes):
        tt = theme(name)
        x = tx + (i % 3) * 186
        y = ty + (i // 3) * 142
        on = name == th
        c.add(f'<rect x="{x}" y="{y}" width="172" height="128" rx="16" fill="{tt["bg"][0]}"/>')
        c.add(f'<rect x="{x+0.5}" y="{y+0.5}" width="171" height="127" rx="16" fill="none" stroke="{t["accent"][0] if on else tt["border"][0]}" stroke-opacity="{1 if on else max(0.2, tt["border"][1])}" stroke-width="{2.5 if on else 1}"/>')
        c.add(f'<rect x="{x+12}" y="{y+12}" width="36" height="72" rx="7" fill="{tt["surface"][0]}"/>')
        c.add(f'<rect x="{x+56}" y="{y+12}" width="104" height="46" rx="8" fill="{tt["surface"][0]}"/>')
        c.add(f'<circle cx="{x+108}" cy="{y+35}" r="9" fill="{tt["accent"][0]}"/>')
        c.add(f'<rect x="{x+56}" y="{y+64}" width="57" height="6" rx="3" fill="{tt["accent"][0]}"/>')
        c.add(f'<rect x="{x+56}" y="{y+76}" width="83" height="6" rx="3" fill="{tt["surface"][0]}"/>')
        c.text(x + 12, y + 110, tt["name"], 13, fill=tt["text"][0], weight=600)
        if on:
            c.add(f'<circle cx="{x+150}" cy="{y+106}" r="11" fill="{t["accent"][0]}"/>')
            c.icon("check", x + 143, y + 99, 14, fill=t["onAccent"][0])
    # live preview panel on the right of gallery
    px = tx + 3 * 186 + 10
    pw = cx + cw - 18 - px
    if pw > 220:
        S = make_stills()
        c.text(px, ty + 14, "LIVE PREVIEW", 11, key="textMuted", weight=700, ls=1.1)
        c.image(S["violet"], px, ty + 26, pw, pw * 9 / 16, t["radius"])
        gy = ty + 26 + pw * 9 / 16 - 64
        c.glass(px + 12, gy, pw - 24, 52, t["radius"], S["violet"], px, ty + 26, pw, pw * 9 / 16)
        c.rect(px + 24, gy + 10, 32, 32, 16, key="accent")
        c.icon("pause", px + 31, gy + 17, 18, fill=t["onAccent"][0])
        c.rect(px + 70, gy + 23, pw - 110, 6, 3, fill="#FFFFFF", a=0.2)
        c.rect(px + 70, gy + 23, (pw - 110) * 0.55, 6, 3, key="accent")
    # rows
    rows = [
        ("sparkle", "Accent colour", "Tints buttons, progress, highlights and the ambient glow.", "swatches"),
        ("maximize", "Corner radius", "From razor-sharp to soft and bubbly.", ("slider", 0.55, "16px")),
        ("layers", "Glass blur", "How frosted the player panels are.", ("slider", 0.5, "48")),
        ("tune", "Density", "Spacing between everything.", ("seg", ["Compact", "Cozy", "Roomy"], 1)),
        ("film", "Control style", "Floating glass card, a full-width dock, or the bare minimum.", ("seg", ["Floating", "Docked", "Minimal"], 0)),
        ("sun-glow", "Ambient light", "Let the picture's colours glow into the letterbox.", ("toggle", True)),
        ("sparkle", "Animations", "Springy transitions everywhere.", ("toggle", True)),
    ]
    y = ty + 2 * 142 + 6
    for ic, title, desc, ctl in rows:
        if y + 64 > cy + ch - 10:
            break
        c.rect(cx + 18, y + 15, 34, 34, int(t["radius"] * 0.6), key="accent", a=0.14)
        c.icon(ic, cx + 26, y + 23, 18, key="accent")
        c.text(cx + 68, y + 29, title, 14, weight=600)
        c.text(cx + 68, y + 47, desc, 12.5, key="textMuted")
        rx = cx + cw - 18
        if ctl == "swatches":
            sw_ = ["#7C5CFF", "#4F8BFF", "#2EC5CE", "#3DDC97", "#C6F432", "#FFC145", "#FF8A3D", "#FF5C7A", "#F25FD0", "#E8E6F0"]
            sx = rx - len(sw_) * 34
            for j, col in enumerate(sw_):
                on = col.upper() == t["accent"][0].upper()
                c.add(f'<circle cx="{sx + j*34 + 13}" cy="{y+32}" r="13" fill="{col}" stroke="{t["text"][0] if on else "none"}" stroke-width="3"/>')
        elif ctl[0] == "slider":
            sx = rx - 180
            c.rect(sx, y + 30, 180, 4, 2, key="text", a=0.16)
            c.rect(sx, y + 30, 180 * ctl[1], 4, 2, key="accent")
            c.add(f'<circle cx="{sx+180*ctl[1]:.0f}" cy="{y+32}" r="8" fill="#FFFFFF" stroke="{t["accent"][0]}" stroke-width="3"/>')
            c.text(sx - 14, y + 37, ctl[2], 12, key="textMuted", anchor="end", weight=600)
        elif ctl[0] == "seg":
            labels, sel = ctl[1], ctl[2]
            widths = [len(l) * 7.3 + 24 for l in labels]
            tot = sum(widths) + 2 * (len(labels) - 1) + 8
            sx = rx - tot
            c.rect(sx, y + 14, tot, 36, min(18, t["radius"]), key="text", a=0.06)
            xx = sx + 4
            for j, l in enumerate(labels):
                if j == sel:
                    c.rect(xx, y + 18, widths[j], 28, min(14, t["radius"] * 0.8), key="accent")
                c.text(xx + widths[j] / 2, y + 37, l, 13, fill=t["onAccent"][0] if j == sel else t["textDim"][0], weight=600, anchor="middle")
                xx += widths[j] + 2
        elif ctl[0] == "toggle":
            sx = rx - 46
            c.rect(sx, y + 18, 46, 28, 14, key="accent")
            c.add(f'<circle cx="{sx+32}" cy="{y+32}" r="11" fill="{t["onAccent"][0]}"/>')
        c.rect(cx + 18, y + 63, cw - 36, 1, key="border")
        y += 64
    return render(c.svg(), os.path.join(OUT, out))


def screen_music(th="aurora", out="music.png", W=1600, H=1000):
    t = theme(th)
    c = C(W, H, t)
    S = make_stills()
    R = 14
    c.defs.append(f'<clipPath id="winclip"><rect width="{W}" height="{H}" rx="{R}"/></clipPath>')
    c.add('<g clip-path="url(#winclip)">')
    c.rect(0, 0, W, H, 0, fill=mix(t["bg"][0], "#000000", 0.5))
    # blurred artwork backdrop
    c.image(S["aurora"], -80, -80, W + 160, H + 160, 0, blur=70, opacity=0.55)
    s = 400
    ax, ay = (W - s) / 2, 150
    c.add(f'<rect x="{ax}" y="{ay+18}" width="{s}" height="{s}" rx="{t["radius"]*1.6}" fill="#000" opacity="0.45" filter="url(#artsh)"/>')
    c.defs.append('<filter id="artsh" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="24"/></filter>')
    c.image(S["aurora"], ax, ay, s, s, t["radius"] * 1.6, preserve="xMidYMid slice")
    # bars
    import random
    rnd = random.Random(4)
    bx = W / 2 - (24 * 10 - 5) / 2
    for i in range(24):
        hgt = 8 + rnd.random() * 34
        c.rect(bx + i * 10, ay + s + 28 + 44 - hgt, 5, hgt, 2.5, key="accent", a=0.85)
    c.text(W / 2, ay + s + 120, "Aurora Borealis (Ambient Mix)", 26, weight=700, family="Inter Display", anchor="middle", fill="#FFFFFF")
    c.text(W / 2, ay + s + 148, "Field Recordings  ·  Arctic Sessions", 14, anchor="middle", fill="#FFFFFF", opacity=0.7)
    # top bar
    c.rect(20, 20, 40, 40, 20, fill="#FFFFFF", a=0.08)
    c.icon("chevron-left", 30, 30, 20, fill="#FFFFFF")
    # docked controls
    ch = 116
    cy = H - ch
    c.glass(0, cy, W, ch, 0, S["aurora"], -80, -80, W + 160, H + 160, ta=0.55)
    sy = cy + 30
    c.text(18, sy + 5, "2:14", 12.5, fill="#FFFFFF", weight=600)
    c.text(W - 18, sy + 5, "6:02", 12.5, fill="#FFFFFF", weight=600, anchor="end", opacity=0.75)
    c.rect(88, sy - 2, W - 176, 4, 2, fill="#FFFFFF", a=0.18)
    c.rect(88, sy - 2, (W - 176) * 0.37, 4, 2, key="accent")
    by = cy + 56
    x = 18
    for ic, size, filled in [("skip-prev", 40, False), ("back-10", 40, False), ("pause", 52, True), ("fwd-10", 40, False), ("skip-next", 40, False)]:
        yy = by + 26 - size / 2
        if filled:
            c.rect(x, yy, size, size, size / 2, key="accent")
            c.icon(ic, x + size / 2 - 12, yy + size / 2 - 12, 24, fill=t["onAccent"][0])
        else:
            c.icon(ic, x + size / 2 - 10, yy + size / 2 - 10, 20, fill="#FFFFFF")
        x += size + 6
    x += 8
    c.icon("volume", x + 10, by + 16, 20, fill="#FFFFFF")
    c.rect(x + 44, by + 24, 110, 5, 2.5, fill="#FFFFFF", a=0.16)
    c.rect(x + 44, by + 24, 77, 5, 2.5, key="accent")
    c.add(f'<circle cx="{x+44+77}" cy="{by+26.5}" r="7" fill="#FFFFFF" stroke="{t["accent"][0]}" stroke-width="3"/>')
    rx = W - 18
    for ic in ["fullscreen", "equalizer", "subtitles"]:
        rx -= 40
        if ic == "equalizer":
            c.rect(rx, by + 6, 40, 40, 20, key="accent", a=0.16)
            c.icon(ic, rx + 10, by + 16, 20, key="accent")
        else:
            c.icon(ic, rx + 10, by + 16, 20, fill="#FFFFFF")
        rx -= 6
    rx -= 58
    c.rect(rx, by + 10, 52, 32, 16, fill="#FFFFFF", a=0.08)
    c.text(rx + 26, by + 30.5, "1.0×", 13, fill="#FFFFFF", weight=700, anchor="middle")
    c.add("</g>")
    return render(c.svg(), os.path.join(OUT, out))


def banner(out="banner.png", W=1920, H=1080):
    t = theme("vela-night")
    c = C(W, H, t)
    c.defs.append(f'<linearGradient id="bb" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2A1F66"/><stop offset="0.55" stop-color="#15103A"/><stop offset="1" stop-color="#0A0920"/></linearGradient>')
    c.defs.append('<radialGradient id="bglow" cx="0.3" cy="0.45" r="0.6"><stop offset="0" stop-color="#7C5CFF" stop-opacity="0.45"/><stop offset="1" stop-color="#7C5CFF" stop-opacity="0"/></radialGradient>')
    c.add(f'<rect width="{W}" height="{H}" fill="url(#bb)"/><rect width="{W}" height="{H}" fill="url(#bglow)"/>')
    import random
    rnd = random.Random(7)
    for _ in range(220):
        c.add(f'<circle cx="{rnd.random()*W:.0f}" cy="{rnd.random()*H:.0f}" r="{rnd.random()*1.4+0.3:.1f}" fill="#FFFFFF" opacity="{rnd.random()*0.6+0.15:.2f}"/>')
    c.add(f'<image href="{os.path.join(ROOT, "branding", "vela.svg")}" x="170" y="{H/2-200}" width="400" height="400"/>')
    c.text(640, H / 2 - 10, "Vela", 168, weight=700, family="Inter Display", fill="#FFFFFF", ls=-6)
    c.text(648, H / 2 + 70, "Play anything, beautifully.", 46, weight=500, fill="#C9BCFF", family="Inter Display", ls=-0.8)
    c.text(650, H / 2 + 132, "Built on libVLC  ·  Themeable to the last pixel  ·  Linux", 26, weight=500, fill="#FFFFFF", opacity=0.6)
    return render(c.svg(), os.path.join(OUT, out))


if __name__ == "__main__":
    print(screen_home())
    print(screen_player())
    print(screen_settings())
    print(screen_music())
    print(banner())
