"""Builds Vela's social promo (9:16 and 16:9) from the rendered screens.

    python3 branding/tools/promo.py <frames-dir> <out-dir>

Needs Pillow, numpy and ffmpeg. Everything — visuals and soundtrack — is
generated here, so the result is free to post anywhere.
"""
import math, os, random, subprocess, sys, wave

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
SRC = sys.argv[1] if len(sys.argv) > 1 else "/tmp/vela-promo"
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(ROOT, "branding", "promo")
os.makedirs(OUT, exist_ok=True)

FPS = 30
DUR = 24.0
SHOTS = os.path.join(ROOT, "branding", "screenshots")
FONT_DIR = "/usr/share/fonts/opentype/inter"
if not os.path.isdir(FONT_DIR):
    FONT_DIR = os.path.join(ROOT, "fonts")

ACCENT = (124, 92, 255)
LAVENDER = (201, 188, 255)
MINT = (94, 234, 212)


def font(weight, size, display=True):
    name = {"bold": "Bold", "semi": "SemiBold", "med": "Medium", "reg": "Regular"}[weight]
    fam = "InterDisplay" if display and weight in ("bold", "semi") else "Inter"
    return ImageFont.truetype(os.path.join(FONT_DIR, f"{fam}-{name}.otf"), size)


# ------------------------------------------------------------------ easing

def clamp(x, a=0.0, b=1.0):
    return max(a, min(b, x))


def ease_out(t):
    return 1 - (1 - clamp(t)) ** 3


def ease_in_out(t):
    t = clamp(t)
    return 4 * t * t * t if t < 0.5 else 1 - (-2 * t + 2) ** 3 / 2


def back_out(t, s=1.7):
    t = clamp(t) - 1
    return t * t * ((s + 1) * t + s) + 1


def window(t, a, b, fade=0.35):
    """0..1 visibility for something shown between a and b."""
    if t < a or t > b:
        return 0.0
    return min(clamp((t - a) / fade), clamp((b - t) / fade))


# ------------------------------------------------------------------ assets

_cache = {}


def load(path):
    if path not in _cache:
        _cache[path] = Image.open(path).convert("RGBA")
    return _cache[path]


def rounded(img, r):
    key = ("mask", img.size, r)  # cache the mask only, never the image itself
    if key not in _cache:
        m = Image.new("L", img.size, 0)
        ImageDraw.Draw(m).rounded_rectangle([0, 0, img.size[0] - 1, img.size[1] - 1], r, fill=255)
        _cache[key] = np.array(m)
    out = img.copy()
    out.putalpha(Image.fromarray(np.minimum(np.array(out.getchannel("A")), _cache[key])))
    return out


def shadow(size, r, blur=40, alpha=150):
    key = ("shadow", size, r, blur, alpha)
    if key not in _cache:
        pad = blur * 3
        im = Image.new("RGBA", (size[0] + pad * 2, size[1] + pad * 2), (0, 0, 0, 0))
        ImageDraw.Draw(im).rounded_rectangle([pad, pad + blur // 2, pad + size[0], pad + size[1] + blur // 2], r, fill=(5, 3, 20, alpha))
        _cache[key] = (im.filter(ImageFilter.GaussianBlur(blur)), pad)
    return _cache[key]


def paste_window(canvas, img, cx, cy, width, alpha=1.0, zoom=1.0, focus=(0.5, 0.5), radius=28, aspect=None):
    """Draw a screenshot as a floating rounded window. `zoom`>1 crops in around `focus`;
    `aspect` (w/h) crops the shot to a taller frame for vertical video."""
    if alpha <= 0.01:
        return
    w0, h0 = img.size
    if aspect and aspect < w0 / h0:
        cw, ch = h0 * aspect / zoom, h0 / zoom
    elif zoom > 1.0:
        cw, ch = w0 / zoom, h0 / zoom
    else:
        cw, ch = w0, h0
    if (cw, ch) != (w0, h0):
        fx = clamp(focus[0] * w0 - cw / 2, 0, w0 - cw)
        fy = clamp(focus[1] * h0 - ch / 2, 0, h0 - ch)
        img = img.crop((int(fx), int(fy), int(fx + cw), int(fy + ch)))
        w0, h0 = img.size
    height = int(width * h0 / w0)
    im = img.resize((int(width), height), Image.LANCZOS)
    im = rounded(im, radius)
    sh, pad = shadow((int(width), height), radius)
    x, y = int(cx - width / 2), int(cy - height / 2)
    if alpha < 1:
        sh = sh.copy(); sh.putalpha(sh.getchannel("A").point(lambda v: int(v * alpha)))
        im = im.copy(); im.putalpha(im.getchannel("A").point(lambda v: int(v * alpha)))
    canvas.alpha_composite(sh, (x - pad, y - pad))
    canvas.alpha_composite(im, (x, y))
    # thin top highlight
    d = ImageDraw.Draw(canvas)
    d.rounded_rectangle([x, y, x + width - 1, y + height - 1], radius, outline=(255, 255, 255, int(28 * alpha)), width=2)


def text_center(canvas, txt, cy, size, weight="bold", color=(255, 255, 255), alpha=1.0, dy=0, tracking=0, display=True):
    if alpha <= 0.01:
        return
    f = font(weight, size, display)
    layer = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    if tracking:
        widths = [d.textlength(ch, font=f) + tracking for ch in txt]
        total = sum(widths) - tracking
        x = canvas.size[0] / 2 - total / 2
        for ch, w in zip(txt, widths):
            d.text((x, cy + dy), ch, font=f, fill=(*color, int(255 * alpha)), anchor="lm")
            x += w
    else:
        d.text((canvas.size[0] / 2, cy + dy), txt, font=f, fill=(*color, int(255 * alpha)), anchor="mm")
    canvas.alpha_composite(layer)


def background(W, H, t, rnd_stars):
    y, x = np.mgrid[0:H, 0:W].astype(np.float32)
    base_top = np.array([22, 16, 58], np.float32)
    base_bot = np.array([8, 7, 24], np.float32)
    g = (y / H)[..., None]
    img = base_top * (1 - g) + base_bot * g
    # two drifting accent blobs
    for (bx, by, r, col, sp) in [(0.3, 0.35, 0.55, ACCENT, 0.13), (0.75, 0.7, 0.45, (46, 197, 206), 0.09)]:
        cx = (bx + 0.08 * math.sin(t * sp * 2 * math.pi)) * W
        cy = (by + 0.06 * math.cos(t * sp * 2 * math.pi)) * H
        d = np.sqrt(((x - cx) / (r * max(W, H))) ** 2 + ((y - cy) / (r * max(W, H))) ** 2)
        k = np.clip(1 - d, 0, 1) ** 2 * 0.55
        img = img * (1 - k[..., None]) + np.array(col, np.float32) * k[..., None] * 0.9 + img * k[..., None] * 0.1
    out = Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGB").convert("RGBA")
    d = ImageDraw.Draw(out)
    for (sx, sy, sr, ph) in rnd_stars:
        a = 0.35 + 0.65 * (0.5 + 0.5 * math.sin(t * 2.2 + ph))
        d.ellipse([sx - sr, sy - sr, sx + sr, sy + sr], fill=(255, 255, 255, int(200 * a)))
    return out


# ------------------------------------------------------------------ frames

def build(W, H, name):
    vertical = H > W
    frames_dir = os.path.join(SRC, f"frames-{name}")
    os.makedirs(frames_dir, exist_ok=True)
    rnd = random.Random(11)
    stars = [(rnd.random() * W, rnd.random() * H, rnd.random() * 1.6 + 0.4, rnd.random() * 6.28) for _ in range(int(W * H / 9000))]

    bg_cache = {}
    icon = load(os.path.join(ROOT, "branding", "vela-1024.png"))
    player = load(os.path.join(SHOTS, "player.png"))
    home = load(os.path.join(SHOTS, "home.png"))
    music = load(os.path.join(SHOTS, "music.png"))
    themes = ["vela-night", "nebula", "ember", "aurora", "vela-day", "oled"]
    tplayers = [load(os.path.join(SRC, f"player-{t}.png")) for t in themes]
    tcustom = [load(os.path.join(SRC, f"customize-{t}.png")) for t in themes]
    speed = load(os.path.join(SRC, "player-speed.png"))

    win_w = int(W * 0.9) if vertical else int(W * 0.6)
    win_cy = H * 0.6 if vertical else H * 0.6
    cap_y = H * 0.25 if vertical else H * 0.1
    AR = 0.92 if vertical else None
    sub_y = cap_y + (90 if vertical else 74)
    big = 92 if vertical else 84
    sub = 40 if vertical else 34

    total = int(DUR * FPS)
    sample = os.environ.get("PROMO_SAMPLE")
    indices = [int(float(x) * FPS) for x in sample.split(",")] if sample else range(total)
    for i in indices:
        t = i / FPS
        bkey = round(t * 6) / 6  # background animates at 6 fps — plenty for slow blobs
        if bkey not in bg_cache:
            bg_cache.clear()
            bg_cache[bkey] = background(W, H, bkey, stars)
        cv = bg_cache[bkey].copy()

        # S1 0–2.6 logo reveal ------------------------------------------------
        if t < 2.9:
            a = window(t, 0.0, 2.6, 0.3)
            s = back_out((t - 0.1) / 0.8) if t > 0.1 else 0
            size = int((W * (0.42 if vertical else 0.2)) * max(0.01, s))
            if size > 4:
                glow = Image.new("RGBA", cv.size, (0, 0, 0, 0))
                gd = ImageDraw.Draw(glow)
                gr = size * 0.9
                cx, cy = W / 2, H * (0.42 if vertical else 0.4)
                gd.ellipse([cx - gr, cy - gr, cx + gr, cy + gr], fill=(*ACCENT, int(120 * a)))
                cv.alpha_composite(glow.filter(ImageFilter.GaussianBlur(size * 0.35)))
                ic = icon.resize((size, size), Image.LANCZOS)
                if a < 1:
                    ic.putalpha(ic.getchannel("A").point(lambda v: int(v * a)))
                cv.alpha_composite(ic, (int(cx - size / 2), int(cy - size / 2)))
            wy = H * (0.42 if vertical else 0.4) + (W * (0.42 if vertical else 0.2)) / 2 + (110 if vertical else 90)
            text_center(cv, "Vela", wy, 150 if vertical else 120, alpha=a * ease_out((t - 0.7) / 0.5), dy=30 * (1 - ease_out((t - 0.7) / 0.5)), tracking=-4)
            text_center(cv, "Play anything, beautifully.", wy + (120 if vertical else 100), 46 if vertical else 40, "semi", LAVENDER,
                        alpha=a * ease_out((t - 1.25) / 0.5), dy=20 * (1 - ease_out((t - 1.25) / 0.5)))

        # S2 2.6–4.6 kinetic statement ------------------------------------------
        if 2.5 < t < 4.8:
            a = window(t, 2.6, 4.6, 0.25)
            l1 = ease_out((t - 2.65) / 0.45)
            l2 = ease_out((t - 3.2) / 0.45)
            text_center(cv, "Powered by libVLC.", H / 2 - (70 if vertical else 60), 96 if vertical else 92, alpha=a * l1, dy=40 * (1 - l1))
            text_center(cv, "A whole new face.", H / 2 + (70 if vertical else 60), 96 if vertical else 92, color=LAVENDER, alpha=a * l2, dy=40 * (1 - l2))

        # S3 4.6–8.6 player hero ---------------------------------------------------
        if 4.5 < t < 8.8:
            a = window(t, 4.6, 8.6, 0.35)
            rise = ease_out((t - 4.6) / 0.8)
            z = 1.0 + 0.10 * ease_in_out((t - 5.2) / 3.4)
            img = player if t < 6.9 else speed
            paste_window(cv, img, W / 2, win_cy + (1 - rise) * H * 0.3, win_w, a, zoom=z, focus=(0.5, 0.8) if t < 6.9 else (0.68, 0.75), aspect=AR)
            c = ease_out((t - 4.9) / 0.5)
            text_center(cv, "Frosted glass." if t < 6.9 else "Every control, one tap.", cap_y, big, alpha=a * c, dy=20 * (1 - c))
            text_center(cv, "Ambient light spills from the picture." if t < 6.9 else "Speed, tracks, EQ, snapshots.", sub_y, sub, "med", LAVENDER, alpha=a * c, display=False)

        # S4 8.6–12.6 theme montage ------------------------------------------------
        if 8.5 < t < 12.8:
            a = window(t, 8.6, 12.6, 0.3)
            k = (t - 8.75) / 0.6
            idx = int(clamp(k, 0, len(themes) - 1e-6))
            frac = clamp((k - idx) / 0.25) if idx < len(themes) - 1 else 0
            cur = tplayers[idx]
            if idx + 1 < len(themes) and k - idx > 0.75:
                blend = clamp((k - idx - 0.75) / 0.25)
                cur = Image.blend(tplayers[idx], tplayers[idx + 1], blend)
            pop = 1 + 0.015 * math.sin(clamp(k - idx) * math.pi)
            paste_window(cv, cur, W / 2, win_cy, int(win_w * pop), a, focus=(0.42, 0.7), aspect=AR)
            text_center(cv, "Six themes." if t < 10.9 else "Any accent. Any vibe.", cap_y, big, alpha=a)
            names = ["Vela Night", "Nebula", "Ember", "Aurora", "Vela Day", "OLED Black"]
            text_center(cv, names[idx], sub_y, sub, "med", LAVENDER, alpha=a, display=False)

        # S5 12.6–15.6 customize ---------------------------------------------------
        if 12.5 < t < 15.8:
            a = window(t, 12.6, 15.6, 0.3)
            z = 1.0 + (0.2 if vertical else 0.55) * ease_in_out((t - 13.3) / 1.8)
            k = (t - 12.6) / 0.5
            img = tcustom[0] if t < 14.3 else tcustom[int(clamp((t - 14.3) / 0.25, 0, 5.99))]
            paste_window(cv, img, W / 2, win_cy, win_w, a, zoom=z, focus=(0.66, 0.3) if vertical else (0.56, 0.62), aspect=AR)
            c = ease_out(k)
            text_center(cv, "Customize everything.", cap_y, big, alpha=a * c, dy=20 * (1 - c))
            text_center(cv, "Radius · blur · density · fonts · motion", sub_y, sub, "med", LAVENDER, alpha=a * c, display=False)

        # S6 15.6–18.6 home -------------------------------------------------------
        if 15.5 < t < 18.8:
            a = window(t, 15.6, 18.6, 0.3)
            z = 1.0 + 0.08 * ease_in_out((t - 15.6) / 3.0)
            slide = ease_out((t - 15.6) / 0.7)
            paste_window(cv, home, W / 2 + (1 - slide) * W * 0.4, win_cy, win_w, a, zoom=z, focus=(0.42, 0.45), aspect=AR)
            c = ease_out((t - 15.8) / 0.5)
            text_center(cv, "Pick up where you left off.", cap_y, big - (12 if vertical else 0), alpha=a * c, dy=20 * (1 - c))
            text_center(cv, "Resume, queue, library — all in one place.", sub_y, sub, "med", LAVENDER, alpha=a * c, display=False)

        # S7 18.6–20.6 music --------------------------------------------------------
        if 18.5 < t < 20.8:
            a = window(t, 18.6, 20.6, 0.3)
            z = 1.0 + 0.06 * ease_in_out((t - 18.6) / 2.0)
            paste_window(cv, music, W / 2, win_cy, win_w, a, zoom=z, focus=(0.5, 0.4), aspect=AR)
            c = ease_out((t - 18.7) / 0.5)
            text_center(cv, "Music, too.", cap_y, big, alpha=a * c, dy=20 * (1 - c))
            text_center(cv, "10-band EQ · artwork · gapless queue", sub_y, sub, "med", LAVENDER, alpha=a * c, display=False)

        # S8 20.6–24 end card ---------------------------------------------------------
        if t > 20.5:
            a = clamp((t - 20.6) / 0.4) * clamp((DUR - t) / 0.45)
            s = back_out((t - 20.6) / 0.7)
            size = int(W * (0.3 if vertical else 0.14) * max(0.01, s))
            cy = H * (0.36 if vertical else 0.34)
            if size > 4:
                glow = Image.new("RGBA", cv.size, (0, 0, 0, 0))
                gd = ImageDraw.Draw(glow)
                gr = size * 0.9
                gd.ellipse([W / 2 - gr, cy - gr, W / 2 + gr, cy + gr], fill=(*ACCENT, int(110 * a)))
                cv.alpha_composite(glow.filter(ImageFilter.GaussianBlur(size * 0.35)))
                ic = icon.resize((size, size), Image.LANCZOS)
                ic.putalpha(ic.getchannel("A").point(lambda v: int(v * a)))
                cv.alpha_composite(ic, (int(W / 2 - size / 2), int(cy - size / 2)))
            base = cy + W * (0.3 if vertical else 0.14) / 2
            c = ease_out((t - 21.0) / 0.5)
            text_center(cv, "Vela", base + (120 if vertical else 90), 140 if vertical else 110, alpha=a * c, dy=24 * (1 - c), tracking=-4)
            c2 = ease_out((t - 21.4) / 0.5)
            text_center(cv, "Free & open source media player for Linux", base + (230 if vertical else 180), 40 if vertical else 34, "med", LAVENDER, alpha=a * c2, display=False)
            c3 = ease_out((t - 21.8) / 0.5)
            # store pills
            labels = ["Flathub", "Arch", "Fedora"]
            f = font("semi", 34 if vertical else 30, False)
            d0 = ImageDraw.Draw(cv)
            widths = [d0.textlength(l, font=f) + 56 for l in labels]
            gap = 18
            x = W / 2 - (sum(widths) + gap * 2) / 2
            py = base + (330 if vertical else 260) + 20 * (1 - c3)
            layer = Image.new("RGBA", cv.size, (0, 0, 0, 0))
            d = ImageDraw.Draw(layer)
            for l, w in zip(labels, widths):
                d.rounded_rectangle([x, py, x + w, py + 66], 33, fill=(255, 255, 255, int(26 * a * c3)), outline=(255, 255, 255, int(60 * a * c3)), width=2)
                d.text((x + w / 2, py + 33), l, font=f, fill=(255, 255, 255, int(255 * a * c3)), anchor="mm")
                x += w + gap
            cv.alpha_composite(layer)

        cv.convert("RGB").save(os.path.join(frames_dir, f"{i:05d}.png"), compress_level=1)
    return frames_dir


# ------------------------------------------------------------------ audio

def soundtrack(path, dur=DUR, sr=44100):
    n = int(dur * sr)
    t = np.arange(n) / sr
    out = np.zeros(n)
    bpm = 100
    beat = 60 / bpm

    def note(f):
        return 440 * 2 ** ((f - 69) / 12)

    # Am – F – C – G pad (2 bars each @100 bpm ≈ 4.8 s), detuned & soft
    chords = [[57, 60, 64, 69], [53, 57, 60, 65], [48, 55, 60, 64], [55, 59, 62, 67]]
    seg = beat * 8
    for k in range(int(dur / seg) + 1):
        ch = chords[k % 4]
        a, b = k * seg, min(dur, (k + 1) * seg + 0.6)
        m = (t >= a) & (t < b)
        tt = t[m] - a
        env = np.minimum(1, tt / 0.9) * np.minimum(1, (b - a - tt) / 0.8)
        for f in ch:
            for det in (-0.12, 0.12):
                fr = note(f + det)
                out[m] += env * (np.sin(2 * np.pi * fr * tt) + 0.3 * np.sin(4 * np.pi * fr * tt) + 0.12 * np.sin(6 * np.pi * fr * tt)) * 0.035
    # sub bass on roots
    for k in range(int(dur / seg) + 1):
        root = chords[k % 4][0] - 12
        a = k * seg
        for j in range(8):
            st = a + j * beat
            if st < 2.6 or st >= dur - 0.5:
                continue
            m = (t >= st) & (t < st + beat * 0.9)
            tt = t[m] - st
            out[m] += np.sin(2 * np.pi * note(root) * tt) * np.exp(-tt * 3) * 0.16
    # kick + hats from the "engine" line onwards
    rng = np.random.default_rng(3)
    st = 2.6
    while st < dur - 1.0:
        m = (t >= st) & (t < st + 0.35)
        tt = t[m] - st
        f = 45 + 110 * np.exp(-tt * 28)
        out[m] += np.sin(2 * np.pi * np.cumsum(f) / sr) * np.exp(-tt * 9) * 0.5
        hs = st + beat / 2
        mh = (t >= hs) & (t < hs + 0.06)
        noise = rng.standard_normal(mh.sum())
        noise = np.diff(np.concatenate([[0], noise]))  # crude high-pass
        out[mh] += noise * np.exp(-(t[mh] - hs) * 70) * 0.05
        st += beat
    # whooshes into each scene
    for s in (2.6, 4.6, 8.6, 12.6, 15.6, 18.6, 20.6):
        a = s - 0.55
        m = (t >= a) & (t < s + 0.1)
        tt = t[m] - a
        noise = rng.standard_normal(m.sum())
        y = np.zeros_like(noise)
        alpha = np.clip(tt / 0.65, 0.02, 1) * 0.35
        for i in range(1, len(noise)):
            y[i] = y[i - 1] + alpha[i] * (noise[i] - y[i - 1])
        out[m] += y * np.sin(np.pi * np.clip(tt / 0.65, 0, 1)) * 0.22
    # shimmer on logo hits
    for s in (0.15, 20.65):
        m = (t >= s) & (t < s + 2.5)
        tt = t[m] - s
        for f in (88, 93, 96):
            out[m] += np.sin(2 * np.pi * note(f) * tt) * np.exp(-tt * 1.6) * 0.03
    # master: soft clip, fades
    out = np.tanh(out * 1.4) * 0.85
    out *= np.minimum(1, t / 0.3) * np.minimum(1, (dur - t) / 1.2)
    stereo = np.stack([out, np.roll(out, 220)], axis=1)
    pcm = (np.clip(stereo, -1, 1) * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes(pcm.tobytes())


def encode(frames_dir, audio, out):
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-framerate", str(FPS), "-i", os.path.join(frames_dir, "%05d.png"),
                    "-i", audio, "-c:v", "libx264", "-preset", "slow", "-crf", "18", "-pix_fmt", "yuv420p",
                    "-profile:v", "high", "-movflags", "+faststart", "-c:a", "aac", "-b:a", "192k", "-shortest", out], check=True)


if __name__ == "__main__":
    audio = os.path.join(SRC, "vela-soundtrack.wav")
    soundtrack(audio)
    which = sys.argv[3] if len(sys.argv) > 3 else "both"
    if which in ("both", "vertical"):
        fd = build(1080, 1920, "vertical")
        encode(fd, audio, os.path.join(OUT, "vela-promo-9x16.mp4"))
    if which in ("both", "landscape"):
        fd = build(1920, 1080, "landscape")
        encode(fd, audio, os.path.join(OUT, "vela-promo-16x9.mp4"))
    print("done")
