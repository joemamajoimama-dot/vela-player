"""Procedural, copyright-free 'film stills' used for screenshots and the promo."""
import math, random

PALETTES = {
    "aurora":  dict(sky=["#04122B", "#0B3D4F", "#1E7B6E"], sun="#B8FFE4", glow="#3DDC97", hills=["#0A2A33", "#071C24", "#040F15"], stars=True, aurora=True),
    "dusk":    dict(sky=["#1B0B3A", "#6B2C8F", "#FF7A59"], sun="#FFD27A", glow="#FF8A3D", hills=["#3A1846", "#24102F", "#120819"], stars=True),
    "desert":  dict(sky=["#3B1C0E", "#C2562B", "#FFC37A"], sun="#FFF1C2", glow="#FFB547", hills=["#7A3416", "#4E200D", "#2A1006"], stars=False),
    "ocean":   dict(sky=["#061A33", "#1B4F8A", "#7FB8E8"], sun="#FFFFFF", glow="#9FD3FF", hills=["#0E2C4E", "#0A2039", "#061526"], stars=False, water=True),
    "neon":    dict(sky=["#0A0618", "#2A0F4F", "#F25FD0"], sun="#FFE3F7", glow="#F25FD0", hills=["#1A0B33", "#110723", "#080312"], stars=True, grid=True),
    "alpine":  dict(sky=["#0F2A4A", "#4F8BC9", "#DDEBFA"], sun="#FFFFFF", glow="#FFFFFF", hills=["#E8F0FA", "#5D7A99", "#2B3F57"], stars=False, snow=True),
    "forest":  dict(sky=["#0B1A12", "#2F5D3A", "#C9E7A8"], sun="#FFF7D6", glow="#E8F5B0", hills=["#1D3B24", "#132A19", "#0A170E"], stars=False),
    "violet":  dict(sky=["#0B0A16", "#2A1F66", "#7C5CFF"], sun="#E9E2FF", glow="#9B83FF", hills=["#1A1440", "#120E2E", "#0A081A"], stars=True),
}

def ridge(w, h, base, amp, rnd, n=14):
    pts = []
    for i in range(n + 1):
        x = w * i / n
        y = base - amp * (0.45 + 0.55 * rnd.random()) * (0.6 + 0.4 * math.sin(i * 1.7 + rnd.random()))
        pts.append((x, y))
    d = f"M0 {h} L0 {pts[0][1]:.1f} "
    for i in range(1, len(pts)):
        x0, y0 = pts[i - 1]; x1, y1 = pts[i]
        cx = (x0 + x1) / 2
        d += f"Q{x0 + (x1-x0)*0.25:.1f} {y0:.1f} {cx:.1f} {(y0+y1)/2:.1f} T{x1:.1f} {y1:.1f} "
    d += f"L{w} {h} Z"
    return d

def scene(name, w, h, seed=1, uid="s"):
    p = PALETTES[name]; rnd = random.Random(seed)
    o = [f'<defs><linearGradient id="{uid}sky" x1="0" y1="0" x2="0" y2="1">'
         f'<stop offset="0" stop-color="{p["sky"][0]}"/><stop offset="0.62" stop-color="{p["sky"][1]}"/><stop offset="1" stop-color="{p["sky"][2]}"/></linearGradient>'
         f'<radialGradient id="{uid}glow"><stop offset="0" stop-color="{p["glow"]}" stop-opacity="0.75"/><stop offset="1" stop-color="{p["glow"]}" stop-opacity="0"/></radialGradient>'
         f'<filter id="{uid}soft" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="{w*0.02:.1f}"/></filter></defs>']
    o.append(f'<rect width="{w}" height="{h}" fill="url(#{uid}sky)"/>')
    if p.get("stars"):
        for _ in range(int(w * h / 9000)):
            x, y = rnd.random() * w, rnd.random() * h * 0.55
            o.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{rnd.random()*1.3+0.3:.2f}" fill="#FFFFFF" opacity="{rnd.random()*0.7+0.2:.2f}"/>')
    if p.get("aurora"):
        for k in range(3):
            y0 = h * (0.18 + k * 0.08)
            d = f"M0 {y0:.0f} " + " ".join(f"Q{w*(i+0.5)/5:.0f} {y0 + (rnd.random()-0.5)*h*0.25:.0f} {w*(i+1)/5:.0f} {y0 + (rnd.random()-0.5)*h*0.1:.0f}" for i in range(5))
            o.append(f'<path d="{d}" stroke="{["#3DDC97","#7CF0BF","#B98BFF"][k]}" stroke-width="{h*0.07:.0f}" fill="none" opacity="0.45" filter="url(#{uid}soft)"/>')
    sx, sy, sr = w * (0.62 + rnd.random() * 0.12), h * (0.5 + rnd.random() * 0.06), h * 0.11
    o.append(f'<circle cx="{sx:.0f}" cy="{sy:.0f}" r="{sr*3.2:.0f}" fill="url(#{uid}glow)"/>')
    o.append(f'<circle cx="{sx:.0f}" cy="{sy:.0f}" r="{sr:.0f}" fill="{p["sun"]}"/>')
    if p.get("grid"):
        hz = h * 0.68
        o.append(f'<rect y="{hz:.0f}" width="{w}" height="{h-hz:.0f}" fill="#0A0618"/>')
        for i in range(-12, 13):
            o.append(f'<line x1="{w/2 + i*w*0.02:.0f}" y1="{hz:.0f}" x2="{w/2 + i*w*0.14:.0f}" y2="{h}" stroke="#F25FD0" stroke-width="1.4" opacity="0.6"/>')
        for j in range(1, 9):
            y = hz + (h - hz) * (j / 8) ** 1.8
            o.append(f'<line x1="0" y1="{y:.0f}" x2="{w}" y2="{y:.0f}" stroke="#F25FD0" stroke-width="1.2" opacity="0.5"/>')
    else:
        for i, col in enumerate(p["hills"]):
            base = h * (0.62 + i * 0.12)
            o.append(f'<path d="{ridge(w, h, base, h*(0.22 - i*0.05), rnd)}" fill="{col}"/>')
        if p.get("water"):
            wy = h * 0.74
            o.append(f'<rect y="{wy:.0f}" width="{w}" height="{h-wy:.0f}" fill="#0A2A4A"/>')
            o.append(f'<ellipse cx="{sx:.0f}" cy="{wy + (h-wy)*0.45:.0f}" rx="{sr*0.9:.0f}" ry="{(h-wy)*0.5:.0f}" fill="{p["sun"]}" opacity="0.35" filter="url(#{uid}soft)"/>')
    # gentle vignette
    o.append(f'<rect width="{w}" height="{h}" fill="url(#{uid}vig)"/>')
    o.insert(1, f'<defs><radialGradient id="{uid}vig" cx="0.5" cy="0.5" r="0.75"><stop offset="0.6" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity="0.45"/></radialGradient></defs>')
    return "".join(o)

def scene_svg(name, w, h, seed=1):
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">{scene(name, w, h, seed)}</svg>'
