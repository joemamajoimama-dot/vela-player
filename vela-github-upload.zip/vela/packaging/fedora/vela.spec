Name:           vela
Version:        0.1.0
Release:        1%{?dist}
Summary:        A beautiful, deeply customizable media player built on libVLC

License:        GPL-3.0-or-later AND OFL-1.1
URL:            https://github.com/velaplayer/vela
Source0:        %{url}/archive/refs/tags/v%{version}/%{name}-%{version}.tar.gz

BuildRequires:  cmake
BuildRequires:  gcc-c++
BuildRequires:  ninja-build
BuildRequires:  pkgconfig(libvlc)
BuildRequires:  cmake(Qt6Core)
BuildRequires:  cmake(Qt6Gui)
BuildRequires:  cmake(Qt6Quick)
BuildRequires:  cmake(Qt6QuickControls2)
BuildRequires:  cmake(Qt6Svg)
BuildRequires:  desktop-file-utils
BuildRequires:  libappstream-glib

Requires:       hicolor-icon-theme
Requires:       qt6-qtsvg%{?_isa}
# libvlc itself is pulled in automatically through its soname.
# Plugin package names differ between Fedora and RPM Fusion builds, so keep
# them weak: `dnf repoquery --whatprovides 'vlc-plugin*'` to check yours.
Recommends:     vlc-plugins-base
Recommends:     vlc-plugin-ffmpeg

%description
Vela is a modern media player built on libVLC, so it plays practically every
video, audio and stream format, wrapped in a polished, themeable interface:
frosted-glass controls, ambient light, a library home with resume, JSON themes
that hot-reload, a 10-band equalizer, and much more.

%prep
%autosetup -n %{name}-%{version}

%build
%cmake -G Ninja -DCMAKE_BUILD_TYPE=Release
%cmake_build

%install
%cmake_install

%check
desktop-file-validate %{buildroot}%{_datadir}/applications/io.github.velaplayer.Vela.desktop
appstream-util validate-relax --nonet %{buildroot}%{_metainfodir}/io.github.velaplayer.Vela.metainfo.xml

%files
%license LICENSE fonts/OFL-Inter.txt
%doc README.md THEMING.md
%{_bindir}/vela
%{_datadir}/applications/io.github.velaplayer.Vela.desktop
%{_metainfodir}/io.github.velaplayer.Vela.metainfo.xml
%{_datadir}/icons/hicolor/*/apps/io.github.velaplayer.Vela*

%changelog
* Sun Oct 18 2026 The Vela contributors - 0.1.0-1
- First release
