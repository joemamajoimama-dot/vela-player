#!/usr/bin/env bash
# Fill in the sha256 of every archive source in the Flatpak manifest.
set -euo pipefail
manifest="$(dirname "$0")/io.github.velaplayer.Vela.yml"
python3 - "$manifest" <<'PY'
import hashlib, re, sys, urllib.request
path = sys.argv[1]
text = open(path).read()
out, url = [], None
for line in text.splitlines(keepends=True):
    m = re.match(r'\s*url:\s*(\S+)', line)
    if m:
        url = m.group(1)
    if 'sha256:' in line and url:
        print('hashing', url, file=sys.stderr)
        h = hashlib.sha256(urllib.request.urlopen(url).read()).hexdigest()
        line = re.sub(r'sha256:.*', f'sha256: {h}', line)
        url = None
    out.append(line)
open(path, 'w').write(''.join(out))
PY
echo "Updated $manifest"
