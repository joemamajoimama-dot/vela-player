import QtQuick
import QtQuick.Effects
import Vela

// Frosted-glass surface. Give it `backdrop` (any item behind it, usually the
// video) and it blurs exactly the region it covers. Strength, tint and corner
// radius all follow the active theme, so users can dial glass from "crystal"
// to "solid" in Settings.
Item {
    id: root
    property Item backdrop
    property real radius: Theme.opt.radius
    property color tint: Theme.c.glass
    property real tintOpacity: Theme.opt.glassOpacity
    property bool outline: true
    default property alias content: contentLayer.data

    // Re-evaluated whenever we (or our parents) move, so the frosted region
    // stays glued to what is actually behind the panel.
    readonly property rect region: {
        root.x; root.y; root.width; root.height
        if (root.parent) { root.parent.x; root.parent.y; root.parent.opacity }
        if (root.parent && root.parent.parent) { root.parent.parent.x; root.parent.parent.y }
        return blurOn ? root.mapToItem(root.backdrop, 0, 0, root.width, root.height) : Qt.rect(0, 0, 0, 0)
    }
    readonly property bool blurOn: backdrop !== null && Theme.opt.blur > 0 && visible && opacity > 0

    ShaderEffectSource {
        id: grab
        visible: false
        live: true
        recursive: false
        sourceItem: root.blurOn ? root.backdrop : null
        // Track our position over the backdrop.
        sourceRect: root.region
        width: root.width
        height: root.height
        textureSize: Qt.size(Math.max(1, root.width / 2), Math.max(1, root.height / 2))
    }

    Rectangle {
        id: mask
        anchors.fill: parent
        radius: root.radius
        visible: false
        layer.enabled: true
    }

    MultiEffect {
        anchors.fill: parent
        visible: root.blurOn
        source: grab
        blurEnabled: true
        blur: 1.0
        blurMax: Math.max(1, Theme.opt.blur)
        saturation: 0.25
        brightness: Theme.dark ? -0.04 : 0.04
        maskEnabled: true
        maskSource: mask
    }

    Rectangle {
        anchors.fill: parent
        radius: root.radius
        color: Theme.alpha(root.tint, root.blurOn ? root.tintOpacity : Math.max(0.92, root.tintOpacity))
        border.width: root.outline ? 1 : 0
        border.color: Theme.alpha("#FFFFFF", Theme.dark ? 0.09 : 0.5)
    }

    // Hairline highlight on the top edge sells the glass.
    Rectangle {
        visible: root.outline && Theme.dark
        anchors { left: parent.left; right: parent.right; top: parent.top; leftMargin: root.radius; rightMargin: root.radius }
        height: 1
        color: Theme.alpha("#FFFFFF", 0.14)
    }

    Item {
        id: contentLayer
        anchors.fill: parent
    }
}
