import QtQuick
import QtQuick.Controls.impl as Impl
import Vela

// Monochrome SVG icon, tinted to any colour.
Item {
    id: root
    property string name
    property int size: 20
    property color color: Theme.c.text
    implicitWidth: size
    implicitHeight: size
    width: size
    height: size

    Impl.IconImage {
        anchors.fill: parent
        source: root.name ? Theme.icon(root.name) : ""
        sourceSize: Qt.size(root.size, root.size)
        color: root.color
        fillMode: Image.PreserveAspectFit
    }
}
