import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Effects
import Vela

// Round, hover-lit icon button. `filled` gives the big accent play button look.
Item {
    id: root
    property string icon
    property int size: 40
    property int iconSize: Math.round(size * 0.5)
    property color tint: filled ? Theme.c.onAccent : (checked ? Theme.c.accent : Theme.c.text)
    property bool filled: false
    property bool checked: false
    property bool flat: true
    property string tip
    property alias hovered: area.containsMouse
    property alias pressed: area.pressed
    signal clicked()

    implicitWidth: size
    implicitHeight: size
    opacity: enabled ? 1 : 0.35

    Rectangle {
        id: bg
        anchors.fill: parent
        radius: Math.min(width / 2, Theme.opt.radius * 1.25)
        color: root.filled ? (area.containsMouse ? Theme.c.accentHi : Theme.c.accent)
             : root.checked ? Theme.c.accentSoft
             : area.pressed ? Theme.alpha(Theme.c.text, 0.16)
             : area.containsMouse ? Theme.alpha(Theme.c.text, 0.09)
             : root.flat ? "transparent" : Theme.alpha(Theme.c.text, 0.06)
        scale: area.pressed ? 0.92 : 1
        Behavior on color { ColorAnimation { duration: Theme.opt.motion ? 140 * Theme.opt.motionSpeed : 0 } }
        Behavior on scale { NumberAnimation { duration: Theme.opt.motion ? 160 * Theme.opt.motionSpeed : 0; easing.type: Easing.OutBack } }
    }

    // Soft accent glow under the primary button
    Rectangle {
        id: glowShape
        visible: false
        width: root.width; height: root.height; radius: width / 2
        color: Theme.c.accent
    }
    MultiEffect {
        visible: root.filled && Theme.opt.accentGlow
        z: -1
        source: glowShape
        anchors.centerIn: parent
        width: root.width; height: root.height
        anchors.verticalCenterOffset: 4
        blurEnabled: true
        blur: 1
        blurMax: 32
        autoPaddingEnabled: true
        opacity: area.containsMouse ? 0.85 : 0.5
        Behavior on opacity { NumberAnimation { duration: 200 } }
    }

    Icon {
        anchors.centerIn: parent
        name: root.icon
        size: root.iconSize
        color: root.tint
        scale: bg.scale
    }

    MouseArea {
        id: area
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: root.clicked()
    }

    ToolTip {
        visible: root.tip !== "" && area.containsMouse
        delay: 600
        text: root.tip
        contentItem: Text { text: root.tip; color: Theme.c.text; font.pixelSize: 12 }
        background: Rectangle { color: Theme.c.elevated; radius: 8; border.color: Theme.c.border }
    }
}
