import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import Vela

// A frosted popover used for tracks, speed, aspect ratio, etc.
// Use MenuSheet.Option rows inside it.
Popup {
    id: root
    property string title
    property Item backdrop
    default property alias items: column.data
    padding: 10
    width: 300
    modal: false
    focus: true
    closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside

    enter: Transition {
        NumberAnimation { property: "opacity"; from: 0; to: 1; duration: Theme.opt.motion ? 160 : 0 }
        NumberAnimation { property: "scale"; from: 0.94; to: 1; duration: Theme.opt.motion ? 220 : 0; easing.type: Easing.OutCubic }
    }
    exit: Transition {
        NumberAnimation { property: "opacity"; to: 0; duration: Theme.opt.motion ? 120 : 0 }
        NumberAnimation { property: "scale"; to: 0.97; duration: Theme.opt.motion ? 120 : 0 }
    }

    background: Glass {
        backdrop: root.backdrop
        radius: Theme.opt.radius + 4
        tint: Theme.c.elevated
        tintOpacity: Math.min(0.94, Theme.opt.glassOpacity + 0.18)
    }

    contentItem: ColumnLayout {
        spacing: 2
        Text {
            visible: root.title !== ""
            text: root.title
            color: Theme.c.textMuted
            font.pixelSize: 11
            font.weight: Font.Bold
            font.letterSpacing: 1.1
            font.capitalization: Font.AllUppercase
            Layout.leftMargin: 10
            Layout.topMargin: 4
            Layout.bottomMargin: 6
        }
        ColumnLayout {
            id: column
            spacing: 2
            Layout.fillWidth: true
        }
    }

    component Option: Rectangle {
        id: opt
        property string text
        property string detail
        property string icon
        property bool selected: false
        signal triggered()
        Layout.fillWidth: true
        implicitHeight: 40
        radius: Theme.opt.radius * 0.6
        color: optMa.containsMouse ? Theme.alpha(Theme.c.text, 0.08) : "transparent"
        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 10
            anchors.rightMargin: 10
            spacing: 10
            Icon { visible: opt.icon !== ""; name: opt.icon; size: 18; color: Theme.c.textDim }
            Text {
                text: opt.text
                color: opt.selected ? Theme.c.accent : Theme.c.text
                font.pixelSize: 14
                font.weight: opt.selected ? Font.DemiBold : Font.Normal
                elide: Text.ElideRight
                Layout.fillWidth: true
            }
            Text { visible: opt.detail !== ""; text: opt.detail; color: Theme.c.textMuted; font.pixelSize: 12 }
            Icon { visible: opt.selected; name: "check"; size: 18; color: Theme.c.accent }
        }
        MouseArea {
            id: optMa
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: opt.triggered()
        }
    }
}
