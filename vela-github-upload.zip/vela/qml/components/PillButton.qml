import QtQuick
import QtQuick.Layouts
import Vela

// Text button. `primary` = accent filled, otherwise a subtle tonal pill.
Rectangle {
    id: root
    property string text
    property string icon
    property bool primary: false
    property bool compact: false
    property bool selected: false
    signal clicked()

    implicitHeight: (compact ? 32 : 42) * Theme.opt.space
    implicitWidth: row.implicitWidth + (compact ? 24 : 36)
    radius: Math.min(height / 2, Theme.opt.radius)
    color: primary ? (ma.containsMouse ? Theme.c.accentHi : Theme.c.accent)
         : selected ? Theme.c.accentSoft
         : ma.containsMouse ? Theme.alpha(Theme.c.text, 0.12) : Theme.alpha(Theme.c.text, 0.07)
    border.width: selected ? 1 : 0
    border.color: Theme.alpha(Theme.c.accent, 0.6)
    scale: ma.pressed ? 0.96 : 1
    Behavior on color { ColorAnimation { duration: Theme.opt.motion ? 140 : 0 } }
    Behavior on scale { NumberAnimation { duration: Theme.opt.motion ? 140 : 0 } }

    RowLayout {
        id: row
        anchors.centerIn: parent
        spacing: 8
        Icon {
            visible: root.icon !== ""
            name: root.icon
            size: root.compact ? 16 : 18
            color: root.primary ? Theme.c.onAccent : root.selected ? Theme.c.accent : Theme.c.text
        }
        Text {
            text: root.text
            color: root.primary ? Theme.c.onAccent : root.selected ? Theme.c.accent : Theme.c.text
            font.pixelSize: (root.compact ? 13 : 14) * Theme.opt.fontScale
            font.weight: Font.DemiBold
            font.family: Theme.opt.fontFamily
        }
    }
    MouseArea {
        id: ma
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: root.clicked()
    }
}
