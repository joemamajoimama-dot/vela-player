import QtQuick
import QtQuick.Layouts
import Vela

RowLayout {
    id: root
    property string title
    property string subtitle
    property string action
    signal actionClicked()
    spacing: 12
    ColumnLayout {
        spacing: 2
        Layout.fillWidth: true
        Text {
            text: root.title
            color: Theme.c.text
            font.pixelSize: 20 * Theme.opt.fontScale
            font.family: "Inter Display"
            font.weight: Font.Bold
            font.letterSpacing: -0.3
        }
        Text {
            visible: root.subtitle !== ""
            text: root.subtitle
            color: Theme.c.textMuted
            font.pixelSize: 13 * Theme.opt.fontScale
        }
    }
    Text {
        visible: root.action !== ""
        text: root.action
        color: actMa.containsMouse ? Theme.c.accentHi : Theme.c.accent
        font.pixelSize: 13
        font.weight: Font.DemiBold
        MouseArea { id: actMa; anchors.fill: parent; anchors.margins: -6; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: root.actionClicked() }
    }
}
