import QtQuick
import Vela

// Timeline with hover preview, a grow-on-hover track and a draggable knob.
Item {
    id: root
    property real value: 0          // 0..1 playback position
    property real length: 0         // ms, for the hover label
    property bool thick: Theme.opt.seekStyle === "thick"
    readonly property bool active: ma.containsMouse || ma.pressed
    readonly property real shown: ma.pressed ? dragValue : value
    property real dragValue: 0
    signal seekRequested(real pos)
    signal scrubbing(real pos)

    implicitHeight: 22
    implicitWidth: 300

    function fmt(ms) {
        if (!(ms >= 0)) return "0:00"
        const s = Math.floor(ms / 1000), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = s % 60
        return (h > 0 ? h + ":" + String(m).padStart(2, "0") : m) + ":" + String(ss).padStart(2, "0")
    }

    readonly property real trackH: (thick ? 6 : 3) + (active ? (thick ? 4 : 3) : 0)

    Rectangle {
        id: track
        anchors.verticalCenter: parent.verticalCenter
        width: parent.width
        height: root.trackH
        radius: height / 2
        color: Theme.alpha(Theme.c.text, 0.18)
        Behavior on height { NumberAnimation { duration: Theme.opt.motion ? 140 : 0; easing.type: Easing.OutCubic } }

        // Hover ghost
        Rectangle {
            visible: ma.containsMouse && !ma.pressed
            width: Math.max(0, Math.min(1, ma.mouseX / root.width)) * parent.width
            height: parent.height
            radius: parent.radius
            color: Theme.alpha(Theme.c.text, 0.18)
        }

        Rectangle {
            id: fill
            width: Math.max(height, root.shown * parent.width)
            height: parent.height
            radius: parent.radius
            gradient: Gradient {
                orientation: Gradient.Horizontal
                GradientStop { position: 0; color: Theme.mix(Theme.c.accent, Theme.c.accentHi, 0.0) }
                GradientStop { position: 1; color: Theme.c.accentHi }
            }
        }
    }

    Rectangle {
        id: knob
        width: root.active ? 16 : 0
        height: width
        radius: width / 2
        color: "#FFFFFF"
        x: root.shown * root.width - width / 2
        anchors.verticalCenter: parent.verticalCenter
        border.width: 3
        border.color: Theme.c.accent
        Behavior on width { NumberAnimation { duration: Theme.opt.motion ? 160 : 0; easing.type: Easing.OutBack } }
    }

    // Time bubble
    Rectangle {
        visible: root.active && root.length > 0
        readonly property real at: ma.pressed ? root.dragValue : Math.max(0, Math.min(1, ma.mouseX / root.width))
        width: label.implicitWidth + 16
        height: 26
        radius: 8
        color: Theme.c.elevated
        border.color: Theme.c.border
        x: Math.max(-8, Math.min(root.width - width + 8, at * root.width - width / 2))
        y: -height - 10
        Text {
            id: label
            anchors.centerIn: parent
            text: root.fmt(parent.at * root.length)
            color: Theme.c.text
            font.pixelSize: 12
            font.weight: Font.DemiBold
            font.features: ({ "tnum": 1 })
        }
    }

    MouseArea {
        id: ma
        anchors.fill: parent
        anchors.topMargin: -8
        anchors.bottomMargin: -8
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        preventStealing: true
        onPressed: mouse => { root.dragValue = Math.max(0, Math.min(1, mouse.x / root.width)); root.scrubbing(root.dragValue) }
        onPositionChanged: mouse => { if (pressed) { root.dragValue = Math.max(0, Math.min(1, mouse.x / root.width)); root.scrubbing(root.dragValue) } }
        onReleased: root.seekRequested(root.dragValue)
    }
}
