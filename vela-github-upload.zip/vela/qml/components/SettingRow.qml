import QtQuick
import QtQuick.Layouts
import Vela

// Label + description on the left, any control on the right.
Rectangle {
    id: root
    property string title
    property string description
    property string icon
    default property alias control: slot.data
    Layout.fillWidth: true
    implicitHeight: Math.max(64 * Theme.opt.space, row.implicitHeight + 24)
    color: "transparent"

    RowLayout {
        id: row
        anchors.fill: parent
        anchors.leftMargin: 18
        anchors.rightMargin: 18
        spacing: 16
        Rectangle {
            visible: root.icon !== ""
            implicitWidth: 34; implicitHeight: 34
            radius: Theme.opt.radius * 0.6
            color: Theme.alpha(Theme.c.accent, 0.14)
            Icon { anchors.centerIn: parent; name: root.icon; size: 18; color: Theme.c.accent }
        }
        ColumnLayout {
            spacing: 3
            Layout.fillWidth: true
            Text { text: root.title; color: Theme.c.text; font.pixelSize: 14 * Theme.opt.fontScale; font.weight: Font.DemiBold; Layout.fillWidth: true; elide: Text.ElideRight }
            Text {
                visible: root.description !== ""
                text: root.description
                color: Theme.c.textMuted
                font.pixelSize: 12.5 * Theme.opt.fontScale
                wrapMode: Text.WordWrap
                Layout.fillWidth: true
            }
        }
        Item {
            id: slot
            implicitWidth: childrenRect.width
            implicitHeight: childrenRect.height
            Layout.alignment: Qt.AlignVCenter | Qt.AlignRight
        }
    }
    Rectangle {
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: 18; rightMargin: 18 }
        height: 1
        color: Theme.c.border
    }
}
