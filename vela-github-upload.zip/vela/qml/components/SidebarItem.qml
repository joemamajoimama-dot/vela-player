import QtQuick
import QtQuick.Layouts
import Vela

Rectangle {
    id: root
    property string icon
    property string text
    property bool active: false
    property bool compact: false
    property string badge
    signal clicked()

    implicitHeight: 42 * Theme.opt.space
    Layout.fillWidth: true
    radius: Theme.opt.radius * 0.75
    color: active ? Theme.c.accentSoft : ma.containsMouse ? Theme.alpha(Theme.c.text, 0.06) : "transparent"
    Behavior on color { ColorAnimation { duration: Theme.opt.motion ? 150 : 0 } }

    Rectangle {
        width: 3
        height: root.active ? 18 : 0
        radius: 2
        anchors.verticalCenter: parent.verticalCenter
        anchors.left: parent.left
        anchors.leftMargin: -1
        color: Theme.c.accent
        Behavior on height { NumberAnimation { duration: Theme.opt.motion ? 220 : 0; easing.type: Easing.OutBack } }
    }

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: root.compact ? 0 : 14
        anchors.rightMargin: root.compact ? 0 : 12
        spacing: 12
        Item { visible: root.compact; Layout.fillWidth: true }
        Icon {
            name: root.icon
            size: 20
            color: root.active ? Theme.c.accent : Theme.c.textDim
        }
        Text {
            visible: !root.compact
            text: root.text
            color: root.active ? Theme.c.text : Theme.c.textDim
            font.pixelSize: 14 * Theme.opt.fontScale
            font.weight: root.active ? Font.DemiBold : Font.Medium
            Layout.fillWidth: true
        }
        Rectangle {
            visible: !root.compact && root.badge !== ""
            implicitWidth: Math.max(20, badgeText.implicitWidth + 10)
            implicitHeight: 20
            radius: 10
            color: Theme.alpha(Theme.c.text, 0.08)
            Text { id: badgeText; anchors.centerIn: parent; text: root.badge; color: Theme.c.textDim; font.pixelSize: 11; font.weight: Font.DemiBold }
        }
        Item { visible: root.compact; Layout.fillWidth: true }
    }
    MouseArea {
        id: ma
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: root.clicked()
    }
}
