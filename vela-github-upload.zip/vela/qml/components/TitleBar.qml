import QtQuick
import QtQuick.Layouts
import Vela

// Client-side title bar: drag to move, double-click to maximise.
Item {
    id: root
    property var window
    property bool dark: true
    default property alias content: slot.data
    implicitHeight: 48

    DragHandler {
        target: null
        grabPermissions: PointerHandler.CanTakeOverFromAnything
        onActiveChanged: if (active && root.window) root.window.startSystemMove()
    }
    TapHandler {
        onDoubleTapped: root.window.visibility === 4 /* Maximized */ ? root.window.showNormal() : root.window.showMaximized()
    }

    RowLayout {
        anchors.fill: parent
        anchors.rightMargin: 10
        spacing: 6
        Item { id: slot; Layout.fillWidth: true; Layout.fillHeight: true }
        Repeater {
            model: [
                { icon: "minimize", act: "min" },
                { icon: root.window && root.window.visibility === 4 ? "restore" : "maximize", act: "max" },
                { icon: "close", act: "close" }
            ]
            delegate: Rectangle {
                id: btn
                required property var modelData
                implicitWidth: 30; implicitHeight: 30
                radius: 15
                color: ma.containsMouse ? (btn.modelData.act === "close" ? Theme.c.danger : Theme.alpha(Theme.c.text, 0.12)) : Theme.alpha(Theme.c.text, 0.06)
                Behavior on color { ColorAnimation { duration: 120 } }
                Icon {
                    anchors.centerIn: parent
                    name: btn.modelData.icon
                    size: 15
                    color: ma.containsMouse && btn.modelData.act === "close" ? "#FFFFFF" : Theme.c.textDim
                }
                MouseArea {
                    id: ma
                    anchors.fill: parent
                    hoverEnabled: true
                    onClicked: {
                        if (btn.modelData.act === "min") root.window.showMinimized()
                        else if (btn.modelData.act === "max") root.window.visibility === 4 ? root.window.showNormal() : root.window.showMaximized()
                        else root.window.close()
                    }
                }
            }
        }
    }
}
