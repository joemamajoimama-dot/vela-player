import QtQuick
import QtQuick.Layouts
import Vela

// Small transient pill: Toast.show("volume", "Volume 80%")
Item {
    id: root
    property Item backdrop
    width: pill.width
    height: pill.height
    opacity: 0
    visible: opacity > 0

    function show(icon, text) {
        ic.name = icon
        label.text = text
        hide.restart()
        if (Theme.opt.motion) { fadeIn.restart() } else { root.opacity = 1; pill.y = 0 }
    }

    NumberAnimation { id: fadeIn; target: root; property: "opacity"; to: 1; duration: 140 }
    NumberAnimation { id: fadeOut; target: root; property: "opacity"; to: 0; duration: 260 }
    Timer { id: hide; interval: 1400; onTriggered: Theme.opt.motion ? fadeOut.restart() : root.opacity = 0 }

    Glass {
        id: pill
        backdrop: root.backdrop
        width: row.implicitWidth + 28
        height: 44
        radius: 22
        RowLayout {
            id: row
            anchors.centerIn: parent
            spacing: 10
            Icon { id: ic; size: 18; color: Theme.c.accent }
            Text { id: label; color: Theme.c.text; font.pixelSize: 14; font.weight: Font.DemiBold }
        }
    }
}
