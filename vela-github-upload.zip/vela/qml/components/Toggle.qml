import QtQuick
import Vela

// iOS/libadwaita-style switch.
Item {
    id: root
    property bool checked: false
    signal toggled(bool on)
    implicitWidth: 46
    implicitHeight: 28

    Rectangle {
        anchors.fill: parent
        radius: height / 2
        color: root.checked ? Theme.c.accent : Theme.alpha(Theme.c.text, 0.18)
        Behavior on color { ColorAnimation { duration: Theme.opt.motion ? 160 : 0 } }
        Rectangle {
            width: parent.height - 6
            height: width
            radius: width / 2
            y: 3
            x: root.checked ? parent.width - width - 3 : 3
            color: root.checked ? Theme.c.onAccent : "#FFFFFF"
            Behavior on x { NumberAnimation { duration: Theme.opt.motion ? 200 : 0; easing.type: Easing.OutBack; easing.overshoot: 1.4 } }
        }
    }
    MouseArea {
        anchors.fill: parent
        cursorShape: Qt.PointingHandCursor
        onClicked: root.toggled(!root.checked)
    }
}
