import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import Vela

// 10-band graphic equaliser backed by libVLC's equalizer.
MenuSheet {
    id: root
    property VlcPlayer player
    title: qsTr("Equalizer")
    width: 520

    property var bands: []
    property real preamp: 0

    function applyPreset(i) {
        const v = player.equalizerPresetValues(i)
        preamp = v[0]
        bands = v.slice(1)
        player.setEqualizer(preamp, bands)
        player.equalizerEnabled = true
    }
    function push() { player.setEqualizer(preamp, bands) }

    RowLayout {
        Layout.fillWidth: true
        Layout.leftMargin: 10
        Layout.rightMargin: 10
        Text { text: qsTr("Enabled"); color: Theme.c.text; font.pixelSize: 14; font.weight: Font.DemiBold; Layout.fillWidth: true }
        Toggle { checked: root.player.equalizerEnabled; onToggled: on => root.player.equalizerEnabled = on }
    }

    Flow {
        Layout.fillWidth: true
        Layout.margins: 8
        spacing: 6
        Repeater {
            model: root.player ? root.player.equalizerPresets : []
            delegate: PillButton {
                required property string modelData
                required property int index
                text: modelData
                compact: true
                onClicked: root.applyPreset(index)
            }
        }
    }

    RowLayout {
        Layout.fillWidth: true
        Layout.preferredHeight: 190
        Layout.margins: 8
        spacing: 0
        enabled: root.player.equalizerEnabled
        opacity: enabled ? 1 : 0.45

        Repeater {
            model: root.player ? root.player.equalizerBands.length + 1 : 0
            delegate: ColumnLayout {
                id: col
                required property int index
                readonly property bool isPre: index === 0
                Layout.fillWidth: true
                Layout.fillHeight: true
                spacing: 6
                Text {
                    text: Math.round(col.isPre ? root.preamp : (root.bands[col.index - 1] || 0)) + ""
                    color: Theme.c.textMuted
                    font.pixelSize: 10
                    Layout.alignment: Qt.AlignHCenter
                }
                Slider {
                    id: s
                    orientation: Qt.Vertical
                    from: -20; to: 20
                    value: col.isPre ? root.preamp : (root.bands[col.index - 1] || 0)
                    Layout.fillHeight: true
                    Layout.alignment: Qt.AlignHCenter
                    onMoved: {
                        if (col.isPre) root.preamp = value
                        else { const b = root.bands.slice(); b[col.index - 1] = value; root.bands = b }
                        root.push()
                    }
                    background: Rectangle {
                        x: s.leftPadding + s.availableWidth / 2 - width / 2
                        y: s.topPadding
                        width: 4; height: s.availableHeight; radius: 2
                        color: Theme.alpha(Theme.c.text, 0.14)
                        Rectangle {
                            // fill from the 0 dB centre line
                            readonly property real mid: parent.height / 2
                            readonly property real pos: s.visualPosition * parent.height
                            y: Math.min(mid, pos); height: Math.abs(mid - pos)
                            width: parent.width; radius: 2
                            color: col.isPre ? Theme.c.textDim : Theme.c.accent
                        }
                    }
                    handle: Rectangle {
                        x: s.leftPadding + s.availableWidth / 2 - width / 2
                        y: s.topPadding + s.visualPosition * (s.availableHeight - height)
                        width: 16; height: 16; radius: 8
                        color: "#FFFFFF"
                        border.width: 3
                        border.color: col.isPre ? Theme.c.textDim : Theme.c.accent
                    }
                }
                Text {
                    text: {
                        if (col.isPre) return qsTr("Pre")
                        const f = root.player.equalizerBands[col.index - 1]
                        return f >= 1000 ? (f / 1000) + "k" : Math.round(f) + ""
                    }
                    color: col.isPre ? Theme.c.textDim : Theme.c.textMuted
                    font.pixelSize: Math.round(10.5)
                    font.weight: Font.DemiBold
                    Layout.alignment: Qt.AlignHCenter
                }
            }
        }
    }

    onAboutToShow: {
        preamp = player.equalizerPreamp
        const saved = player.equalizerValues
        bands = player.equalizerBands.map((_, i) => i < saved.length ? Number(saved[i]) : 0)
    }
}
