import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import Vela

Item {
    id: root
    property var app
    property PlaylistModel queue
    property VlcPlayer player
    readonly property real pad: 40 * Theme.opt.space

    ColumnLayout {
        anchors.fill: parent
        anchors.leftMargin: root.pad
        anchors.rightMargin: root.pad
        anchors.topMargin: 64
        spacing: 22 * Theme.opt.space

        RowLayout {
            Layout.fillWidth: true
            spacing: 10
            ColumnLayout {
                spacing: 4
                Text { text: qsTr("Queue"); color: Theme.c.text; font.family: "Inter Display"; font.pixelSize: 34 * Theme.opt.fontScale; font.weight: Font.Bold; font.letterSpacing: -0.8 }
                Text { text: root.queue.count ? qsTr("%n item(s) · drag to reorder", "", root.queue.count) : qsTr("Nothing queued"); color: Theme.c.textMuted; font.pixelSize: 13 }
            }
            Item { Layout.fillWidth: true }
            PillButton { text: qsTr("Shuffle"); icon: "shuffle"; compact: true; selected: root.queue.shuffle; onClicked: root.queue.shuffle = !root.queue.shuffle }
            PillButton {
                text: root.queue.repeat === "one" ? qsTr("Repeat one") : root.queue.repeat === "all" ? qsTr("Repeat all") : qsTr("Repeat off")
                icon: root.queue.repeat === "one" ? "repeat-one" : "repeat"
                compact: true
                selected: root.queue.repeat !== "off"
                onClicked: root.queue.cycleRepeat()
            }
            PillButton { text: qsTr("Add files"); icon: "plus"; compact: true; onClicked: root.app.openFileDialog() }
            PillButton { visible: root.queue.count > 0; text: qsTr("Clear"); icon: "trash"; compact: true; onClicked: root.queue.clear() }
        }

        ListView {
            id: list
            Layout.fillWidth: true
            Layout.fillHeight: true
            visible: root.queue.count > 0
            clip: true
            spacing: 4
            model: root.queue
            boundsBehavior: Flickable.StopAtBounds
            ScrollBar.vertical: ScrollBar {}
            move: Transition { NumberAnimation { properties: "y"; duration: Theme.opt.motion ? 200 : 0; easing.type: Easing.OutCubic } }
            displaced: Transition { NumberAnimation { properties: "y"; duration: Theme.opt.motion ? 200 : 0; easing.type: Easing.OutCubic } }

            delegate: Item {
                id: slot
                required property int index
                required property string title
                required property bool isCurrent
                required property string kind
                width: list.width
                height: 62 * Theme.opt.space

                Rectangle {
                    id: card
                    width: slot.width
                    height: slot.height
                    radius: Theme.opt.radius * 0.8
                    color: slot.isCurrent ? Theme.c.accentSoft : rowMa.containsMouse || grip.active ? Theme.c.surfaceHi : Theme.c.surface
                    border.color: slot.isCurrent ? Theme.alpha(Theme.c.accent, 0.5) : Theme.c.border
                    z: grip.active ? 10 : 0
                    scale: grip.active ? 1.02 : 1
                    Behavior on scale { NumberAnimation { duration: 120 } }

                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 8
                        anchors.rightMargin: 12
                        spacing: 12
                        Item {
                            Layout.preferredWidth: 28; Layout.fillHeight: true
                            Icon { anchors.centerIn: parent; name: "grip"; size: 18; color: Theme.c.textMuted }
                            DragHandler {
                                id: grip
                                target: card
                                xAxis.enabled: false
                                onActiveChanged: {
                                    if (!active) {
                                        const to = Math.max(0, Math.min(root.queue.count - 1, Math.round((slot.y + card.y) / slot.height)))
                                        card.y = 0
                                        root.queue.move(slot.index, to)
                                    }
                                }
                            }
                            HoverHandler { cursorShape: Qt.OpenHandCursor }
                        }
                        Rectangle {
                            Layout.preferredWidth: 42; Layout.preferredHeight: 42
                            radius: Theme.opt.radius * 0.55
                            color: slot.isCurrent ? Theme.c.accent : Theme.alpha(Theme.c.text, 0.08)
                            Icon {
                                anchors.centerIn: parent
                                name: slot.isCurrent ? (root.player.playing ? "pause" : "play") : (slot.kind === "audio" ? "music" : "film")
                                size: 18
                                color: slot.isCurrent ? Theme.c.onAccent : Theme.c.textDim
                            }
                        }
                        ColumnLayout {
                            spacing: 2
                            Layout.fillWidth: true
                            Text { text: slot.title; color: slot.isCurrent ? Theme.c.accent : Theme.c.text; font.pixelSize: Math.round(14.5); font.weight: Font.DemiBold; elide: Text.ElideRight; Layout.fillWidth: true }
                            Text { text: slot.isCurrent ? qsTr("Now playing") : qsTr("#%1").arg(slot.index + 1); color: Theme.c.textMuted; font.pixelSize: 12 }
                        }
                        IconButton { icon: "close"; size: 32; iconSize: 15; opacity: rowMa.containsMouse ? 1 : 0; tip: qsTr("Remove"); onClicked: root.queue.remove(slot.index) }
                    }
                    MouseArea {
                        id: rowMa
                        anchors.fill: parent
                        anchors.leftMargin: 40
                        anchors.rightMargin: 50
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: slot.isCurrent ? root.player.togglePause() : root.queue.currentIndex = slot.index
                        onDoubleClicked: root.app.playerOpen = true
                    }
                }
            }
        }

        ColumnLayout {
            visible: root.queue.count === 0
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 10
            Item { Layout.fillHeight: true }
            Icon { name: "queue"; size: 54; color: Theme.c.textMuted; Layout.alignment: Qt.AlignHCenter }
            Text { text: qsTr("Your queue is empty"); color: Theme.c.text; font.pixelSize: 18; font.weight: Font.DemiBold; Layout.alignment: Qt.AlignHCenter }
            Text { text: qsTr("Drop files here to line them up, or right-click anything in your library."); color: Theme.c.textMuted; font.pixelSize: 13; Layout.alignment: Qt.AlignHCenter }
            Item { Layout.fillHeight: true }
        }
    }
}
