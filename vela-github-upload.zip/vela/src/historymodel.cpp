// SPDX-License-Identifier: GPL-3.0-or-later
#include "historymodel.h"

#include <QSettings>

static constexpr int kMaxEntries = 60;

HistoryModel::HistoryModel(QObject *parent)
    : QAbstractListModel(parent)
{
    QSettings s;
    m_enabled = s.value("privacy/history", true).toBool();
    const int n = s.beginReadArray("history");
    for (int i = 0; i < n; ++i) {
        s.setArrayIndex(i);
        Entry e;
        e.url = s.value("url").toUrl();
        e.title = s.value("title").toString();
        e.kind = s.value("kind", "video").toString();
        e.thumbnail = s.value("thumbnail").toString();
        e.position = s.value("position").toLongLong();
        e.length = s.value("length").toLongLong();
        e.played = s.value("played").toDateTime();
        if (e.url.isValid())
            m_entries << e;
    }
    s.endArray();
}

void HistoryModel::save() const
{
    QSettings s;
    s.remove("history");
    s.beginWriteArray("history", int(m_entries.size()));
    for (int i = 0; i < m_entries.size(); ++i) {
        const Entry &e = m_entries.at(i);
        s.setArrayIndex(i);
        s.setValue("url", e.url);
        s.setValue("title", e.title);
        s.setValue("kind", e.kind);
        s.setValue("thumbnail", e.thumbnail);
        s.setValue("position", e.position);
        s.setValue("length", e.length);
        s.setValue("played", e.played);
    }
    s.endArray();
    s.setValue("privacy/history", m_enabled);
}

int HistoryModel::rowCount(const QModelIndex &parent) const
{
    return parent.isValid() ? 0 : int(m_entries.size());
}

QVariant HistoryModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() >= m_entries.size())
        return {};
    const Entry &e = m_entries.at(index.row());
    switch (role) {
    case UrlRole: return e.url;
    case Qt::DisplayRole:
    case TitleRole: return e.title;
    case PositionRole: return e.position;
    case LengthRole: return e.length;
    case ProgressRole: return e.length > 0 ? double(e.position) / double(e.length) : 0.0;
    case PlayedRole: return e.played;
    case KindRole: return e.kind;
    case ThumbnailRole: return e.thumbnail;
    }
    return {};
}

QHash<int, QByteArray> HistoryModel::roleNames() const
{
    return {{UrlRole, "url"}, {TitleRole, "title"}, {PositionRole, "position"}, {LengthRole, "length"},
            {ProgressRole, "progress"}, {PlayedRole, "played"}, {KindRole, "kind"}, {ThumbnailRole, "thumbnail"}};
}

void HistoryModel::record(const QUrl &url, const QString &title, qint64 positionMs, qint64 lengthMs,
                          bool hasVideo, const QString &thumbnail)
{
    if (!m_enabled || !url.isValid())
        return;

    Entry e;
    for (int i = 0; i < m_entries.size(); ++i) {
        if (m_entries.at(i).url == url) {
            e = m_entries.at(i);
            beginRemoveRows({}, i, i);
            m_entries.removeAt(i);
            endRemoveRows();
            break;
        }
    }
    e.url = url;
    if (!title.isEmpty())
        e.title = title;
    e.kind = hasVideo ? "video" : "audio";
    if (!thumbnail.isEmpty())
        e.thumbnail = thumbnail;
    e.position = positionMs;
    if (lengthMs > 0)
        e.length = lengthMs;
    e.played = QDateTime::currentDateTime();

    beginInsertRows({}, 0, 0);
    m_entries.prepend(e);
    endInsertRows();

    if (m_entries.size() > kMaxEntries) {
        beginRemoveRows({}, kMaxEntries, int(m_entries.size()) - 1);
        m_entries.resize(kMaxEntries);
        endRemoveRows();
    }
    save();
    emit countChanged();
}

void HistoryModel::setEnabled(bool on)
{
    if (on == m_enabled)
        return;
    m_enabled = on;
    QSettings().setValue("privacy/history", on);
    emit countChanged();
}

qint64 HistoryModel::resumePosition(const QUrl &url) const
{
    for (const Entry &e : m_entries) {
        if (e.url != url)
            continue;
        // Don't resume trivially short progress or something you basically finished.
        if (e.position < 10000 || (e.length > 0 && e.position > e.length - 15000))
            return 0;
        return e.position;
    }
    return 0;
}

void HistoryModel::remove(int row)
{
    if (row < 0 || row >= m_entries.size())
        return;
    beginRemoveRows({}, row, row);
    m_entries.removeAt(row);
    endRemoveRows();
    save();
    emit countChanged();
}

void HistoryModel::clear()
{
    beginResetModel();
    m_entries.clear();
    endResetModel();
    save();
    emit countChanged();
}

QVariantMap HistoryModel::get(int row) const
{
    QVariantMap m;
    const auto roles = roleNames();
    for (auto it = roles.cbegin(); it != roles.cend(); ++it)
        m[QString::fromUtf8(it.value())] = data(index(row), it.key());
    return m;
}
