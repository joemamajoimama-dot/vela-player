// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include <QAbstractListModel>
#include <QDateTime>
#include <QUrl>
#include <QtQml/qqmlregistration.h>

// "Continue watching": recently played media with resume positions.
class HistoryModel : public QAbstractListModel
{
    Q_OBJECT
    QML_ELEMENT

    Q_PROPERTY(int count READ rowCount NOTIFY countChanged)
    Q_PROPERTY(bool enabled READ isEnabled WRITE setEnabled NOTIFY countChanged)

public:
    enum Roles { UrlRole = Qt::UserRole + 1, TitleRole, PositionRole, LengthRole, ProgressRole,
                 PlayedRole, KindRole, ThumbnailRole };

    struct Entry {
        QUrl url;
        QString title, kind, thumbnail;
        qint64 position = 0, length = 0;
        QDateTime played;
    };

    explicit HistoryModel(QObject *parent = nullptr);

    int rowCount(const QModelIndex &parent = {}) const override;
    QVariant data(const QModelIndex &index, int role) const override;
    QHash<int, QByteArray> roleNames() const override;

    bool isEnabled() const { return m_enabled; }
    void setEnabled(bool on);

    Q_INVOKABLE void record(const QUrl &url, const QString &title, qint64 positionMs, qint64 lengthMs,
                            bool hasVideo, const QString &thumbnail = {});
    Q_INVOKABLE qint64 resumePosition(const QUrl &url) const;
    Q_INVOKABLE void remove(int row);
    Q_INVOKABLE void clear();
    Q_INVOKABLE QVariantMap get(int row) const;

signals:
    void countChanged();

private:
    void save() const;
    QList<Entry> m_entries;
    bool m_enabled = true;
};
