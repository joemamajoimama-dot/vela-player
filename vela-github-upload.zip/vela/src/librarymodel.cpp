// SPDX-License-Identifier: GPL-3.0-or-later
#include "librarymodel.h"

#include <QCoreApplication>
#include <QCryptographicHash>
#include <QDir>
#include <QDirIterator>
#include <QFileInfo>
#include <QPointer>
#include <QSet>
#include <QSettings>
#include <QStandardPaths>
#include <QThreadPool>

#include <algorithm>

namespace {

const QSet<QString> &videoExts()
{
    static const QSet<QString> s = {"mkv", "mp4", "m4v", "webm", "avi", "mov", "wmv", "flv", "mpg",
                                    "mpeg", "ts", "m2ts", "mts", "ogv", "3gp", "vob", "divx", "rmvb", "asf"};
    return s;
}

const QSet<QString> &audioExts()
{
    static const QSet<QString> s = {"mp3", "flac", "ogg", "opus", "m4a", "aac", "wav", "wma", "alac",
                                    "ape", "aiff", "aif", "mka", "wv", "mpc", "dsf"};
    return s;
}

QString prettyTitle(const QString &baseName)
{
    QString t = baseName;
    t.replace('_', ' ');
    t.replace('.', ' ');
    return t.simplified();
}

} // namespace

namespace {
// All LibraryModel instances share one folder list; this relays changes.
class FolderBus : public QObject
{
    Q_OBJECT
signals:
    void changed(const QStringList &folders);
};
FolderBus *folderBus()
{
    static FolderBus bus;
    return &bus;
}
} // namespace

LibraryModel::LibraryModel(QObject *parent)
    : QAbstractListModel(parent)
{
    QSettings s;
    m_folders = s.contains("library/folders") ? s.value("library/folders").toStringList() : defaultFolders();
    connect(folderBus(), &FolderBus::changed, this, [this](const QStringList &f) {
        if (f == m_folders)
            return;
        m_folders = f;
        emit foldersChanged();
        rescan();
    });
    QMetaObject::invokeMethod(this, &LibraryModel::rescan, Qt::QueuedConnection);
}

QStringList LibraryModel::defaultFolders()
{
    QStringList out;
    for (auto loc : {QStandardPaths::MoviesLocation, QStandardPaths::MusicLocation, QStandardPaths::DownloadLocation}) {
        const QString p = QStandardPaths::writableLocation(loc);
        if (!p.isEmpty() && QDir(p).exists() && !out.contains(p))
            out << p;
    }
    return out;
}

bool LibraryModel::isMediaUrl(const QUrl &url)
{
    const QString ext = QFileInfo(url.path()).suffix().toLower();
    return videoExts().contains(ext) || audioExts().contains(ext) || !url.isLocalFile();
}

QString LibraryModel::thumbnailFor(const QString &path)
{
    // https://specifications.freedesktop.org/thumbnail-spec/
    const QByteArray uri = QUrl::fromLocalFile(path).toEncoded();
    const QString md5 = QCryptographicHash::hash(uri, QCryptographicHash::Md5).toHex();
    const QString cache = QStandardPaths::writableLocation(QStandardPaths::GenericCacheLocation) + "/thumbnails/";
    for (const char *size : {"x-large", "large", "normal"}) {
        const QString f = cache + size + "/" + md5 + ".png";
        if (QFileInfo::exists(f))
            return QUrl::fromLocalFile(f).toString();
    }
    return {};
}

void LibraryModel::rescan()
{
    const int gen = ++m_generation;
    m_scanning = true;
    emit scanningChanged();

    const QStringList folders = m_folders;
    QPointer<LibraryModel> self(this);
    QThreadPool::globalInstance()->start([self, gen, folders] {
        QList<Item> found;
        QSet<QString> seen;
        for (const QString &root : folders) {
            QDirIterator it(root, QDir::Files | QDir::Readable | QDir::NoDotAndDotDot,
                            QDirIterator::Subdirectories | QDirIterator::FollowSymlinks);
            while (it.hasNext() && found.size() < 20000) {
                const QFileInfo fi(it.nextFileInfo());
                if (fi.fileName().startsWith('.') || fi.absoluteFilePath().contains("/."))
                    continue;
                const QString ext = fi.suffix().toLower();
                const bool video = videoExts().contains(ext);
                if (!video && !audioExts().contains(ext))
                    continue;
                const QString canon = fi.canonicalFilePath();
                if (seen.contains(canon))
                    continue;
                seen.insert(canon);
                Item item;
                item.title = prettyTitle(fi.completeBaseName());
                item.path = fi.absoluteFilePath();
                item.folder = fi.dir().dirName();
                item.ext = ext.toUpper();
                item.video = video;
                item.size = fi.size();
                item.modified = fi.lastModified();
                item.thumb = thumbnailFor(item.path);
                found.append(item);
            }
        }
        QMetaObject::invokeMethod(qApp, [self, gen, found = std::move(found)]() mutable {
            if (!self || gen != self->m_generation)
                return;
            self->m_all = std::move(found);
            self->m_scanning = false;
            emit self->scanningChanged();
            self->applyFilter();
        }, Qt::QueuedConnection);
    });
}

void LibraryModel::applyFilter()
{
    beginResetModel();
    m_view.clear();
    const QString needle = m_search.trimmed();
    for (const Item &i : std::as_const(m_all)) {
        if (m_kind == "video" && !i.video)
            continue;
        if (m_kind == "audio" && i.video)
            continue;
        if (!needle.isEmpty() && !i.title.contains(needle, Qt::CaseInsensitive)
            && !i.folder.contains(needle, Qt::CaseInsensitive))
            continue;
        m_view.append(i);
    }
    if (m_sortBy == "name")
        std::sort(m_view.begin(), m_view.end(), [](const Item &a, const Item &b) {
            return QString::localeAwareCompare(a.title, b.title) < 0;
        });
    else if (m_sortBy == "size")
        std::sort(m_view.begin(), m_view.end(), [](const Item &a, const Item &b) { return a.size > b.size; });
    else
        std::sort(m_view.begin(), m_view.end(), [](const Item &a, const Item &b) { return a.modified > b.modified; });
    endResetModel();
    emit countChanged();
}

int LibraryModel::rowCount(const QModelIndex &parent) const
{
    return parent.isValid() ? 0 : int(m_view.size());
}

QVariant LibraryModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() >= m_view.size())
        return {};
    const Item &i = m_view.at(index.row());
    switch (role) {
    case Qt::DisplayRole:
    case TitleRole: return i.title;
    case UrlRole: return QUrl::fromLocalFile(i.path);
    case KindRole: return i.video ? QStringLiteral("video") : QStringLiteral("audio");
    case SizeRole: return i.size;
    case ModifiedRole: return i.modified;
    case FolderRole: return i.folder;
    case ThumbnailRole: return i.thumb;
    case ExtensionRole: return i.ext;
    }
    return {};
}

QHash<int, QByteArray> LibraryModel::roleNames() const
{
    return {{TitleRole, "title"}, {UrlRole, "url"}, {KindRole, "kind"}, {SizeRole, "size"},
            {ModifiedRole, "modified"}, {FolderRole, "folder"}, {ThumbnailRole, "thumbnail"},
            {ExtensionRole, "extension"}};
}

QVariantMap LibraryModel::get(int row) const
{
    QVariantMap m;
    const auto roles = roleNames();
    for (auto it = roles.cbegin(); it != roles.cend(); ++it)
        m[QString::fromUtf8(it.value())] = data(index(row), it.key());
    return m;
}

QVariantList LibraryModel::urls() const
{
    QVariantList out;
    for (const Item &i : m_view)
        out << QUrl::fromLocalFile(i.path);
    return out;
}

void LibraryModel::setKind(const QString &k)
{
    if (k == m_kind) return;
    m_kind = k;
    emit kindChanged();
    applyFilter();
}

void LibraryModel::setFolders(const QStringList &f)
{
    if (f == m_folders) return;
    m_folders = f;
    QSettings().setValue("library/folders", f);
    emit foldersChanged();
    rescan();
    emit folderBus()->changed(f);
}

void LibraryModel::setSearch(const QString &s)
{
    if (s == m_search) return;
    m_search = s;
    emit searchChanged();
    applyFilter();
}

void LibraryModel::setSortBy(const QString &s)
{
    if (s == m_sortBy) return;
    m_sortBy = s;
    emit sortByChanged();
    applyFilter();
}

#include "librarymodel.moc"
