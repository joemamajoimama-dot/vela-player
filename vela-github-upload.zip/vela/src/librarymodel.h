// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include <QAbstractListModel>
#include <QDateTime>
#include <QStringList>
#include <QUrl>
#include <QtQml/qqmlregistration.h>

// Scans the user's media folders (XDG Videos / Music by default) and exposes
// a searchable, sortable list. Thumbnails come from the shared freedesktop
// thumbnail cache that file managers already populate.
class LibraryModel : public QAbstractListModel
{
    Q_OBJECT
    QML_ELEMENT

    Q_PROPERTY(QString kind READ kind WRITE setKind NOTIFY kindChanged)          // "video" | "audio" | "all"
    Q_PROPERTY(QStringList folders READ folders WRITE setFolders NOTIFY foldersChanged)
    Q_PROPERTY(QString search READ search WRITE setSearch NOTIFY searchChanged)
    Q_PROPERTY(QString sortBy READ sortBy WRITE setSortBy NOTIFY sortByChanged)  // "recent" | "name" | "size"
    Q_PROPERTY(bool scanning READ scanning NOTIFY scanningChanged)
    Q_PROPERTY(int count READ rowCount NOTIFY countChanged)
    Q_PROPERTY(int totalCount READ totalCount NOTIFY countChanged)

public:
    enum Roles { TitleRole = Qt::UserRole + 1, UrlRole, KindRole, SizeRole, ModifiedRole,
                 FolderRole, ThumbnailRole, ExtensionRole };

    struct Item {
        QString title, path, folder, ext;
        bool video = true;
        qint64 size = 0;
        QDateTime modified;
        QString thumb;
    };

    explicit LibraryModel(QObject *parent = nullptr);

    int rowCount(const QModelIndex &parent = {}) const override;
    QVariant data(const QModelIndex &index, int role) const override;
    QHash<int, QByteArray> roleNames() const override;

    QString kind() const { return m_kind; }
    void setKind(const QString &k);
    QStringList folders() const { return m_folders; }
    void setFolders(const QStringList &f);
    QString search() const { return m_search; }
    void setSearch(const QString &s);
    QString sortBy() const { return m_sortBy; }
    void setSortBy(const QString &s);
    bool scanning() const { return m_scanning; }
    int totalCount() const { return int(m_all.size()); }

    Q_INVOKABLE void rescan();
    Q_INVOKABLE QVariantMap get(int row) const;
    Q_INVOKABLE QVariantList urls() const;
    Q_INVOKABLE static bool isMediaUrl(const QUrl &url);
    Q_INVOKABLE static QStringList defaultFolders();

signals:
    void kindChanged();
    void foldersChanged();
    void searchChanged();
    void sortByChanged();
    void scanningChanged();
    void countChanged();

private:
    void applyFilter();
    static QString thumbnailFor(const QString &path);

    QString m_kind = QStringLiteral("video");
    QStringList m_folders;
    QString m_search;
    QString m_sortBy = QStringLiteral("recent");
    bool m_scanning = false;
    int m_generation = 0;
    QList<Item> m_all;
    QList<Item> m_view;
};
