// SPDX-License-Identifier: GPL-3.0-or-later
#include "playlistmodel.h"

#include <QFileInfo>
#include <QRandomGenerator>
#include <QSettings>

#include <algorithm>

PlaylistModel::PlaylistModel(QObject *parent)
    : QAbstractListModel(parent)
{
    QSettings s;
    for (const QVariant &v : s.value("queue/items").toList())
        m_items << v.toUrl();
    m_current = std::clamp(s.value("queue/current", -1).toInt(), -1, int(m_items.size()) - 1);
    m_shuffle = s.value("queue/shuffle", false).toBool();
    m_repeat = s.value("queue/repeat", "off").toString();
}

PlaylistModel::~PlaylistModel()
{
    save();
}

void PlaylistModel::save() const
{
    QSettings s;
    QVariantList list;
    for (const QUrl &u : m_items)
        list << u;
    s.setValue("queue/items", list);
    s.setValue("queue/current", m_current);
    s.setValue("queue/shuffle", m_shuffle);
    s.setValue("queue/repeat", m_repeat);
}

int PlaylistModel::rowCount(const QModelIndex &parent) const
{
    return parent.isValid() ? 0 : int(m_items.size());
}

QVariant PlaylistModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() >= m_items.size())
        return {};
    const QUrl &u = m_items.at(index.row());
    switch (role) {
    case UrlRole: return u;
    case Qt::DisplayRole:
    case TitleRole: {
        const QString base = QFileInfo(u.path()).completeBaseName();
        return base.isEmpty() ? u.toDisplayString() : QString(base).replace('_', ' ');
    }
    case IsCurrentRole: return index.row() == m_current;
    case KindRole: {
        static const QStringList audio = {"mp3", "flac", "ogg", "opus", "m4a", "aac", "wav", "wma"};
        return audio.contains(QFileInfo(u.path()).suffix().toLower()) ? "audio" : "video";
    }
    }
    return {};
}

QHash<int, QByteArray> PlaylistModel::roleNames() const
{
    return {{UrlRole, "url"}, {TitleRole, "title"}, {IsCurrentRole, "isCurrent"}, {KindRole, "kind"}};
}

QUrl PlaylistModel::currentUrl() const
{
    return (m_current >= 0 && m_current < m_items.size()) ? m_items.at(m_current) : QUrl();
}

void PlaylistModel::touchCurrent(int old)
{
    if (old >= 0 && old < m_items.size())
        emit dataChanged(index(old), index(old), {IsCurrentRole});
    if (m_current >= 0 && m_current < m_items.size())
        emit dataChanged(index(m_current), index(m_current), {IsCurrentRole});
    emit currentChanged();
    save();
    if (m_current >= 0)
        emit playRequested(currentUrl());
}

void PlaylistModel::setCurrentIndex(int i)
{
    if (i < -1 || i >= m_items.size())
        return;
    const int old = m_current;
    if (old >= 0 && old != i)
        m_history << old;
    m_current = i;
    touchCurrent(old);
}

void PlaylistModel::setShuffle(bool s)
{
    if (s == m_shuffle) return;
    m_shuffle = s;
    m_history.clear();
    emit modeChanged();
    emit currentChanged();
    save();
}

void PlaylistModel::setRepeat(const QString &r)
{
    if (r == m_repeat) return;
    m_repeat = r;
    emit modeChanged();
    emit currentChanged();
    save();
}

void PlaylistModel::cycleRepeat()
{
    setRepeat(m_repeat == "off" ? "all" : m_repeat == "all" ? "one" : "off");
}

bool PlaylistModel::hasNext() const
{
    return !m_items.isEmpty() && (m_shuffle || m_repeat != "off" || m_current < m_items.size() - 1);
}

bool PlaylistModel::hasPrevious() const
{
    return !m_history.isEmpty() || m_current > 0;
}

void PlaylistModel::playAll(const QVariantList &urls, int start)
{
    beginResetModel();
    m_items.clear();
    for (const QVariant &v : urls)
        m_items << v.toUrl();
    m_history.clear();
    m_current = m_items.isEmpty() ? -1 : std::clamp(start, 0, int(m_items.size()) - 1);
    endResetModel();
    emit countChanged();
    emit currentChanged();
    save();
    if (m_current >= 0)
        emit playRequested(currentUrl());
}

void PlaylistModel::append(const QUrl &url)
{
    beginInsertRows({}, int(m_items.size()), int(m_items.size()));
    m_items << url;
    endInsertRows();
    emit countChanged();
    emit currentChanged();
    save();
}

void PlaylistModel::appendMany(const QVariantList &urls)
{
    if (urls.isEmpty()) return;
    beginInsertRows({}, int(m_items.size()), int(m_items.size() + urls.size() - 1));
    for (const QVariant &v : urls)
        m_items << v.toUrl();
    endInsertRows();
    emit countChanged();
    emit currentChanged();
    save();
}

void PlaylistModel::playNext(const QUrl &url)
{
    const int at = m_current + 1;
    beginInsertRows({}, at, at);
    m_items.insert(at, url);
    endInsertRows();
    emit countChanged();
    emit currentChanged();
    save();
}

void PlaylistModel::remove(int row)
{
    if (row < 0 || row >= m_items.size()) return;
    beginRemoveRows({}, row, row);
    m_items.removeAt(row);
    endRemoveRows();
    m_history.removeAll(row);
    for (int &h : m_history)
        if (h > row) --h;
    if (row < m_current)
        --m_current;
    else if (row == m_current)
        m_current = std::min(m_current, int(m_items.size()) - 1);
    emit countChanged();
    emit currentChanged();
    save();
}

void PlaylistModel::move(int from, int to)
{
    if (from == to || from < 0 || to < 0 || from >= m_items.size() || to >= m_items.size())
        return;
    beginMoveRows({}, from, from, {}, to > from ? to + 1 : to);
    m_items.move(from, to);
    endMoveRows();
    if (m_current == from) m_current = to;
    else if (from < m_current && to >= m_current) --m_current;
    else if (from > m_current && to <= m_current) ++m_current;
    m_history.clear();
    emit currentChanged();
    save();
}

void PlaylistModel::clear()
{
    beginResetModel();
    m_items.clear();
    m_current = -1;
    m_history.clear();
    endResetModel();
    emit countChanged();
    emit currentChanged();
    save();
}

bool PlaylistModel::next(bool userInitiated)
{
    if (m_items.isEmpty())
        return false;
    if (!userInitiated && m_repeat == "one") {
        touchCurrent(m_current); // replay same item
        return true;
    }
    int n;
    if (m_shuffle && m_items.size() > 1) {
        do n = QRandomGenerator::global()->bounded(int(m_items.size()));
        while (n == m_current);
    } else {
        n = m_current + 1;
        if (n >= m_items.size()) {
            if (m_repeat == "off")
                return false;
            n = 0;
        }
    }
    setCurrentIndex(n);
    return true;
}

bool PlaylistModel::previous()
{
    if (m_items.isEmpty())
        return false;
    const int old = m_current;
    if (!m_history.isEmpty()) {
        m_current = m_history.takeLast();
    } else if (m_current > 0) {
        m_current -= 1;
    } else {
        return false;
    }
    touchCurrent(old);
    return true;
}
