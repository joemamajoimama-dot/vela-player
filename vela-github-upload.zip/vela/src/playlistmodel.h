// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include <QAbstractListModel>
#include <QUrl>
#include <QtQml/qqmlregistration.h>

// The play queue. Persists across sessions.
class PlaylistModel : public QAbstractListModel
{
    Q_OBJECT
    QML_ELEMENT

    Q_PROPERTY(int currentIndex READ currentIndex WRITE setCurrentIndex NOTIFY currentChanged)
    Q_PROPERTY(QUrl currentUrl READ currentUrl NOTIFY currentChanged)
    Q_PROPERTY(bool shuffle READ shuffle WRITE setShuffle NOTIFY modeChanged)
    Q_PROPERTY(QString repeat READ repeat WRITE setRepeat NOTIFY modeChanged) // off | all | one
    Q_PROPERTY(int count READ rowCount NOTIFY countChanged)
    Q_PROPERTY(bool hasNext READ hasNext NOTIFY currentChanged)
    Q_PROPERTY(bool hasPrevious READ hasPrevious NOTIFY currentChanged)

public:
    enum Roles { UrlRole = Qt::UserRole + 1, TitleRole, IsCurrentRole, KindRole };

    explicit PlaylistModel(QObject *parent = nullptr);
    ~PlaylistModel() override;

    int rowCount(const QModelIndex &parent = {}) const override;
    QVariant data(const QModelIndex &index, int role) const override;
    QHash<int, QByteArray> roleNames() const override;

    int currentIndex() const { return m_current; }
    void setCurrentIndex(int i);
    QUrl currentUrl() const;
    bool shuffle() const { return m_shuffle; }
    void setShuffle(bool s);
    QString repeat() const { return m_repeat; }
    void setRepeat(const QString &r);
    bool hasNext() const;
    bool hasPrevious() const;

    // Replace the queue and start at `start`.
    Q_INVOKABLE void playAll(const QVariantList &urls, int start = 0);
    Q_INVOKABLE void append(const QUrl &url);
    Q_INVOKABLE void appendMany(const QVariantList &urls);
    Q_INVOKABLE void playNext(const QUrl &url);
    Q_INVOKABLE void remove(int row);
    Q_INVOKABLE void move(int from, int to);
    Q_INVOKABLE void clear();
    // Advance; returns false at the end of the queue.
    Q_INVOKABLE bool next(bool userInitiated = true);
    Q_INVOKABLE bool previous();
    Q_INVOKABLE void cycleRepeat();

signals:
    void currentChanged();
    void modeChanged();
    void countChanged();
    void playRequested(const QUrl &url);

private:
    void save() const;
    void touchCurrent(int old);

    QList<QUrl> m_items;
    int m_current = -1;
    bool m_shuffle = false;
    QString m_repeat = QStringLiteral("off");
    QList<int> m_history; // for "previous" while shuffling
};
