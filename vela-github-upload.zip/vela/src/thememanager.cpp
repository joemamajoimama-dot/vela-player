// SPDX-License-Identifier: GPL-3.0-or-later
#include "thememanager.h"

#include <QDesktopServices>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonObject>
#include <QRegularExpression>
#include <QSettings>
#include <QStandardPaths>

#include <algorithm>
#include <cmath>

static const char *kBuiltinDir = ":/qt/qml/Vela/themes";

ThemeManager::ThemeManager(QObject *parent)
    : QObject(parent)
{
    QSettings s;
    m_currentId = s.value("appearance/theme", "vela-night").toString();
    m_overrides = s.value("appearance/overrides").toMap();

    m_reloadDebounce.setSingleShot(true);
    m_reloadDebounce.setInterval(150);
    connect(&m_reloadDebounce, &QTimer::timeout, this, &ThemeManager::reload);
    connect(&m_watcher, &QFileSystemWatcher::directoryChanged, &m_reloadDebounce, qOverload<>(&QTimer::start));
    connect(&m_watcher, &QFileSystemWatcher::fileChanged, &m_reloadDebounce, qOverload<>(&QTimer::start));

    QDir().mkpath(themesFolder());
    loadAll();
    watchUserDir();
    recompute();
}

QVariantMap ThemeManager::defaultOptions()
{
    return {
        {"radius", 16},             // corner radius of cards, panels, buttons (px)
        {"blur", 48},               // glass blur strength (0 = off)
        {"glassOpacity", 0.62},     // tint opacity of glass surfaces
        {"density", "comfortable"}, // compact | comfortable | spacious
        {"fontFamily", "Inter"},
        {"fontScale", 1.0},
        {"motion", true},           // animations on/off
        {"motionSpeed", 1.0},       // 0.5 = snappy, 2 = slow & silky
        {"controlStyle", "floating"}, // floating | docked | minimal
        {"seekStyle", "thick"},     // thin | thick
        {"ambient", true},          // ambient light behind the video
        {"ambientStrength", 0.55},
        {"autoHideMs", 2600},
        {"cardSize", 236},
        {"sidebar", "expanded"},    // expanded | compact
        {"titlebar", "custom"},     // custom | system
        {"accentGlow", true},
        {"showRemaining", false},
        {"grain", false},           // subtle film grain over the UI chrome
        {"autoOpenPlayer", true},   // jump to the player when something starts
        {"volumeBoost", false},     // allow volume up to 200%
        {"defaultFill", "fit"},     // fit | fill | stretch
        {"libraryLayout", "auto"},  // auto | grid | list
    };
}

QString ThemeManager::themesFolder() const
{
    return QStandardPaths::writableLocation(QStandardPaths::GenericConfigLocation) + "/Vela/themes";
}

QStringList ThemeManager::accentPresets() const
{
    return {"#7C5CFF", "#4F8BFF", "#2EC5CE", "#3DDC97", "#C6F432",
            "#FFC145", "#FF8A3D", "#FF5C7A", "#F25FD0", "#E8E6F0"};
}

static QVariantMap readTheme(const QString &path, bool builtin)
{
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly))
        return {};
    QJsonParseError err;
    const QJsonDocument doc = QJsonDocument::fromJson(f.readAll(), &err);
    if (err.error != QJsonParseError::NoError || !doc.isObject()) {
        qWarning("Vela: skipping theme %s: %s", qPrintable(path), qPrintable(err.errorString()));
        return {};
    }
    QVariantMap t = doc.object().toVariantMap();
    if (!t.contains("colors"))
        return {};
    t["id"] = (builtin ? QString() : QStringLiteral("user:")) + QFileInfo(path).completeBaseName();
    t["builtin"] = builtin;
    if (!t.contains("name"))
        t["name"] = QFileInfo(path).completeBaseName();
    return t;
}

void ThemeManager::loadAll()
{
    m_themes.clear();
    m_themeList.clear();

    auto add = [this](const QVariantMap &t) {
        if (t.isEmpty())
            return;
        m_themes.insert(t["id"].toString(), t);
        const QVariantMap c = t["colors"].toMap();
        m_themeList.append(QVariantMap{
            {"id", t["id"]}, {"name", t["name"]}, {"dark", t.value("dark", true)},
            {"builtin", t["builtin"]}, {"author", t.value("author")},
            {"bg", c.value("bg")}, {"surface", c.value("surface")},
            {"accent", c.value("accent")}, {"text", c.value("text")},
        });
    };

    QDir builtin(kBuiltinDir);
    const QStringList order = {"vela-night", "vela-day", "nebula", "ember", "aurora", "oled"};
    for (const QString &id : order)
        add(readTheme(builtin.filePath(id + ".json"), true));
    for (const QFileInfo &fi : builtin.entryInfoList({"*.json"}, QDir::Files, QDir::Name))
        if (!order.contains(fi.completeBaseName()))
            add(readTheme(fi.filePath(), true));

    QDir user(themesFolder());
    for (const QFileInfo &fi : user.entryInfoList({"*.json"}, QDir::Files, QDir::Name))
        add(readTheme(fi.filePath(), false));

    if (!m_themes.contains(m_currentId))
        m_currentId = "vela-night";
    emit themesChanged();
}

void ThemeManager::watchUserDir()
{
    if (!m_watcher.directories().isEmpty())
        m_watcher.removePaths(m_watcher.directories());
    if (!m_watcher.files().isEmpty())
        m_watcher.removePaths(m_watcher.files());
    m_watcher.addPath(themesFolder());
    QDir user(themesFolder());
    for (const QFileInfo &fi : user.entryInfoList({"*.json"}, QDir::Files))
        m_watcher.addPath(fi.filePath());
}

void ThemeManager::reload()
{
    loadAll();
    watchUserDir();
    recompute();
}

static double luminance(const QColor &c)
{
    auto ch = [](double v) { return v <= 0.03928 ? v / 12.92 : std::pow((v + 0.055) / 1.055, 2.4); };
    return 0.2126 * ch(c.redF()) + 0.7152 * ch(c.greenF()) + 0.0722 * ch(c.blueF());
}

void ThemeManager::recompute()
{
    const QVariantMap theme = m_themes.value(m_currentId);

    // Options: defaults <- theme <- user overrides
    QVariantMap opt = defaultOptions();
    const QVariantMap themeOpt = theme.value("options").toMap();
    for (auto it = themeOpt.cbegin(); it != themeOpt.cend(); ++it)
        opt[it.key()] = it.value();
    for (auto it = m_overrides.cbegin(); it != m_overrides.cend(); ++it)
        if (it.key() != "accent")
            opt[it.key()] = it.value();

    // Colours: theme <- accent override, with derived tokens filled in.
    QVariantMap c = theme.value("colors").toMap();
    QVariantMap out;
    for (auto it = c.cbegin(); it != c.cend(); ++it)
        out[it.key()] = QColor(it.value().toString());

    if (m_overrides.contains("accent")) {
        const QColor a(m_overrides.value("accent").toString());
        if (a.isValid()) {
            out["accent"] = a;
            out.remove("accentHi");
            out.remove("onAccent");
        }
    }
    const QColor accent = out.value("accent", QColor("#7C5CFF")).value<QColor>();
    if (!out.contains("accentHi"))
        out["accentHi"] = accent.lighter(118);
    if (!out.contains("onAccent"))
        out["onAccent"] = luminance(accent) > 0.45 ? QColor("#111015") : QColor("#FFFFFF");
    out["accentSoft"] = alpha(accent, 0.16);

    const QString density = opt.value("density").toString();
    opt["space"] = density == "compact" ? 0.78 : density == "spacious" ? 1.22 : 1.0;

    m_options = opt;
    m_colors = out;
    emit changed();
}

void ThemeManager::setCurrentId(const QString &id)
{
    if (id == m_currentId || !m_themes.contains(id))
        return;
    m_currentId = id;
    QSettings().setValue("appearance/theme", id);
    recompute();
}

QString ThemeManager::currentName() const
{
    return m_themes.value(m_currentId).value("name").toString();
}

bool ThemeManager::dark() const
{
    return m_themes.value(m_currentId).value("dark", true).toBool();
}

void ThemeManager::set(const QString &key, const QVariant &value)
{
    m_overrides[key] = value;
    QSettings().setValue("appearance/overrides", m_overrides);
    recompute();
}

void ThemeManager::unset(const QString &key)
{
    if (m_overrides.remove(key)) {
        QSettings().setValue("appearance/overrides", m_overrides);
        recompute();
    }
}

void ThemeManager::resetOverrides()
{
    m_overrides.clear();
    QSettings().remove("appearance/overrides");
    recompute();
}

QString ThemeManager::exportTheme(const QString &name)
{
    QString slug = name.toLower();
    slug.replace(QRegularExpression("[^a-z0-9]+"), "-");
    slug = slug.trimmed();
    if (slug.isEmpty())
        slug = "my-theme";

    QJsonObject colors;
    for (auto it = m_colors.cbegin(); it != m_colors.cend(); ++it) {
        if (it.key() == "accentSoft")
            continue;
        colors[it.key()] = it.value().value<QColor>().name(QColor::HexArgb);
    }
    QJsonObject opts = QJsonObject::fromVariantMap(m_options);
    QJsonObject root{{"name", name.isEmpty() ? "My Theme" : name},
                     {"dark", dark()},
                     {"author", qEnvironmentVariable("USER")},
                     {"colors", colors},
                     {"options", opts}};

    const QString path = themesFolder() + "/" + slug + ".json";
    QFile f(path);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Truncate))
        return {};
    f.write(QJsonDocument(root).toJson(QJsonDocument::Indented));
    f.close();
    reload();
    setCurrentId("user:" + slug);
    return path;
}

bool ThemeManager::importTheme(const QUrl &file)
{
    const QString src = file.toLocalFile();
    if (readTheme(src, false).isEmpty())
        return false;
    const QString dst = themesFolder() + "/" + QFileInfo(src).fileName();
    QFile::remove(dst);
    if (!QFile::copy(src, dst))
        return false;
    reload();
    setCurrentId("user:" + QFileInfo(src).completeBaseName());
    return true;
}

QVariant ThemeManager::setting(const QString &key, const QVariant &fallback) const
{
    return QSettings().value(key, fallback);
}

void ThemeManager::setSetting(const QString &key, const QVariant &value)
{
    QSettings().setValue(key, value);
    ++m_settingsRev;
    emit settingsChanged();
}

void ThemeManager::openThemesFolder()
{
    QDesktopServices::openUrl(QUrl::fromLocalFile(themesFolder()));
}

QColor ThemeManager::alpha(const QColor &c, double a)
{
    QColor o = c;
    o.setAlphaF(float(std::clamp(a, 0.0, 1.0) * c.alphaF()));
    return o;
}

QColor ThemeManager::mix(const QColor &a, const QColor &b, double t)
{
    t = std::clamp(t, 0.0, 1.0);
    return QColor::fromRgbF(float(a.redF() + (b.redF() - a.redF()) * t),
                            float(a.greenF() + (b.greenF() - a.greenF()) * t),
                            float(a.blueF() + (b.blueF() - a.blueF()) * t),
                            float(a.alphaF() + (b.alphaF() - a.alphaF()) * t));
}

QString ThemeManager::icon(const QString &name)
{
    return QStringLiteral("qrc:/qt/qml/Vela/icons/%1.svg").arg(name);
}
