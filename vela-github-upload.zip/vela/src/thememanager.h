// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include <QColor>
#include <QFileSystemWatcher>
#include <QObject>
#include <QTimer>
#include <QUrl>
#include <QVariantMap>
#include <QtQml/qqmlregistration.h>

// Loads built-in and user themes (JSON) and layers the user's personal
// overrides on top. Everything QML draws reads from `c` (colours) and
// `opt` (shape, motion, layout options), so a theme file or a slider in
// Settings can restyle the whole app live.
//
// User themes live in ~/.config/Vela/themes/*.json (or the Flatpak
// equivalent) and are hot-reloaded when the file changes on disk.
class ThemeManager : public QObject
{
    Q_OBJECT
    QML_NAMED_ELEMENT(Theme)
    QML_SINGLETON

    Q_PROPERTY(QVariantList themes READ themes NOTIFY themesChanged)
    Q_PROPERTY(QString currentId READ currentId WRITE setCurrentId NOTIFY changed)
    Q_PROPERTY(QString currentName READ currentName NOTIFY changed)
    Q_PROPERTY(bool dark READ dark NOTIFY changed)
    Q_PROPERTY(QVariantMap c READ colors NOTIFY changed)
    Q_PROPERTY(QVariantMap opt READ options NOTIFY changed)
    Q_PROPERTY(QVariantMap overrides READ overrides NOTIFY changed)
    Q_PROPERTY(QString themesFolder READ themesFolder CONSTANT)
    Q_PROPERTY(QStringList accentPresets READ accentPresets CONSTANT)
    Q_PROPERTY(int settingsRevision READ settingsRevision NOTIFY settingsChanged)

public:
    explicit ThemeManager(QObject *parent = nullptr);

    QVariantList themes() const { return m_themeList; }
    QString currentId() const { return m_currentId; }
    void setCurrentId(const QString &id);
    QString currentName() const;
    bool dark() const;
    QVariantMap colors() const { return m_colors; }
    QVariantMap options() const { return m_options; }
    QVariantMap overrides() const { return m_overrides; }
    QString themesFolder() const;
    QStringList accentPresets() const;

    Q_INVOKABLE void set(const QString &key, const QVariant &value);
    Q_INVOKABLE void unset(const QString &key);
    Q_INVOKABLE void resetOverrides();
    Q_INVOKABLE QString exportTheme(const QString &name);
    Q_INVOKABLE bool importTheme(const QUrl &file);
    Q_INVOKABLE void openThemesFolder();
    Q_INVOKABLE void reload();
    // Plain QSettings access for options that live outside the theme (subtitle style, …)
    Q_INVOKABLE QVariant setting(const QString &key, const QVariant &fallback = {}) const;
    Q_INVOKABLE void setSetting(const QString &key, const QVariant &value);
    int settingsRevision() const { return m_settingsRev; }

    Q_INVOKABLE static QColor alpha(const QColor &c, double a);
    Q_INVOKABLE static QColor mix(const QColor &a, const QColor &b, double t);
    Q_INVOKABLE static QString icon(const QString &name);

signals:
    void changed();
    void themesChanged();
    void settingsChanged();

private:
    void loadAll();
    void recompute();
    void watchUserDir();
    static QVariantMap defaultOptions();

    QMap<QString, QVariantMap> m_themes; // id -> full theme json
    QVariantList m_themeList;
    QString m_currentId;
    QVariantMap m_colors, m_options, m_overrides;
    QFileSystemWatcher m_watcher;
    QTimer m_reloadDebounce;
    int m_settingsRev = 0;
};
