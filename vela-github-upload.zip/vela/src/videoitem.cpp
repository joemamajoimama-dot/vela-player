// SPDX-License-Identifier: GPL-3.0-or-later
#include "videoitem.h"
#include "vlcplayer.h"

#include <QQuickWindow>
#include <QSGSimpleRectNode>
#include <QSGSimpleTextureNode>

VideoItem::VideoItem(QQuickItem *parent)
    : QQuickItem(parent)
{
    setFlag(ItemHasContents, true);
}

void VideoItem::setPlayer(VlcPlayer *p)
{
    if (p == m_player)
        return;
    if (m_player)
        disconnect(m_player, nullptr, this, nullptr);
    m_player = p;
    if (m_player)
        connect(m_player, &VlcPlayer::frameReady, this, &QQuickItem::update);
    emit playerChanged();
    update();
}

void VideoItem::setFillMode(FillMode m)
{
    if (m == m_fillMode)
        return;
    m_fillMode = m;
    emit fillModeChanged();
    update();
}

void VideoItem::setAspectRatio(const QString &a)
{
    if (a == m_aspect)
        return;
    m_aspect = a;
    emit fillModeChanged();
    update();
}

void VideoItem::setZoom(double z)
{
    z = qBound(0.5, z, 4.0);
    if (qFuzzyCompare(z, m_zoom))
        return;
    m_zoom = z;
    emit fillModeChanged();
    update();
}

void VideoItem::geometryChange(const QRectF &n, const QRectF &o)
{
    QQuickItem::geometryChange(n, o);
    update();
}

void VideoItem::recomputeRect(QSizeF frame)
{
    QRectF r;
    if (!frame.isEmpty()) {
        double ar = frame.width() / frame.height();
        const QStringList parts = m_aspect.split(':');
        if (parts.size() == 2 && parts[1].toDouble() > 0)
            ar = parts[0].toDouble() / parts[1].toDouble();

        const QSizeF box = size();
        QSizeF s(box.width(), box.width() / ar);
        switch (m_fillMode) {
        case Fit:
            if (s.height() > box.height())
                s = QSizeF(box.height() * ar, box.height());
            break;
        case Fill:
            if (s.height() < box.height())
                s = QSizeF(box.height() * ar, box.height());
            break;
        case Stretch:
            s = box;
            break;
        }
        s *= m_zoom;
        r = QRectF(QPointF((box.width() - s.width()) / 2, (box.height() - s.height()) / 2), s);
    }
    if (r != m_contentRect) {
        m_contentRect = r;
        QMetaObject::invokeMethod(this, &VideoItem::contentRectChanged, Qt::QueuedConnection);
    }
}

QSGNode *VideoItem::updatePaintNode(QSGNode *old, UpdatePaintNodeData *)
{
    QImage frame;
    if (!m_player || !m_player->takeFrame(frame) || frame.isNull()) {
        delete old;
        recomputeRect({});
        return nullptr;
    }

    auto *node = static_cast<QSGSimpleTextureNode *>(old);
    if (!node) {
        node = new QSGSimpleTextureNode;
        node->setOwnsTexture(true);
        node->setFiltering(QSGTexture::Linear);
    }

    QSGTexture *tex = window()->createTextureFromImage(frame);
    tex->setFiltering(QSGTexture::Linear);
    node->setTexture(tex); // previous texture is deleted because the node owns it

    recomputeRect(frame.size());

    // Clip to our bounds when filling/zooming past the edges.
    const QRectF bounds(QPointF(0, 0), size());
    const QRectF visible = m_contentRect.intersected(bounds);
    if (visible.isEmpty()) {
        node->setRect(QRectF());
        return node;
    }
    const double sx = frame.width() / m_contentRect.width();
    const double sy = frame.height() / m_contentRect.height();
    node->setRect(visible);
    node->setSourceRect(QRectF((visible.x() - m_contentRect.x()) * sx,
                               (visible.y() - m_contentRect.y()) * sy,
                               visible.width() * sx, visible.height() * sy));
    return node;
}
