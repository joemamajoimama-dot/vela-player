// SPDX-License-Identifier: GPL-3.0-or-later
// Vela — a thin, QML-friendly wrapper around a libVLC media player.
//
// Video is rendered through libVLC's memory callbacks ("vmem") into a
// triple-buffered RV32 frame store that VideoItem uploads as a texture.
// This works the same on Wayland and X11 and lets QML put effects
// (ambient glow, blur, rounded corners) on top of the video.
#pragma once

#include <QImage>
#include <QMutex>
#include <QObject>
#include <QSize>
#include <QStringList>
#include <QUrl>
#include <QVariantList>
#include <QtQml/qqmlregistration.h>

#include <atomic>
#include <vector>

struct libvlc_instance_t;
struct libvlc_media_player_t;
struct libvlc_media_t;
struct libvlc_event_manager_t;
struct libvlc_event_t;
struct libvlc_equalizer_t;

class VlcPlayer : public QObject
{
    Q_OBJECT
    QML_ELEMENT

    Q_PROPERTY(QUrl source READ source NOTIFY sourceChanged)
    Q_PROPERTY(State state READ state NOTIFY stateChanged)
    Q_PROPERTY(bool playing READ isPlaying NOTIFY stateChanged)
    Q_PROPERTY(bool hasMedia READ hasMedia NOTIFY sourceChanged)
    Q_PROPERTY(qint64 time READ time NOTIFY timeChanged)
    Q_PROPERTY(qint64 length READ length NOTIFY lengthChanged)
    Q_PROPERTY(double position READ position NOTIFY timeChanged)
    Q_PROPERTY(double buffering READ buffering NOTIFY bufferingChanged)
    Q_PROPERTY(int volume READ volume WRITE setVolume NOTIFY volumeChanged)
    Q_PROPERTY(bool muted READ isMuted WRITE setMuted NOTIFY mutedChanged)
    Q_PROPERTY(double rate READ rate WRITE setRate NOTIFY rateChanged)
    Q_PROPERTY(QString title READ title NOTIFY titleChanged)
    Q_PROPERTY(QString artist READ artist NOTIFY titleChanged)
    Q_PROPERTY(QString artworkUrl READ artworkUrl NOTIFY titleChanged)
    Q_PROPERTY(bool hasVideo READ hasVideo NOTIFY videoSizeChanged)
    Q_PROPERTY(QSize videoSize READ videoSize NOTIFY videoSizeChanged)
    Q_PROPERTY(QVariantList audioTracks READ audioTracks NOTIFY tracksChanged)
    Q_PROPERTY(QVariantList subtitleTracks READ subtitleTracks NOTIFY tracksChanged)
    Q_PROPERTY(int audioTrack READ audioTrack WRITE setAudioTrack NOTIFY tracksChanged)
    Q_PROPERTY(int subtitleTrack READ subtitleTrack WRITE setSubtitleTrack NOTIFY tracksChanged)
    Q_PROPERTY(int subtitleDelay READ subtitleDelay WRITE setSubtitleDelay NOTIFY delaysChanged)
    Q_PROPERTY(int audioDelay READ audioDelay WRITE setAudioDelay NOTIFY delaysChanged)
    Q_PROPERTY(bool hardwareDecoding READ hardwareDecoding WRITE setHardwareDecoding NOTIFY optionsChanged)
    Q_PROPERTY(int subtitleScale READ subtitleScale WRITE setSubtitleScale NOTIFY optionsChanged)
    Q_PROPERTY(QStringList equalizerPresets READ equalizerPresets CONSTANT)
    Q_PROPERTY(QVariantList equalizerBands READ equalizerBands CONSTANT)
    Q_PROPERTY(double equalizerPreamp READ equalizerPreamp NOTIFY equalizerChanged)
    Q_PROPERTY(QVariantList equalizerValues READ equalizerValues NOTIFY equalizerChanged)
    Q_PROPERTY(bool equalizerEnabled READ equalizerEnabled WRITE setEqualizerEnabled NOTIFY equalizerChanged)
    Q_PROPERTY(QString lastError READ lastError NOTIFY errorOccurred)
    Q_PROPERTY(QString vlcVersion READ vlcVersion CONSTANT)

public:
    enum State { Idle, Opening, Buffering, Playing, Paused, Stopped, Ended, Error };
    Q_ENUM(State)

    explicit VlcPlayer(QObject *parent = nullptr);
    ~VlcPlayer() override;

    QUrl source() const { return m_source; }
    State state() const { return m_state; }
    bool isPlaying() const { return m_state == Playing || m_state == Buffering; }
    bool hasMedia() const { return !m_source.isEmpty(); }
    qint64 time() const { return m_time; }
    qint64 length() const { return m_length; }
    double position() const { return m_length > 0 ? double(m_time) / double(m_length) : 0.0; }
    double buffering() const { return m_buffering; }
    int volume() const { return m_volume; }
    bool isMuted() const { return m_muted; }
    double rate() const { return m_rate; }
    QString title() const { return m_title; }
    QString artist() const { return m_artist; }
    QString artworkUrl() const { return m_artworkUrl; }
    bool hasVideo() const { return m_videoSize.isValid() && !m_videoSize.isEmpty(); }
    QSize videoSize() const { return m_videoSize; }
    QVariantList audioTracks() const { return m_audioTracks; }
    QVariantList subtitleTracks() const { return m_subtitleTracks; }
    int audioTrack() const;
    int subtitleTrack() const;
    int subtitleDelay() const { return m_subtitleDelay; }
    int audioDelay() const { return m_audioDelay; }
    QStringList equalizerPresets() const;
    QVariantList equalizerBands() const;
    bool equalizerEnabled() const { return m_eqEnabled; }
    double equalizerPreamp() const { return m_eqPreamp; }
    QVariantList equalizerValues() const { return m_eqBandsDb; }
    QString lastError() const { return m_lastError; }
    QString vlcVersion() const;
    bool hardwareDecoding() const { return m_hwDecoding; }
    void setHardwareDecoding(bool on);
    int subtitleScale() const { return m_subtitleScale; }
    void setSubtitleScale(int pct);

    void setVolume(int v);
    void setMuted(bool m);
    void setRate(double r);
    void setAudioTrack(int id);
    void setSubtitleTrack(int id);
    void setSubtitleDelay(int ms);
    void setAudioDelay(int ms);
    void setEqualizerEnabled(bool on);

    Q_INVOKABLE void open(const QUrl &url, qint64 startAtMs = 0);
    Q_INVOKABLE void play();
    Q_INVOKABLE void pause();
    Q_INVOKABLE void togglePause();
    Q_INVOKABLE void stop();
    Q_INVOKABLE void seek(qint64 ms);
    Q_INVOKABLE void seekRelative(qint64 deltaMs);
    Q_INVOKABLE void setPosition(double pos);
    Q_INVOKABLE void nextFrame();
    Q_INVOKABLE bool addSubtitle(const QUrl &url);
    Q_INVOKABLE QString snapshot();
    Q_INVOKABLE QVariantList equalizerPresetValues(int preset) const;
    Q_INVOKABLE void setEqualizer(double preamp, const QVariantList &bandsDb);

    // Called from the scene graph render thread.
    bool takeFrame(QImage &out);
    QImage currentFrameCopy();

signals:
    void sourceChanged();
    void stateChanged();
    void timeChanged();
    void lengthChanged();
    void bufferingChanged();
    void volumeChanged();
    void mutedChanged();
    void rateChanged();
    void titleChanged();
    void videoSizeChanged();
    void tracksChanged();
    void delaysChanged();
    void optionsChanged();
    void equalizerChanged();
    void endReached();
    void errorOccurred();
    void frameReady();

private:
    static void handleEvent(const libvlc_event_t *ev, void *self);
    static unsigned videoSetup(void **opaque, char *chroma, unsigned *w, unsigned *h,
                               unsigned *pitches, unsigned *lines);
    static void videoCleanup(void *opaque);
    static void *videoLock(void *opaque, void **planes);
    static void videoUnlock(void *opaque, void *picture, void *const *planes);
    static void videoDisplay(void *opaque, void *picture);

    void setState(State s);
    void refreshTracks();
    void refreshMeta();
    void applyEqualizer();

    libvlc_instance_t *m_vlc = nullptr;
    libvlc_media_player_t *m_mp = nullptr;
    libvlc_media_t *m_media = nullptr;
    libvlc_equalizer_t *m_eq = nullptr;

    QUrl m_source;
    State m_state = Idle;
    qint64 m_time = 0;
    qint64 m_length = 0;
    qint64 m_pendingStart = 0;
    double m_buffering = 0;
    int m_volume = 100;
    bool m_muted = false;
    double m_rate = 1.0;
    QString m_title, m_artist, m_artworkUrl, m_lastError;
    QSize m_videoSize;
    QVariantList m_audioTracks, m_subtitleTracks;
    int m_subtitleDelay = 0;
    int m_audioDelay = 0;
    bool m_hwDecoding = true;
    int m_subtitleScale = 100;
    bool m_eqEnabled = false;
    double m_eqPreamp = 0;
    QVariantList m_eqBandsDb;

    // Triple-buffered frame store (VLC writes `write`, display swaps to
    // `ready`, render thread swaps `ready` into `read`).
    QMutex m_frameLock;
    std::vector<uchar> m_buffers[3];
    int m_writeIdx = 0, m_readyIdx = 1, m_readIdx = 2;
    bool m_hasNewFrame = false;
    unsigned m_frameW = 0, m_frameH = 0, m_pitch = 0;
    std::atomic<bool> m_alive{true};
};
