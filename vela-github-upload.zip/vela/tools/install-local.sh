#!/usr/bin/env bash
# Build Vela from this checkout, install it for the current user (~/.local),
# and add an app-menu entry plus a Desktop shortcut. Only the optional
# dependency step needs sudo.
#
#   tools/install-local.sh             install deps (sudo), build, install, add launchers
#   tools/install-local.sh --no-deps   skip the dependency step
#
# Tested on Nobara / Fedora 44 (GCC 16, Qt 6.11). The apt and pacman package
# lists follow the README and the CI workflow but have not been run here.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PREFIX="${PREFIX:-$HOME/.local}"
APP_ID="$(sed -n 's/^set(VELA_APP_ID "\([^"]*\)".*/\1/p' "$ROOT/CMakeLists.txt")"
[ -n "$APP_ID" ] || { echo "Could not read VELA_APP_ID from CMakeLists.txt" >&2; exit 1; }

install_deps() {
  if command -v dnf >/dev/null; then
    sudo dnf install -y cmake ninja-build gcc-c++ vlc vlc-devel \
      qt6-qtbase-devel qt6-qtdeclarative-devel qt6-qtsvg-devel
  elif command -v pacman >/dev/null; then
    sudo pacman -S --needed --noconfirm base-devel cmake ninja vlc \
      qt6-base qt6-declarative qt6-svg
  elif command -v apt >/dev/null; then
    sudo apt install -y build-essential cmake ninja-build pkg-config libvlc-dev vlc \
      qt6-base-dev qt6-declarative-dev qt6-svg-dev "qml6-module-qtquick*" "qml6-module-qtqml*"
  else
    echo "Unknown package manager: install the dependencies from README.md by hand." >&2
  fi
}

[ "${1:-}" = "--no-deps" ] || install_deps

cd "$ROOT"
# Files dated in the future (e.g. from a zip made on a machine with a skewed
# clock) make Ninja loop with "manifest 'build.ninja' still dirty after 100 tries".
find . -path ./build -prune -o -newermt now -exec touch {} +

cmake -B build -G Ninja -Wno-dev -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX="$PREFIX"
cmake --build build
cmake --install build

# App-menu entry: use an absolute path so it works even if ~/.local/bin is not on PATH.
APP_DESKTOP="$PREFIX/share/applications/$APP_ID.desktop"
sed -i "s|^\(Try\)\?Exec=vela|\1Exec=$PREFIX/bin/vela|" "$APP_DESKTOP"

# Desktop shortcut.
DESK="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Desktop")"
mkdir -p "$DESK"
cp "$APP_DESKTOP" "$DESK/Vela.desktop"
sed -i "s|^Icon=.*|Icon=$PREFIX/share/icons/hicolor/256x256/apps/$APP_ID.png|" "$DESK/Vela.desktop"
chmod +x "$DESK/Vela.desktop"
gio set "$DESK/Vela.desktop" metadata::trusted true 2>/dev/null || true
update-desktop-database "$PREFIX/share/applications" 2>/dev/null || true

echo "Done. Launch Vela from the app menu or the Desktop shortcut ($DESK/Vela.desktop)."
echo "If the shortcut asks for permission: right-click it and choose \"Allow Launching\"."
