#!/usr/bin/env bash
# Rebrand the app id + URLs for your GitHub account before publishing.
#   tools/set-github-owner.sh <github-user-or-org> [repo-name]
# Flathub requires io.github.<owner>.* ids to match a GitHub account you control.
set -euo pipefail
owner="${1:?usage: $0 <github-owner> [repo]}"
repo="${2:-vela}"
old_id="io.github.velaplayer.Vela"
new_id="io.github.${owner}.Vela"
cd "$(dirname "$0")/.."

grep -rlZ --exclude-dir=.git -e "$old_id" -e "velaplayer/vela" -e "io.github.velaplayer" . \
  | xargs -0 sed -i \
      -e "s|$old_id|$new_id|g" \
      -e "s|io\.github\.velaplayer|io.github.${owner}|g" \
      -e "s|velaplayer/vela|${owner}/${repo}|g" \
      -e "s|velaplayer\.github\.io/vela|${owner}.github.io/${repo}|g"

find . -path ./.git -prune -o -name "*${old_id}*" -print | while read -r f; do
  mv "$f" "${f//$old_id/$new_id}"
done
echo "App id is now $new_id"
