import QtQuick
import QtQuick.Controls.Basic
import QtQuick.Layouts
import Vela

Item {
    id: root
    property var app
    property PlaylistModel queue
    property string kind: "video"
    property string heading
    property string layoutMode: Theme.opt.libraryLayout === "auto" ? (kind === "audio" ? "list" : "grid") : Theme.opt.libraryLayout
    readonly property real pad: 40 * Theme.opt.space

    LibraryModel { id: lib; kind: root.kind }

    function play(index) { root.queue.playAll(lib.urls(), index) }

    ColumnLayout {
        anchors.fill: parent
        anchors.leftMargin: root.pad
        anchors.rightMargin: root.pad
        anchors.topMargin: 64
        spacing: 22 * Theme.opt.space

        // Header
        RowLayout {
            spacing: 14
            Layout.fillWidth: true
            ColumnLayout {
                spacing: 4
                Text {
                    text: root.heading
                    color: Theme.c.text
                    font.family: "Inter Display"
                    font.pixelSize: 34 * Theme.opt.fontScale
                    font.weight: Font.Bold
                    font.letterSpacing: -0.8
                }
                Text {
                    text: lib.scanning ? qsTr("Scanning…") : qsTr("%n item(s)", "", lib.count)
                    color: Theme.c.textMuted
                    font.pixelSize: 13
                }
            }
            Item { Layout.fillWidth: true }
            PillButton {
                visible: lib.count > 0
                text: qsTr("Play all")
                icon: "play"
                primary: true
                onClicked: root.play(0)
            }
            PillButton {
                visible: lib.count > 0
                text: qsTr("Shuffle")
                icon: "shuffle"
                onClicked: { root.queue.shuffle = true; root.queue.playAll(lib.urls(), Math.floor(Math.random() * lib.count)) }
            }
        }

        // Toolbar: search, sort, layout, size
        RowLayout {
            spacing: 10
            Layout.fillWidth: true

            Rectangle {
                Layout.preferredWidth: 320
                Layout.preferredHeight: 40
                radius: Math.min(20, Theme.opt.radius)
                color: Theme.c.surface
                border.color: search.activeFocus ? Theme.c.accent : Theme.c.border
                border.width: search.activeFocus ? 1.5 : 1
                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 14
                    anchors.rightMargin: 8
                    spacing: 8
                    Icon { name: "search"; size: 17; color: Theme.c.textMuted }
                    TextField {
                        id: search
                        Layout.fillWidth: true
                        placeholderText: qsTr("Search %1").arg(root.heading.toLowerCase())
                        placeholderTextColor: Theme.c.textMuted
                        color: Theme.c.text
                        font.pixelSize: 14
                        background: null
                        selectByMouse: true
                        onTextChanged: lib.search = text
                    }
                    IconButton { visible: search.text !== ""; icon: "close"; size: 26; iconSize: 14; onClicked: search.text = "" }
                }
            }

            Repeater {
                model: [{ k: "recent", t: qsTr("Recent") }, { k: "name", t: qsTr("A–Z") }, { k: "size", t: qsTr("Size") }]
                delegate: PillButton {
                    required property var modelData
                    text: modelData.t
                    compact: true
                    selected: lib.sortBy === modelData.k
                    onClicked: lib.sortBy = modelData.k
                }
            }

            Item { Layout.fillWidth: true }

            VSlider {
                visible: root.layoutMode === "grid" && lib.count > 0
                implicitWidth: 120
                from: 160; to: 340
                value: Theme.opt.cardSize
                onMoved: Theme.set("cardSize", Math.round(value))
            }
            IconButton { icon: "layers"; size: 36; checked: root.layoutMode === "grid"; tip: qsTr("Grid"); onClicked: Theme.set("libraryLayout", "grid") }
            IconButton { icon: "queue"; size: 36; checked: root.layoutMode === "list"; tip: qsTr("List"); onClicked: Theme.set("libraryLayout", "list") }
            IconButton { icon: "refresh"; size: 36; tip: qsTr("Rescan"); onClicked: lib.rescan() }
        }

        // Grid
        GridView {
            id: grid
            visible: root.layoutMode === "grid" && lib.count > 0
            Layout.fillWidth: true
            Layout.fillHeight: true
            clip: true
            boundsBehavior: Flickable.StopAtBounds
            readonly property int cols: Math.max(1, Math.floor((width + 20) / (Theme.opt.cardSize + 20)))
            cellWidth: width / cols
            cellHeight: (cellWidth - 20) / (root.kind === "audio" ? 1 : 16 / 9) + 74
            model: lib
            ScrollBar.vertical: ScrollBar {}
            delegate: Item {
                required property int index
                required property string title
                required property string folder
                required property string kind
                required property string thumbnail
                required property string extension
                required property url url
                width: grid.cellWidth
                height: grid.cellHeight
                MediaCard {
                    width: parent.width - 20
                    title: parent.title
                    subtitle: parent.folder
                    kind: parent.kind
                    badge: parent.extension
                    thumbnail: parent.thumbnail
                    onClicked: root.play(parent.index)
                    onRightClicked: (mx, my) => { ctx.row = parent.index; ctx.url = parent.url; ctx.popup() }
                }
            }
        }

        // List
        ListView {
            id: list
            visible: root.layoutMode === "list" && lib.count > 0
            Layout.fillWidth: true
            Layout.fillHeight: true
            clip: true
            spacing: 2
            boundsBehavior: Flickable.StopAtBounds
            model: lib
            ScrollBar.vertical: ScrollBar {}
            delegate: Rectangle {
                id: rowItem
                required property int index
                required property string title
                required property string folder
                required property string kind
                required property string extension
                required property real size
                required property url url
                width: list.width
                height: 54 * Theme.opt.space
                radius: Theme.opt.radius * 0.6
                color: rowMa.containsMouse ? Theme.alpha(Theme.c.text, 0.06) : index % 2 ? "transparent" : Theme.alpha(Theme.c.text, 0.02)
                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 14
                    anchors.rightMargin: 14
                    spacing: 14
                    Item {
                        Layout.preferredWidth: 28
                        Text { anchors.centerIn: parent; visible: !rowMa.containsMouse; text: rowItem.index + 1; color: Theme.c.textMuted; font.pixelSize: 12; font.features: ({ "tnum": 1 }) }
                        Icon { anchors.centerIn: parent; visible: rowMa.containsMouse; name: "play"; size: 16; color: Theme.c.accent }
                    }
                    Rectangle {
                        Layout.preferredWidth: 36; Layout.preferredHeight: 36
                        radius: Theme.opt.radius * 0.5
                        color: Qt.hsla(((rowItem.title.charCodeAt(0) || 0) * 7 % 360) / 360, 0.5, Theme.dark ? 0.3 : 0.7, 1)
                        Icon { anchors.centerIn: parent; name: rowItem.kind === "audio" ? "music" : "film"; size: 16; color: Theme.alpha("#FFFFFF", 0.85) }
                    }
                    Text { text: rowItem.title; color: Theme.c.text; font.pixelSize: 14; font.weight: Font.Medium; elide: Text.ElideRight; Layout.fillWidth: true }
                    Text { text: rowItem.folder; color: Theme.c.textMuted; font.pixelSize: 13; elide: Text.ElideRight; Layout.preferredWidth: 200 }
                    Text { text: rowItem.extension; color: Theme.c.textMuted; font.pixelSize: 11; font.weight: Font.Bold; Layout.preferredWidth: 46 }
                    Text { text: (rowItem.size / 1048576).toFixed(rowItem.size > 1073741824 ? 0 : 1) + " MB"; color: Theme.c.textMuted; font.pixelSize: 12; font.features: ({ "tnum": 1 }); horizontalAlignment: Text.AlignRight; Layout.preferredWidth: 80 }
                }
                MouseArea {
                    id: rowMa
                    anchors.fill: parent
                    hoverEnabled: true
                    acceptedButtons: Qt.LeftButton | Qt.RightButton
                    cursorShape: Qt.PointingHandCursor
                    onClicked: mouse => {
                        if (mouse.button === Qt.RightButton) { ctx.row = rowItem.index; ctx.url = rowItem.url; ctx.popup() }
                        else root.play(rowItem.index)
                    }
                }
            }
        }

        // Empty state
        ColumnLayout {
            visible: lib.count === 0 && !lib.scanning
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 10
            Item { Layout.fillHeight: true }
            Icon { name: root.kind === "audio" ? "music" : "film"; size: 54; color: Theme.c.textMuted; Layout.alignment: Qt.AlignHCenter }
            Text {
                text: search.text ? qsTr("Nothing matches “%1”").arg(search.text) : qsTr("No %1 found").arg(root.heading.toLowerCase())
                color: Theme.c.text; font.pixelSize: 18; font.weight: Font.DemiBold
                Layout.alignment: Qt.AlignHCenter
            }
            Text {
                text: qsTr("Add folders in Customize → Library, or drop files right here.")
                color: Theme.c.textMuted; font.pixelSize: 13
                Layout.alignment: Qt.AlignHCenter
            }
            Item { Layout.fillHeight: true }
        }
    }

    Menu {
        id: ctx
        property int row: -1
        property url url
        background: Rectangle { implicitWidth: 220; color: Theme.c.elevated; radius: Theme.opt.radius * 0.8; border.color: Theme.c.border }
        delegate: MenuItem {
            id: mi
            contentItem: Text { text: mi.text; color: Theme.c.text; font.pixelSize: 13.5; leftPadding: 6 }
            background: Rectangle { radius: Theme.opt.radius * 0.5; color: mi.highlighted ? Theme.alpha(Theme.c.text, 0.08) : "transparent" }
        }
        Action { text: qsTr("Play"); onTriggered: root.play(ctx.row) }
        Action { text: qsTr("Play next"); onTriggered: { root.queue.playNext(ctx.url); root.app.toast("queue", qsTr("Playing next")) } }
        Action { text: qsTr("Add to queue"); onTriggered: root.app.enqueue([ctx.url]) }
        Action { text: qsTr("Show in folder"); onTriggered: Qt.openUrlExternally(ctx.url.toString().substring(0, ctx.url.toString().lastIndexOf("/"))) }
    }
}
